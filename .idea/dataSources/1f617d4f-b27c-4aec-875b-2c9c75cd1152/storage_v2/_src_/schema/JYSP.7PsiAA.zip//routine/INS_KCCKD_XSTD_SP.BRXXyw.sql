CREATE PROCEDURE INS_KCCKD_XSTD_SP
( p_XSTDID in NUMBER,p_zdrid in number  )
   AS
 v_seqkcckd1 number;
  v_sql varchar2(4000) :='';
	
BEGIN 
select SEQKCCKD1.NEXTVAL into v_seqkcckd1 from dual;    
v_sql := q'[INSERT INTO KCCKD1_TB
	  (  ID,
       ZDRID,
       ZDRQ,
       DJLXID,
       DJZT,
       SPZT,
       YWRQ,
       KHID       
       )
select :1,
        :2,
        SYSDATE,
        6,
        0,
        0,
SYSDATE,
       KHID
       FROM XSTD_TB TD WHERE 
      TD.ID=:3
	 ]';
EXECUTE IMMEDIATE v_sql using v_seqkcckd1,p_zdrid,p_XSTDID;
 
  for c_sor_1 in 
  (select tdmx.ID,tdmx.WLID,tdmx.SL,wl.ckid  from XSTDMX_TB TDMX inner join
  wlzd_tb wl on tdmx.wlid=wl.id  where tdmx.fid = p_XSTDID)     
    loop      
    insert into KCCKD2_TB(ID,FID,XSTDMXID,WLID,SFSL) values     
       (
       SEQKCCKD2.NEXTVAL,
       v_seqkcckd1,
       c_sor_1.id,
        c_sor_1.wlid,
        c_sor_1.sl
        -----c_sor_1.ckid
       );     
       end loop;
      COMMIT;
END INS_KCCKD_XSTD_SP;
/

