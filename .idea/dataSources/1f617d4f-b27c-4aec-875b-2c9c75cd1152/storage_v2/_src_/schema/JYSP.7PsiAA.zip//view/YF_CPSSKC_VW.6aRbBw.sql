CREATE VIEW YF_CPSSKC_VW AS
  SELECT A."CPID",A."DDBH",B.RKSL,C.CKSL,D.KCSL,E.CPBH,E.CPMC,E.CPGG FROM
(SELECT DISTINCT CPID,DDBH FROM (
select DISTINCT CPID,DDBH from yf_cpck_tb where rkrq is not null
 UNION ALL
select DISTINCT CPID,DDBH from yf_cpck_tb where rkrq is not null and ckrq is not null
))A
LEFT JOIN
(select CPID,DDBH,sum(sl)RKSL from (select CPID,DDBH,sl from yf_cpck_tb where rkrq is not null) group by CPID,DDBH) B
ON A.CPID=B.CPID AND A.DDBH=B.DDBH
LEFT JOIN
(select CPID,DDBH,sum(sl)CKSL from (select CPID,sl,DDBH from yf_cpck_tb where rkrq is not null and ckrq is not null) group by CPID,DDBH) C
ON A.CPID=C.CPID AND A.DDBH=C.DDBH
LEFT JOIN
(select CPID,DDBH,sum(sl)KCSL from (select CPID,sl,DDBH from yf_cpck_tb where rkrq is not null and ckrq is null) group by CPID,DDBH) D
ON A.CPID=D.CPID AND A.DDBH=D.DDBH
LEFT JOIN YF_CPZD_TB E ON A.CPID=E.ID
ORDER BY A.DDBH,A.CPID
/

