CREATE function DEL_GETMENU_FC(P_DELID in number)
  return varchar2 as
  Result varchar2(4000) := null;
  --created by wangwh 20090514  委托菜单显示
begin
  for x in (SELECT lpad('-- ', 3 * (level - 1), '--') || U_NAME U_NAME
              from auth_menu_tb
             where menu_id in (select menu_id
                                 from oa_delegationmenu_tb
                                where DELEGATION_ID = P_DELID)
             START WITH MENU_ID_SUPERIOR is null 　　CONNECT BY
             PRIOR MENU_ID = MENU_ID_SUPERIOR) loop
    Result := Result || x.U_NAME || '<br>';
    if length(Result) > 200 then
      return(rtrim(Result, ',')||'....');
    end if;
  end loop;
  return(rtrim(Result, ','));
end DEL_GETMENU_FC;
/

