CREATE VIEW GB_PCFX1_VW AS
  select scph,csid,fx,count(*) cs from gb_pcjl_tb where zt=431 group by scph,csid,fx
/

