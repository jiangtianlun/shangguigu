CREATE procedure kcjs_sp(p_id in number) as
  p_bdkcsl number;
  p_zzkcsl number;
  p_jhsl   number; --计划数量
  p_zkc    number;
  p_jysl   number;

begin
  select nvl(byjy, 0)
    into p_bdkcsl
    from bykcjy_vw
   where wlid = (select ljid from scyjh_tb where id = p_id)
     and yf = to_char(sysdate, 'yyyymm');
  select nvl(zzkcsl, 0) into p_zzkcsl from scyjh_tb where id = p_id;
  select jhsl into p_jhsl from scyjh_tb where id = p_id;

  p_zkc  := p_bdkcsl + p_zzkcsl;
  p_jysl := p_zkc - p_jhsl;

  update scyjh_tb
     set bdkcsl = p_bdkcsl, zkc = p_zkc, jysl = p_jysl
   where id = p_id;
  commit;
exception
  when others then
    rollback;
end kcjs_sp;
/

