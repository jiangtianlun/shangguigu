CREATE VIEW ORA_VW_ASPNET_PROFILES AS
  SELECT UserId,
       LastUpdatedDate,
       DBMS_LOB.GETLENGTH(PropertyNames) +
       DBMS_LOB.GETLENGTH(PropertyValuesString) +
       DBMS_LOB.GETLENGTH(PropertyValuesBinary) DataSize
FROM ora_aspnet_Profile
WITH READ ONLY
/

