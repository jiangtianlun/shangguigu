CREATE VIEW GB_CPCKTJ2_VW AS
  select a."NY",a."KHID",a."CKSL",b.khmc from
(select ny,khid,sum(cksl)cksl from (select cpid,cksl,khid,to_char(ckrq,'yyyy-mm')ny from GB_cpck_tb)
 group by ny,khid)a left join GB_khzd_tb b on a.khid=b.id order by a.ny,a.khid
/

