CREATE VIEW SFC_VW AS
  SELECT WLID, WLBH,WLMC,GGXH,sum(SQJC)SQJC,sum(BQRK) BQRK,sum(BQCK) BQCK,sum(BQJC) BQJC from 
(select WLID,SSSL SQJC,0 BQRK,0 BQCK,0 BQJC from KCRKD2_TB RKD2 left join KCRKD1_TB RKD1 on RKD2.FID = RKD1.ID where  RKD1.YWRQ<to_date('2017-03-01 00:00:00','yyyy-mm-dd hh24:mi:ss') and  RKD1.DJZT = 1
		union all			
		select   WLID,-SFSL SQJC,0 BQRK,0 BQCK,0 BQJC from KCCKD2_TB CKD2 left join KCCKD1_TB CKD1 on CKD2.FID = CKD1.ID where CKD1.YWRQ<to_date('2017-03-01 00:00:00','yyyy-mm-dd hh24:mi:ss') and  CKD1.DJZT = 1 
       union all         
		  select WLID,0 SQJC,SSSL BQRK,0 BQCK,0 BQJC from  KCRKD2_TB RKD2 left join KCRKD1_TB RKD1 on RKD2.FID = RKD1.ID  where RKD1.YWRQ between to_date('2017-03-01 00:00:00','yyyy-mm-dd hh24:mi:ss') and to_date('2017-03-29 14:28:57','yyyy-mm-dd hh24:mi:ss')
		  and  RKD1.DJZT = 1 
      union all	
		select  WLID,0 SQJC,0 BQRK,SFSL BQCK,0 BQJC from KCCKD2_TB CKD2 left join KCCKD1_TB CKD1 on CKD2.FID = CKD1.ID 
        where CKD1.YWRQ  BETWEEN to_date('2017-03-01 00:00:00','yyyy-mm-dd hh24:mi:ss') and to_date('2017-03-29 14:28:57','yyyy-mm-dd hh24:mi:ss') and  CKD1.DJZT = 1 
        union all select WLID,0 SQJC,0 BQRK,0 BQCK, SSSL  BQJC from KCRKD2_TB RKD2 left join KCRKD1_TB RKD1 on RKD2.FID = RKD1.ID
         where  RKD1.YWRQ <= to_date('2017-03-29 14:28:57','yyyy-mm-dd hh24:mi:ss') and  RKD1.DJZT = 1 
		union all select WLID,0  SQJC,0 BQRK,0  BQCK,  -SFSL  BQJC  from KCCKD2_TB CKD2 left join KCCKD1_TB CKD1 ON CKD2.FID = CKD1.ID
         where CKD1.YWRQ <= to_date('2017-03-29 14:28:57','yyyy-mm-dd hh24:mi:ss') and  CKD1.DJZT = 1 
		 )A inner join (select id,wlbh,wlmc,ggxh,jldwid from WLZD_TB where sfyx = 1 and ckid=1212) WL on A.wlid = wl.id group by WLID,wlbh,wlmc,ggxh,jldwid order by wlbh
/

