CREATE VIEW SP_PH_VW AS
  select wlid, ph, sum(sl) sl, sum(je) je
  from (
        --各仓库期初：各仓库都按照现存的最近的结转日期(可以未审核)。
        --一个仓库如果既有审核又有未审核的盘点入库单，则该仓库按当前月份计算
        select wlid, ph, nvl(pdsl, 0) sl, nvl(pdje, 0) je
          from sp_qckc_tb t1
         where exists (select *
                  from (select max(ywrq) ywrq, ckid
                          from SP_qckc_tb
                         group by ckid) t3
                 where t1.ywrq = t3.ywrq
                   and t1.ckid = t3.ckid)
        union all
        --各仓库除采购外入库单：各仓库结转日期至当前时间
        select t2.wlid, t2.ph, sum(nvl(t2.sssl, 0)) sl, sum(nvl(t2.je, 0)) je
          from SP_kcrkd1_tb t1, SP_kcrkd2_tb t2
         where t1.id = t2.fid
           and t2.cgddmxid is null
           and t1.djzt = 1
           and exists
         (select *
                  from (select max(ywrq) ywrq, ckid
                          from SP_qckc_tb
                         group by ckid) t3
                 where t1.ckid = t3.ckid
                   and t1.ywrq between t3.ywrq and sysdate)
         group by wlid, ph
        union all

        --各仓库采购入库单：各仓库结转日期至当前时间
        select wlid, ph, sum(nvl(sssl, 0)) sl, sum(nvl(je, 0)) je
          from SP_kcrkd2_tb t1
         where cgddmxid is not null
           and djzt = 1
           and exists
         (select *
                  from (select max(ywrq) ywrq, ckid
                          from SP_qckc_tb
                         group by ckid) t3
                 where t1.ckid = t3.ckid
                   and t1.ywrq between t3.ywrq and sysdate)
         group by wlid, ph
        union all

        --各仓库出库单：各仓库结转日期至当前时间
        select wlid, ph, -sum(nvl(sfsl, 0)) sl, -sum(nvl(t2.je, 0)) je
          from SP_kcckd1_tb t1, SP_kcckd2_tb t2
         where t1.id = t2.fid
           and t1.djzt = 1
           and exists
         (select *
                  from (select max(ywrq) ywrq, ckid
                          from SP_qckc_tb
                         group by ckid) t3
                 where t1.ckid = t3.ckid
                   and t1.ywrq between t3.ywrq and sysdate)
         group by wlid, ph)
 group by wlid, ph
 order by wlid, ph
/

