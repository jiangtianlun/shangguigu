CREATE PROCEDURE sc_scyjh_sp(P_IMPTASK_BM IN NUMBER) IS
 CURSOR CUR_IMPDATA IS
      SELECT
          to_single_byte(C03)     LJBH,      --零件编号
          to_single_byte(C04)     LJMC,       ---零件名称
             C05     JHSCSL,      ---计划生产数量
             C06     BDKCSL,      -----本地库存数量
             C07     ZZKC,      ----中转库存
             C08     ZKC,      ----总库存
             C09     JYSL,       ---结余数量
             C10     SJSCSL,      -----实际生产数量
             C11     JFRQ, --交付日期
             C12     DHRQ --到货日期
       FROM ZX_SWAPDATA_TB T
        WHERE T.IMPTASK_BM = P_IMPTASK_BM;
        V_LJ CUR_IMPDATA%ROWTYPE;
        V_CNT NUMBER;
        v_wl_cnt NUMBER;
        v_LJID NUMBER;
        V_ZDRID number;
         V_DJLX number;
        V_NFYF varchar2(100);
		str_split_table str_split;
BEGIN
   savepoint V_SP_0000;  
   --substr('782,201701',instr('782,201701',',',1,1)-1 )
  --SELECT substr(TEMPADDITION,8,6) into V_ZDRID FROM ZX_SWAPDATA_VW;----取制单人ID
   select string_split(TEMPADDITION,',') into str_split_table from ZX_SWAPDATA_VW;
   
   V_NFYF := str_split_table(1);
   V_ZDRID := str_split_table(2);
   V_DJLX := str_split_table(3);
   --SELECT substr(TEMPADDITION,1,6) into V_NFYF FROM ZX_SWAPDATA_VW;   
   open CUR_IMPDATA;
   loop fetch CUR_IMPDATA into V_LJ;
   exit when CUR_IMPDATA%NOTFOUND;
   
   if V_DJLX=0 then --增补单 
    select count(1) into V_CNT from SCYJH_TB where trim(LJBH)=trim(V_LJ.LJBH) 
    and trim(NFYF)=V_NFYF and DJLX=V_DJLX and to_char(JFRQ,'YYYY-MM-DD')=trim(V_LJ.JFRQ);  
  end if;
  if V_DJLX=1 then --计划单 
    select count(1) into V_CNT from SCYJH_TB where trim(LJBH)=trim(V_LJ.LJBH) 
    and trim(NFYF)=V_NFYF and DJLX=V_DJLX;  
   end if;
   
   --trim((select to_char(scrq,'yyyymm') scrq from sc_sjcs_tb where id=1)); 
   --查找是否有相同的零件
   --xwh 20170627 增加仓库为模压(1273)的判断
   select count(id) into v_wl_cnt from WLZD_TB where SFYX=1 and CKID=1273 and trim(WLBH)=trim(V_LJ.LJBH);
   if v_wl_cnt = 1 then
   select id into V_LJID from WLZD_TB where trim(WLBH)=trim(V_LJ.LJBH) and CKID=1273 and SFYX=1;
   else
   V_LJID :=-1;
   end if;
   
   IF V_CNT = 0 THEN
   INSERT INTO SCYJH_TB
      (ID,DJLX,DJZT,LJID,LJBH,LJMC,JHSL,BDKCSL,ZZKCSL,ZKC,JYSL,SJSL,ZDRQ,zdrid,NFYF,JFRQ,DHRQ)
         SELECT SEQSCYJH.NEXTVAL,
                V_DJLX,
                0,-----草稿
                v_LJID,
                to_single_byte(trim(V_LJ.LJBH)),
                to_single_byte(trim(V_LJ.LJMC)),
                nvl(trim(V_LJ.JHSCSL),0),
                nvl(trim(V_LJ.BDKCSL),0),
                nvl(trim(V_LJ.ZZKC),0),
                nvl(trim(V_LJ.ZKC),0),
                nvl(trim(V_LJ.JYSL),0),
                nvl(trim(V_LJ.SJSCSL),0),                         
                sysdate,
                v_ZDRID,
                v_nfyf，
                to_date(trim(nvl(V_LJ.JFRQ,'')),'YYYY-MM-DD'),
                --20170623徐文豪修改，如未填写到货日期，若按交付日期提前一周后小于系统日期，则往后推一天
                --如已填到货日期，则按到货日期来
                (case when (to_date(trim(nvl(V_LJ.JFRQ,'')),'YYYY-MM-DD')-7-to_date(to_char(SYSDATE,'YYYY-MM-DD'),'YYYY-MM-DD'))<0 and V_LJ.DHRQ is null then to_date(to_char(SYSDATE,'YYYY-MM-DD'),'YYYY-MM-DD')+1 when V_LJ.DHRQ is not null then to_date(trim(nvl(V_LJ.DHRQ,'')),'YYYY-MM-DD') else (to_date(trim(nvl(V_LJ.JFRQ,'')),'YYYY-MM-DD')-7) end )
               -- (select to_char(scrq,'yyyymm') scrq from sc_sjcs_tb where id=1) nfyf
                FROM DUAL;
   END IF;
       IF V_CNT <>0 THEN
        UPDATE SCYJH_TB
        SET 
              DJZT=0,            
              LJID = v_LJID,
              LJBH = to_single_byte(V_LJ.LJBH),
              LJMC = to_single_byte(V_LJ.LJMC),
              JHSL = nvl(trim(V_LJ.JHSCSL),0),
              BDKCSL=nvl(trim(V_LJ.BDKCSL),0),
              ZZKCSL=nvl(trim(V_LJ.ZZKC),0),
              ZKC=nvl(trim(V_LJ.ZKC),0),
              JYSL=nvl(trim(V_LJ.JYSL),0),
              SJSL=nvl(trim(V_LJ.SJSCSL),0),
              zdrid=V_ZDRID,
              --ZDRID=V_USERID,
              ZDRQ = SYSDATE,
              JFRQ = to_date(nvl(trim(V_LJ.JFRQ),''),'YYYY-MM-DD'),
              DHRQ = (case when (to_date(trim(nvl(V_LJ.JFRQ,'')),'YYYY-MM-DD')-7-to_date(to_char(SYSDATE,'YYYY-MM-DD'),'YYYY-MM-DD'))<0 and V_LJ.DHRQ is null then to_date(to_char(SYSDATE,'YYYY-MM-DD'),'YYYY-MM-DD')+1 when V_LJ.DHRQ is not null then to_date(trim(nvl(V_LJ.DHRQ,'')),'YYYY-MM-DD') else (to_date(trim(nvl(V_LJ.JFRQ,'')),'YYYY-MM-DD')-7) end )

              WHERE trim(LJBH) = trim(V_LJ.LJBH)
              and trim(nfyf)= V_NFYF and  DJLX=V_DJLX;
             -- and NFYF=(select to_char(scrq,'yyyymm') scrq from sc_sjcs_tb where id=1);
        END IF;
   END LOOP;
   CLOSE CUR_IMPDATA;
   COMMIT;
   EXCEPTION  WHEN OTHERS THEN RAISE_APPLICATION_ERROR(-20009, SQLERRM||'导入出错');
   ROLLBACK TO SAVEPOINT V_SP_0000;
   commit;
   END sc_scyjh_sp;
/

