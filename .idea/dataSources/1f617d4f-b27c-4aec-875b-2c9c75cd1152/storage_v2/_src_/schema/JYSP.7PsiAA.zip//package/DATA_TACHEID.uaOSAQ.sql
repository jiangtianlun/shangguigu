CREATE package data_tacheid as
  tacheid number;
End data_tacheid;
/

