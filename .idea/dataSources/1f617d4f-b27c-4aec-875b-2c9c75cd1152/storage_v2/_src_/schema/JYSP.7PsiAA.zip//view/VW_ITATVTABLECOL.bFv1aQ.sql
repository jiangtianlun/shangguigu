CREATE VIEW VW_ITATVTABLECOL AS
  select TBKEY*1000000 + COLKEY RXH, AA."COLKEY",AA."TBKEY",AA."TABLE_NAME",AA."COLUMN_NAME",AA."DATA_TYPE",AA."COMMENTS"
  from (select DECODE(substr(COLUMN_NAME,
                             instr(COLUMN_NAME, '_', -1, 1) + 1,
                             length(COLUMN_NAME) -
                             instr(COLUMN_NAME, '_', -1, 1)),
                      'ID',
                      0,
                      substr(COLUMN_NAME,
                             instr(COLUMN_NAME, '_', -1, 1) + 1,
                             length(COLUMN_NAME) -
                             instr(COLUMN_NAME, '_', -1, 1))) as COLKEY,
               substr(TABLE_NAME,
                      instr(TABLE_NAME, '_', 1, 1) + 1,
                      instr(TABLE_NAME, '_', -1, 1) -
                      instr(TABLE_NAME, '_', 1, 1) - 1) as TBKEY,
               "TABLE_NAME",
               "COLUMN_NAME",
               (select DATA_TYPE
                  from user_tab_columns
                 where COLUMN_NAME = user_col_comments.COLUMN_NAME
                   and TABLE_NAME = user_col_comments.TABLE_NAME) as DATA_TYPE,
               COMMENTS
          from user_col_comments
         where table_name like 'ITATV_%') AA
/

