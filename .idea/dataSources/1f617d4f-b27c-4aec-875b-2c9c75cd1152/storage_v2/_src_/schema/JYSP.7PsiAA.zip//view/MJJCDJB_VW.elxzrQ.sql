CREATE VIEW MJJCDJB_VW AS
  select jl.jcrq fcrq,jl.mjid,jl.fcbmid,jl.jsbmid,jl.jcbz from mjjcdjjl_tb jl where jl.jcbz=0
union
select jl.ccrq fcrq,jl.mjid,jl.fcbmid,jl.jsbmid,jl.jcbz from mjjcdjjl_tb jl where jl.jcbz=1
union
select jl.jcrq fcrq,jl.mjid,jl.fcbmid,jl.jsbmid,jl.jcbz from mjjcdjjl_tb jl where jl.jcbz=2
union
select jl.ccrq fcrq,jl.mjid,jl.fcbmid,jl.jsbmid,jl.jcbz from mjjcdjjl_tb jl where jl.jcbz=3
/

