CREATE procedure LONG_VARCHAR_SP(
P_TAB  VARCHAR2,
P_COL  VARCHAR2,
P_PK   VARCHAR2
) is
V_SQL  VARCHAR2(4000):= 'SELECT '||P_PK||','||p_COL||' FROM '||P_TAB ;
V_PK   NUMBER;
V_COL  LONG;
V_GD   VARCHAR2(4000);
V_SQL1 VARCHAR2(4000);

TYPE CUR1 IS REF CURSOR;
MYCUR CUR1;
 
begin
     --1
     V_SQL := 'alter table '||P_TAB||' add GD varchar2(4000)';
     EXECUTE IMMEDIATE V_SQL ;
     --2
     V_SQL  := 'SELECT '||P_PK||','||p_COL||' FROM '||P_TAB ;
     OPEN MYCUR FOR V_SQL;
     LOOP
         FETCH MYCUR INTO V_PK,V_COL ;
     EXIT WHEN MYCUR%NOTFOUND;
         V_GD := DBMS_LOB.substr(V_COL);
         IF V_GD IS NOT NULL THEN
             V_SQL1 := 'UPDATE '||P_TAB||' SET GD ='||V_GD||' WHERE '||P_PK ||'='||V_PK;
             EXECUTE IMMEDIATE V_SQL1 ;
         END IF;

     END LOOP;
     CLOSE MYCUR;
     COMMIT;
     /*--3
     V_SQL := 'UPDATE '||P_TAB||' SET '||P_COL||' = GD';
     --4
     V_SQL := 'alter table '||P_TAB||' add GD varchar2(4000)';
     EXECUTE IMMEDIATE V_SQL ;*/
     
end LONG_VARCHAR_SP;
/

