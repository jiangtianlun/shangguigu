CREATE package FK_UTIL
IS
  -- 获得我所引用的表
  FUNCTION get_refering_stats(v_table_name varchar2) RETURN fk_stats;
  -- 获得所有子表及外键列
  FUNCTION get_refered_stats(v_table_name varchar2) RETURN fk_stats;
  -- 获得所有子表对某个ID的引用条数
  FUNCTION get_refered_count(v_parent_table varchar2, v_parent_id NUMBER) RETURN fk_refered_count;
  -- 获得所有子表对符合条件的某些记录的引用条数
  FUNCTION get_refered_count_cond(v_parent_table varchar2, v_cond_col varchar2, v_cond varchar2) RETURN fk_refered_count;
END FK_UTIL;


/

