CREATE function GET_COLUMNSETTING_BY_XK_MASTER return VARCHAR2 is

v_result         varchar2(100);
v_columnsetting  number;
v_str            varchar2(4000);
v_num            number;
v_str2           varchar2(1000);
xx number;
-- 得到权限设置
cursor c_columnsetting is 
   select ltrim(to_char(columnsetting),',') columnsetting 
     from xk_master ;
c_columnsetting_rt   c_columnsetting%rowtype;    
     
begin
     -- delete 
     delete from xk_master_columnsetting ;
     open c_columnsetting ;
     fetch c_columnsetting into c_columnsetting_rt;
     v_str := c_columnsetting_rt.columnsetting ;
     while ( length(v_str)>0  )
     loop
         v_num := instr(v_str,',');
         v_columnsetting := to_number( substr(v_str , 1 , v_num-1 ));
         v_str := substr(v_str , v_num +1 , length(v_str) );
         xx :=length(v_str);
         -- insert into xk_master_columnsetting
         v_str2 := 'insert into xk_master_columnsetting values ( :v_columnsetting )';
         execute immediate v_str2 using v_columnsetting ;
         
     end loop;
     close c_columnsetting;

     commit;
    return(v_result);
end GET_COLUMNSETTING_BY_XK_MASTER;
/

