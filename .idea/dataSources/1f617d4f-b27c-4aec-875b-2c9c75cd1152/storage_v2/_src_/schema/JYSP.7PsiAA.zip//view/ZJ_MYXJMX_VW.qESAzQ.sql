CREATE VIEW ZJ_MYXJMX_VW AS
  select bzid,ljid,sum(sl) sl,sum(bfsl) bfsl,YF,gxzdid FROM(
select XJJL.BZID BZID,
       XJJL.LJID LJID,
       NVL(XJJL.SL, 0) SL,----------巡检单的每月明细 xjy
       NVL(XJJL.BFSL, 0) BFSL,
       TO_CHAR(SCRQ, 'YYYY-MM') YF,
       gxzdid
  from zj_xjjl1_tb XJJL
  LEFT JOIN wlzd_tb wlzd on XJJL.LJID = WLZD.ID
 WHERE XJJL.DJZT = 1)
 GROUP BY grouping sets((BZID,LJID,YF,gxzdid),LJID,NULL) ORDER BY LJID
/

