CREATE function testtest(p_orgid in number) return number is
  result number;
begin
  result := 2;
  return result;
end testtest;
/

