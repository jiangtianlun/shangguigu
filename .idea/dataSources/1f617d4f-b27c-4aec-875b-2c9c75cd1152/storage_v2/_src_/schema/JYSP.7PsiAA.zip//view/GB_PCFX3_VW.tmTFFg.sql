CREATE VIEW GB_PCFX3_VW AS
  select csid,fx,count(*)cs,avg(csz)ave,min(amin)amin,max(amax)amax from
(select a.*,b.amin,b.amax from (select scph,csid,fx,csz from gb_pcjl_tb where zt=431)a left join gb_cszd_tb b on a.csid=b.id)
group by csid,fx
/

