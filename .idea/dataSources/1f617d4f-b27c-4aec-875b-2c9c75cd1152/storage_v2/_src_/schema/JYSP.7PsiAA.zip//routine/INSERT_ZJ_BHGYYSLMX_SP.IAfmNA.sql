CREATE procedure INSERT_ZJ_BHGYYSLMX_SP(p_fid in number,p_num in number)
as
----Wy.PU63802新增1行
 v_num number:= p_num;
begin
loop
exit when v_num < 1;
insert into ZJ_BHGYYSLMX_TB (ID,FID,Djlx) SELECT SEQZJ_BHGYYSLMX.NEXTVAL,p_fid,1 FROM DUAL;
v_num := v_num -1;
end loop;
end INSERT_ZJ_BHGYYSLMX_SP;
/

