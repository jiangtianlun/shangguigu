CREATE VIEW SP_WLBOM_VW AS
  select id wlid,wlmc,wlbh, ggxh,bz from sp_wlzd_tb order by id
/

