CREATE procedure INSERT_SP_KCRKD1_SP(p_djlxid in number,p_userid in number,p_ckid in number,p_num in number)
as
 v_num number := p_num;
 --v_MXNUM number := 0;--v_MXNUM 明细数量
begin
  --select count(id) into v_MXNUM from cc_xstdmx_tb where fid = p_fid;
  /*IF v_MXNUM+v_num>10 THEN
    v_num :=10-v_MXNUM;  --明细最多只有10行
  END IF;*/
loop
exit when v_num < 1;
insert into SP_KCRKD1_TB (ID,DJZT,DJLXID,CKID,ZDRID,ZDRQ,YWRQ) SELECT SEQSP_KCRKD1.NEXTVAL,0,p_djlxid,p_ckid,p_userid,sysdate,sysdate FROM DUAL;
v_num := v_num -1;
end loop;
end INSERT_SP_KCRKD1_SP;
/

