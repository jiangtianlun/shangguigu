CREATE VIEW GB_YNKH3_VW AS
  select a."BZID",a."RQ",a."YDL",b."ID",b."ZBMC",b."YQZB",(a.ydl-b.yqzb) as cz,to_char(RQ,'yyyy-mm') as NY from (select bzid,rq,sum(ydl) ydl from GB_nxcj3_tb group by bzid,rq)a left join
GB_banzu_tb b on a.bzid=b.id
/

