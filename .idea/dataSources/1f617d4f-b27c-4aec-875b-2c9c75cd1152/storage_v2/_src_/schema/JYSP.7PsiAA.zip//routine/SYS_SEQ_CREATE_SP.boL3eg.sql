CREATE Procedure SYS_SEQ_CREATE_SP Is

--2004.08.10 LIWB CREATED 创建各表序列，并根据主键字段内容调整序列起始编号

	v_maxseq  Number;
	v_sql     Varchar2(400);
	v_b_found Boolean;

	--/*序列名称光标*/
	Cursor v_rs_seq Is
		Select 'SEQ' || substr(uc.table_name, 1, length(uc.table_name) - 3) As seqname, uc.table_name,
			   ucc.column_name, utc.data_type, uc.constraint_name
		From sys.user_constraints uc, sys.user_cons_columns ucc, sys.user_tab_columns utc
		Where uc.constraint_name = ucc.constraint_name And uc.constraint_type = 'P' And
			  uc.table_name = utc.table_name And ucc.column_name = utc.column_name And
			  utc.data_type = 'NUMBER' And substr(uc.table_name, length(uc.table_name) - 2, 3) = '_TB'
		Union
			Select 'SEQ' || uc.table_name, uc.table_name, ucc.column_name, utc.data_type As seqname,
				   uc.constraint_name
			From sys.user_constraints uc, sys.user_cons_columns ucc, sys.user_tab_columns utc
			Where uc.constraint_name = ucc.constraint_name And uc.constraint_type = 'P' And
				  uc.table_name = utc.table_name And ucc.column_name = utc.column_name And
				  utc.data_type = 'NUMBER' And substr(uc.table_name, length(uc.table_name) - 2, 3) <> '_TB';


	--对象存在否光标
	Cursor v_rs_obj(var_objname Varchar2) Is
		Select uo.object_name From sys.user_objects uo Where uo.object_name = var_objname;

	rs_seq v_rs_seq%Rowtype;
	rs_obj v_rs_obj%Rowtype;

	--动态SQL
	Type refcursor Is Ref Cursor;
	acur refcursor;
Begin
	dbms_output.put_line('开始更新序列...');
	Open v_rs_seq;
	Loop
		Fetch v_rs_seq
			Into rs_seq;
		Exit When v_rs_seq%Notfound;

		dbms_output.put_line(rs_seq.seqname || '...');

		Open acur For 'select max(' || rs_seq.column_name || ') as maxseq from ' || rs_seq.table_name;

		Fetch acur
			Into v_maxseq;
		If v_maxseq Is Null Then
			v_maxseq := 0;
		End If;
		Close acur;

		--删除序列
		Open v_rs_obj(upper(rs_seq.seqname));
		Fetch v_rs_obj
			Into rs_obj;
		v_b_found := v_rs_obj%Found;
		Close v_rs_obj;
		If v_b_found Then
			v_sql := 'drop sequence ' || rs_seq.seqname;
			Execute Immediate v_sql;

			/*          v_sql := 'Update sys.seq$ s Set s.highwater = ' || (round(v_maxseq) + 1) ||
                                 ' Where s.obj# = (Select uo.object_id From sys.user_objects uo Where uo.object_name =' ||
                                 chr(39) || rs_seq.seqname || chr(39) || ')';
            */ --Execute Immediate v_sql;
		End If;
		--创建序列
		v_sql := 'create sequence ' || rs_seq.seqname || ' start with ' || (round(v_maxseq) + 1);
		Execute Immediate v_sql;

	End Loop;
	Close v_rs_seq;
	dbms_output.put_line('更新序列完毕!');
End SYS_SEQ_CREATE_SP;
/

