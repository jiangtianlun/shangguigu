CREATE procedure INSERT_TUZHI_SP(p_dir    in varchar2-----目录名
                                           )
as
  b_file bfile;
  b_lob blob;
 begin
  insert into sp_zx_file_tb(file_bm,table_name,primarykey_value,file_mc,create_id,file_date) 
   values (5,'A1',3,'111.dwg',2,empty_blob() ) return file_date into b_lob;
  
  b_file:=bfilename('fsp','111.dwg'); 
  dbms_lob.open(b_file,dbms_lob.file_readonly);
  dbms_lob.loadfromfile(b_lob,b_file,dbms_lob.getlength(b_file));
  dbms_lob.close(b_file);
  commit;

end INSERT_TUZHI_SP;
/

