CREATE VIEW KHZD_VW AS
  select ID, LBBH  as KHBH,LBMC as khmc,FID as KHLBID from wllb_tb where fid in ( 104,323)
/

