CREATE function getExpressPageUrl(p_expressid in number)
  return varchar as
  result      varchar(4000);
  p_express varchar(4000);
begin
  select t.express_disptext into p_express
    from oa_tacherouter_tb t
   where t.expressid = p_expressid;
  if p_express is null then
     result:='<a href="../../WorkFlow/Ext/Expression.aspx?expressid='||p_expressid||'" target=_blank>配置表达式</a>';
     --result:='';
  else
     result:='<a href="../../WorkFlow/Ext/Expression.aspx?expressid='||p_expressid||'" target=_blank>'||BASE_LENGTHLIMIT_FC(p_express,30)||'</a>';
     --result:='';
     end if;
  return result;
end getExpressPageUrl;



/

