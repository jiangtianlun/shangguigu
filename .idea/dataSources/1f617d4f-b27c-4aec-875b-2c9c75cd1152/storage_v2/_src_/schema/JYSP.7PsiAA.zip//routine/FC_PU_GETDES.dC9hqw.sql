CREATE function FC_PU_GETDES(P_ID in number, DTYPE in number)
  return clob as
  --created by wangwh 20120529 获取新增的说明
  result clob;
  v_KEY  number;
  v_TYPE number;
  v_RKEY number;
  --v_CHANGEKEY number;
begin
  select DESCRIPTION_KEY, DESCRIPTION_TYPE
    into v_KEY, v_TYPE
    from suf_description_tb
   where DESCRIPTION_ID = P_ID;
  if DTYPE = 1 then
    select DESCRIPTION_ID
      into v_RKEY
      from vw_newdescription
     where DESCRIPTION_KEY = v_KEY
       and DESCRIPTION_TYPE = v_TYPE;
    select DESCRIPTION_DES
      into result
      from suf_description_tb
     where DESCRIPTION_ID = v_RKEY;
  else
    select DESCRIPTION_ID
      into v_RKEY
      from vw_latestdescription
     where DESCRIPTION_KEY = v_KEY
       and DESCRIPTION_TYPE = v_TYPE;
    select DESCRIPTION_CHANGE
      into result
      from suf_description_tb
     where DESCRIPTION_ID = v_RKEY;
  end if;
  return(result);
end FC_PU_GETDES;
/

