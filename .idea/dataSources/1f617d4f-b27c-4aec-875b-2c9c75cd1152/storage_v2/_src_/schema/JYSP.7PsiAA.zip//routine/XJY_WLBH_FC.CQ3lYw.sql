CREATE FUNCTION XJY_WLBH_FC(  p_wllb in varchar2,----------物料大类的表名
                                         p_wllbzd in varchar2,-----物料大类的编码字段
                                         p_wlzd in varchar2,----------物料字典表
                                         p_wlzdzd    in varchar2,---------物料字典表的字段
                                         p_bhcd  in number :=3)
 return varchar2 as
 v_sql1 varchar2(4000);
 v_sql2 varchar2(4000);
 v_wlbh varchar2(100);
 v_num  number;
 v_num1  number;
 v_qzcd number;
 begin
  v_sql1 :='select length('||p_wllbzd||')  from '||p_wllb||' where id=90';
  execute immediate  v_sql1  into v_num1;
  v_sql2 :='select nvl(max(substr('||p_wlzdzd||',' ||-p_bhcd|| ',' ||p_bhcd || ')),0) from '||p_wlzd||' where ckid in(1274)';
/*  v_sql := 'select nvl(max(substr(' || p_lm || ',' || -p_hzcd || ',' ||
           p_hzcd || ')),0)+1 from ' || p_tb ||
           ' where to_char(zdrq,''yyyymmdd'')=to_char(sysdate,''yyyymmdd'')
           and instr(' || p_lm || ',''' || p_qz || ''')>0';*/
  
  EXECUTE IMMEDIATE v_sql2 INTO v_num; 
    v_wlbh :=v_num||v_num1;
    /*v_wlbh:=p_qz||v_rq||lpad(v_num, p_hzcd, '0');*/

  return v_wlbh;
EXCEPTION
  WHEN OTHERS THEN
    return '生成物料编号出错';
end XJY_WLBH_FC;
/

