CREATE function get_flowpath_hischkcomment_fc(p_tacheid number,
                                                         p_objid   number)
  return varchar2 is
  Result varchar2(4000);
  cursor c_his is
    select hischkcomment
      from oa_history_tb
     where tacheid = p_tacheid
       and hiscodes = p_objid
     order by hischktime desc;
begin
  open c_his;
  fetch c_his
    into Result;
  close c_his;
  return(Result);
end get_flowpath_hischkcomment_fc;


/

