CREATE VIEW WLXCKRMTMX_VW AS
  select KCCKD1.YWRQ YF,
KCCKD1.DJLXID DJLXID,
KCCKD1.DJBH DJBH,
KCCKD2.WLID wlid,
KCCKD2.yszzid yszzid,--物流箱ID
KCCKD2.Sysl sysl,--出库数量
KCCKD2.Hssl HSSL,--回收数量
kcckd1.zdrid ZDRID,--制单人ID
wlzd.wllbid wllbid
  from KCCKD2_TB KCCKD2
  left join KCCKD1_TB KCCKD1 on kcckd2.fid = kcckd1.id
  left join wlzd_tb wlzd on wlzd.id=kcckd2.wlid
  left join wllb_tb wllb on wllb.id=wlzd.wllbid
  where kcckd1.djzt=1
/

