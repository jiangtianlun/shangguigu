CREATE VIEW GB_YLGZ_VW AS
  select a."ID",a."RQ",a."WLID",a."GYSID",a."SL",a."RKRID",a."RKPH",b.ckrq as ylckrq,v1.gysmc,b.cksl as ylcksl,b.scph,c.cpid,c.rkrq as cprkrq,c.rksl as cprksl,d.cksl as cpcksl,d.ckrq as cpckrq,d.khid,v2.khmc from GB_ylrk_tb a left join GB_ylck_tb b on b.rkph=a.rkph
 left join GB_cprk_tb c on b.scph=c.scph
left join GB_cpck_tb d on d.scph=c.scph
left join GB_gyszd_tb v1 on a.gysid=v1.id
left join GB_khzd_tb v2 on d.khid=v2.id
/

