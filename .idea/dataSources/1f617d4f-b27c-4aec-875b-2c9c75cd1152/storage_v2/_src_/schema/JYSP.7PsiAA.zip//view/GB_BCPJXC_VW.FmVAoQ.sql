CREATE VIEW GB_BCPJXC_VW AS
  select bcpid,scph,jldwid,ckid,jin,chu,nvl(jin,0)-nvl(chu,0) as ye from
(select bcpid,scph,jldwid,ckid,sum(jin)jin,sum(chu)chu from
(select bcpid,scph,jldwid,ckid,case when jc=0 then sl else null end as jin,case when jc=1 then sl else null end as chu from gb_bcpck_tb)t
group by bcpid,scph,jldwid,ckid)a order by ckid,scph desc,bcpid
/

