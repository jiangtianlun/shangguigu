CREATE procedure INSERT_CGQGD2_SP(p_fid in number,p_num in number)
as
----Wy.PU21501新增1行
 v_num number:= p_num;
begin
loop
exit when v_num < 1;
insert into CGQGD2_TB(ID,FID) SELECT SEQCGQGD2.NEXTVAL,p_fid FROM DUAL;
v_num := v_num -1;
end loop;
end INSERT_CGQGD2_SP;
/

