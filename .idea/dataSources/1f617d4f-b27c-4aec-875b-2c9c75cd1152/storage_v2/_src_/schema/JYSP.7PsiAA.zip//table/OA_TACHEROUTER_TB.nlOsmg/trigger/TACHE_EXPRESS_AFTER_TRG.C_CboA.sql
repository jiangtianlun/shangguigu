CREATE TRIGGER TACHE_EXPRESS_AFTER_TRG
  AFTER INSERT OR UPDATE OR DELETE
  ON OA_TACHEROUTER_TB
  declare
  cursor tacherouter_cursor is
    select *
      from oa_tacherouter_tb
     where tacheid = data_tacheid.tacheid
     order by expressid;
  v_expression varchar2(200);
begin
  for tacherouter_rec in tacherouter_cursor loop
    --modify cwm 091109 begin
    if tacherouter_rec.EXPRESS is not null then
      v_expression := v_expression || tacherouter_rec.EXPRESS || ',' ||
                      tacherouter_rec.NEXTTACHENO || ';';
    else
      v_expression :=  v_expression || tacherouter_rec.NEXTTACHENO || ';';  
    end if;    
  --modify cwm 091109 end             
    exit when tacherouter_cursor%notfound;
  end loop;  
  select trim(trailing ';' from v_expression) into v_expression from dual;  --modify cwm 091109
  update oa_tache_tb
     set TACHEEXPRESSION = v_expression
   where tacheid = data_tacheid.tacheid;
end tache_express_after_trg;

/

