CREATE VIEW XJXCKCJY_VW AS
  SELECT WLID,
       BYJC,
       SSSL,
       SFSL,
       BYJC + SSSL - SFSL BYJY,
       YF,
       CKID,
       GYSID,
       PCH,
       HWHID
  FROM (SELECT WLID,
               SUM(BYJC) BYJC,
               SUM(SSSL) SSSL,
               SUM(SFSL) SFSL,
               YF,
               CKID,
               GYSID,
               PCH,
               HWHID
          FROM (
                -------每月库存结余表的批次号、货位号的剩余数量
                select KCJY.WLID WLID,
                       NVL(KCJY.QCKC,0) BYJC,
                        0 SSSL,
                        0 SFSL,
                        to_char(KCJY.YWRQ,'yyyymm') YF,
                        WLZD.CKID CKID,--20171115徐文豪 取物料字典表中的ckid
                        KCJY.GYSID GYSID,
                        KCJY.pch,
                        KCJY.hwhid
                  from kcjy_tb kcjy
                  LEFT JOIN WLZD_TB WLZD ON KCJY.WLID=WLZD.ID
                ------每月库存入库的批次号、货位的数量(加上)
                union all
                select rkd2.wlid wlid,
                       0 BYJC,
                       nvl(rkd2.sssl, 0) SSSL,
                       0 SFSL,
                       TO_CHAR(rkd1.YWRQ, 'YYYYMM') YF,
                       WLZD.CKID CKID,
                       rkd2.gysid gysid,
                       rkd2.pch pch,
                       rkd2.hwhid hwhid
                  from kcrkd1_tb rkd1
                  left join kcrkd2_tb rkd2 on rkd1.id = rkd2.fid
                  LEFT JOIN WLZD_TB WLZD ON RKD2.WLID = WLZD.ID
                 where rkd1.djzt = 1
                union all
                ---------每月库存出库的批次号、货位号的数量（减去）
                select ckd2.wlid wlid,
                       0 BYJC,
                       0 SSSL,
                       nvl(ckd2.sfsl, 0) SFSL,
                       TO_CHAR(ckd1.YWRQ, 'YYYYMM') YF,
                       WLZD.CKID CKID,
                       ckd2.gysid gysid,
                       ckd2.pch pch,
                       ckd2.hwhid hwhid
                  from kcckd1_tb ckd1
                  left join kcckd2_tb ckd2 on ckd1.id = ckd2.fid
                  LEFT JOIN WLZD_TB WLZD ON CKD2.WLID = WLZD.ID
                 /*where ckd1.djzt =1  暂时不用*/
                 )
         GROUP BY WLID, YF, CKID, GYSID, PCH, HWHID)
 ORDER BY yf asc
/

