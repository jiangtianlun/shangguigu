CREATE VIEW VW_PU_DIFFSTAT_DL AS
  select --rownum as DXH,
       vm.U_NAME as DMENUNAME,
       vm.U_LINK as DMENUURL,
       '' as DMENUTYPE,
       sp.pu_bm as DPUBM,
       sp.pu_name as DPUNAME,
       FC_PU_GETDES((select DESCRIPTION_ID
                      from suf_description_tb
                     where DESCRIPTION_KEY = sp.pu_bm
                       and DESCRIPTION_TP = 4
                       and DESCRIPTION_TYPE = 1),
                    1) as DPUDES,
       FC_PU_GETDES((select DESCRIPTION_ID
                      from suf_description_tb
                     where DESCRIPTION_KEY = sp.pu_bm
                       and DESCRIPTION_TP = 4
                       and DESCRIPTION_TYPE = 1),
                    2) as DPUCHANGE,
       decode(vpd.DTYPE,
              0,
              '网格控件',
              1,
              '卡片控件',
              2,
              '网格数据域',
              3,
              '卡片数据域') as DTYPE,
       decode(vpd.DTYPE,
              0,
              (select CROL_NAME || '[' || CROL_TEXT || ']'
                 from suf_control_tb
                where CROL_BM = vpd.DKEY),
              1,
              (select CROL_NAME || '[' || CROL_TEXT || ']'
                 from suf_control_tb
                where CROL_BM = vpd.DKEY),
              2,
              (select FLD_KEY || '[' || FLD_DISPTEXT || ']'
                 from suf_field_tb
                where FLD_BM = vpd.DKEY),
              3,
              (select FLD_KEY || '[' || FLD_DISPTEXT || ']'
                 from suf_field_tb
                where FLD_BM = vpd.DKEY)) as DNAME,
       FC_PU_GETDES(vpd.DID, 1) as DDES,
       FC_PU_GETDES(vpd.DID, 2) as DCHANGE
  from vw_menu_pu vm, vw_pu_diffstatistical vpd, suf_programunit_tb sp
 where vpd.PU = sp.pu_bm(+)
   and sp.pu_bm = vm.PU(+)
   and vpd.DTYPE != 4
   and vpd.DDATE > pkg_session.get_val_date('P_STA')
   and vpd.DDATE <= pkg_session.get_val_date('P_END')
   and FC_PU_MENUCHECK(vm.MENU_ID, pkg_session.get_val('P_MENU')) = 1
/

