CREATE procedure saveActionandStyle(cid    in number,
                                               cpic   in varchar2,
                                               cclick in varchar2--,
                                             /*  dclick in varchar2,
                                               cfloat in varchar2*/) is

  v_click  number := to_number(cclick);
 /* v_dclick number := to_number(dclick);
  v_float  number := to_number(cfloat);*/
  v_pic    varchar2(200) := cpic;
  -- 暂时样式就是图片路径问题
  cursor cur_style_pic is
  -- select asset_id from ko_class_style_tb where class_id = cid;
    select asset_source
      from ko_asset_tb t
     where exists (select *
              from ko_class_style_tb
             where class_id = cid
               and t.asset_id = asset_id);
  --  类的单击路径
  cursor cur_act_cclick is
    select asset_id
      from ko_class_action_tb
     where class_id = cid
       and class_action_type = 1;
 /* cursor cur_act_dclick is
    select asset_id
      from ko_class_action_tb
     where class_id = cid
       and class_action_type = 3;
  cursor cur_act_cfloat is
    select asset_id
      from ko_class_action_tb
     where class_id = cid
       and class_action_type = 2;*/

  cur_record_c cur_act_cclick%rowtype;
 /* cur_record_f cur_act_cfloat%rowtype;
  cur_record_d cur_act_dclick%rowtype;*/
  cur_record_p cur_style_pic%rowtype;
begin

  open cur_style_pic;
  loop
    fetch cur_style_pic
      into cur_record_p;
    if cur_style_pic%rowcount > 0 then
      update ko_asset_tb
         set asset_source = v_pic
       where asset_id in
             (select asset_id from ko_class_style_tb where class_id = cid);
    else
      insert into ko_asset_tb
        (asset_id, asset_name, asset_type, asset_source)
      values
        (seqko_asset.nextval, '图片路径', 4, v_pic);
        insert into ko_class_style_tb
          (class_style_id, class_style_name, asset_id, class_id)
        values
          (seqko_class_style.nextval, 'path', seqko_asset.currval, cid);
    end if;
   exit when cur_style_pic %notfound;
  end loop;
  close cur_style_pic;
-----------------------------------------------------------------------
  open cur_act_cclick;
  loop
    fetch cur_act_cclick
      into cur_record_c;
    exit when cur_act_cclick%notfound;
  end loop;

  if cur_act_cclick%rowcount > 0 then
    update ko_class_action_tb
       set asset_id = v_click
     where class_id = cid
       and class_action_type = 1;
  else
    insert into ko_class_action_tb
      (class_action_id,
       class_id,
       class_action_name,
       class_action_type,
       asset_id)
    values
      (seqko_class_action.nextval, cid, '鼠标点击', 1, v_click);
  end if;
  close cur_act_cclick;
  --------------------------------------------------
  /*open cur_act_cfloat;
  loop
    fetch cur_act_cfloat
      into cur_record_f;
    exit when cur_act_cfloat%notfound;
  end loop;

  if cur_act_cfloat%rowcount > 0 then
    update ko_class_action_tb
       set asset_id = v_float
     where class_id = cid
       and class_action_type = 2;
  else
    insert into ko_class_action_tb
      (class_action_id,
       class_id,
       class_action_name,
       class_action_type,
       asset_id)
    values
      (seqko_class_action.nextval, cid, '鼠标浮动', 2, v_float);
  end if;
  close cur_act_cfloat;
  ------------------------------------------------------------
  open cur_act_dclick;
  loop
    fetch cur_act_dclick
      into cur_record_d;
    exit when cur_act_dclick%notfound;
  end loop;

  if cur_act_dclick%rowcount > 0 then
    update ko_class_action_tb
       set asset_id = v_dclick
     where class_id = cid
       and class_action_type = 3;
  else
    insert into ko_class_action_tb
      (class_action_id,
       class_id,
       class_action_name,
       class_action_type,
       asset_id)
    values
      (seqko_class_action.nextval, cid, '鼠标双击', 3, v_dclick);
  end if;
  close cur_act_dclick;*/

  /*select * from ko_class_action_tb where class_id = cid;
  select * from ko_class_style_tb where class_id = cid;*/

end saveActionandStyle;
/

