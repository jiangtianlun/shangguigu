CREATE VIEW KCYB_VW AS
  select wlid,wl.ckid,sum(sssl) rksl,sum(sfsl) cksl,to_char(sysdate, 'yyyy') nf,to_char(sysdate, 'mm') yf
from
--徐文豪2017-11-11,提取当月的成品零件总入库和总出库数量
(select ck2.wlid, null sssl, ck2.sfsl
          from kcckd1_tb ck1
          left join kcckd2_tb ck2 on ck1.id = ck2.fid
         where ck1.djzt=1 and ck1.ywrq between trunc(sysdate, 'mm')
                        and last_day(trunc(sysdate))
        union all
        select rk2.wlid, rk2.sssl sl, null sfsl
          from kcrkd1_tb rk1
          left join kcrkd2_tb rk2 on rk1.id = rk2.fid
        where rk1.djzt=1 and rk1.ywrq between trunc(sysdate, 'mm')
                       and last_day(trunc(sysdate))
)bykcyb,  wlzd_tb wl
 where wl.ckid in (1273, 1257)
   and bykcyb.wlid = wl.id
group by bykcyb.wlid, wl.ckid
/

