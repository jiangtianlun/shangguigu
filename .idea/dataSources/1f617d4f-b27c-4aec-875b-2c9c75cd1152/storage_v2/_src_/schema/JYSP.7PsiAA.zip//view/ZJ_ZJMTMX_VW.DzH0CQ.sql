CREATE VIEW ZJ_ZJMTMX_VW AS
  select ID,
       BZID,
       LJID,
       nvl(SL, 0) sl,
       nvl(FXS, 0) fxs,
       nvl(FXHGS, 0) fxhgs,
       nvl(BFBHGS, 0) BFBHGS,
       CZZ,
       SCRQ,
       GXZDID,
       GXXH
  from ZJ_CPJYJL_TB ZJ_CPJYJL
 WHERE DJZT = 1
/

