CREATE VIEW ZJ_ZJMYMX_VW AS
  SELECT LJID,
       LJMC,
       WLBH,
       BZID,---------终检记录表每月
       SUM(SL) SL,
       SUM(FXS) FXS,
       SUM(bfbhgs) bfbhgs,
       YF
  FROM (select ZJJL.LJID LJID,
               WLZD.WLMC LJMC,
               WLZD.WLBH WLBH,
               ZJJL.BZID BZID,
               nvl(zjjl.sl, 0) sl,
               nvl(zjjl.fxs, 0) fxs,
               nvl(zjJL.Bfbhgs, 0) bfbhgs,
               to_char(scrq, 'yyyymm') YF
          from zj_cpjyjl_tb ZJJL
          LEFT JOIN WLZD_TB WLZD ON ZJJL.LJID = WLZD.ID
         WHERE ZJJL.DJZT = 1)
 GROUP BY grouping sets((LJID, LJMC, WLBH, BZID, YF),BZID,NULL)
 order by bzid asc
/

