CREATE TYPE "T_DICOBJECT"                                                                                                                                                                                                                                                                            as object(
 name varchar2(2000),
 id varchar2(2000)
 )
/

