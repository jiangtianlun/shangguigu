CREATE VIEW AUTH_MENU_PU_VIEW AS
  select substr(substr(U_LINK || '&', instr(upper(U_LINK), 'PU=') + 3),
              0,
              instr(substr(U_LINK || '&', instr(upper(U_LINK), 'PU=') + 3),
                    '&') - 1) as PU,
       mu."MENU_ID",
       mu."MENU_ID_SUPERIOR",
       mu."U_NO",
       mu."U_NAME"||'['||substr(substr(U_LINK || '&', instr(upper(U_LINK), 'PU=') + 3),
              0,
              instr(substr(U_LINK || '&', instr(upper(U_LINK), 'PU=') + 3),
                    '&') - 1)||']' U_NAME,
       mu."U_LINK",
       mu."U_VALIDATE",
       mu."U_NAME_FULL",
       mu."U_LEVEL",
       mu."U_PATH",
       mu."MODULEID",
       mu."U_MEMO",
       mu."U_ORDER"
  from auth_menu_tb mu
 where upper(u_link) like '%PU=%'
union
select null as PU,
       mu."MENU_ID",
       mu."MENU_ID_SUPERIOR",
       mu."U_NO",
       mu."U_NAME",
       mu."U_LINK",
       mu."U_VALIDATE",
       mu."U_NAME_FULL",
       mu."U_LEVEL",
       mu."U_PATH",
       mu."MODULEID",
       mu."U_MEMO",
       mu."U_ORDER"
  from auth_menu_tb mu
 where upper(nvl(u_link, 'aa')) not like '%PU=%'
/

