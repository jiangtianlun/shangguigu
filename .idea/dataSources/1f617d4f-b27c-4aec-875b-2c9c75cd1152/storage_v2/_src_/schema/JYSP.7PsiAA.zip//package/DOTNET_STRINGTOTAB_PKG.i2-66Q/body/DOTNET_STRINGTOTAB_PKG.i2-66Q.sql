CREATE package body DOTNET_STRINGTOTAB_PKG is
--
--1
FUNCTION GET_TAB_FC (P_STR IN VARCHAR2, P_DELIMITER IN VARCHAR2)
    RETURN t_dic_table
is
    str_split t_dic_table := t_dic_table ();

BEGIN
    -- 枚举，";" 分隔的
    IF P_DELIMITER = ';' THEN
        str_split  := GET_TAB_2_FC (P_STR , P_DELIMITER );
    -- SQL语句
    else
        str_split  := GET_TAB_1_FC (P_STR);
    END IF;

    RETURN str_split;

END GET_TAB_FC;
/*........................*/
--2 SQL语句
FUNCTION GET_TAB_1_FC (P_STR IN VARCHAR2)
    RETURN t_dic_table
is
    type cur1 is ref cursor;
    acur cur1;
    str_split t_dic_table := t_dic_table ();
    vT_ROW T_ROW;
BEGIN
     open acur for p_str;
     loop
         fetch acur into vT_ROW ;
     exit when acur%notfound;
         str_split.EXTEND;
         str_split (str_split.COUNT) := t_dicobject(vT_ROW.NAME,vT_ROW.ID);
     end loop;

    RETURN str_split;

END GET_TAB_1_FC;
/*........................*/
--3 枚举，";" 分隔的
FUNCTION GET_TAB_2_FC (P_STR IN VARCHAR2, P_DELIMITER IN VARCHAR2)
    RETURN t_dic_table
is
    j INT := 0;
    i INT := 1;
    len INT := 0;
    len1 INT := 0;
    str VARCHAR2 (4000);
    str_split t_dic_table := t_dic_table ();
    vT_ROW T_ROW;
BEGIN

    len := LENGTH (p_str);
    len1 := LENGTH (p_delimiter);

    WHILE j < len
    LOOP
        j := INSTR (p_str, p_delimiter, i);

        IF j = 0
        THEN
            j := len;
             str := SUBSTR (p_str, i);
             str_split.EXTEND;
             vT_ROW:=GET_RECORD_FC(str,',');
             str_split (str_split.COUNT) := t_dicobject(vT_ROW.NAME,vT_ROW.ID);

            IF i >= len
            THEN
                EXIT;
            END IF;
        ELSE
            str := SUBSTR (p_str, i, j - i);
            i := j + len1;
            str_split.EXTEND;
            vT_ROW:=GET_RECORD_FC(str,',');
            str_split (str_split.COUNT) := t_dicobject(vT_ROW.NAME,vT_ROW.ID);
        END IF;
    END LOOP;

    RETURN str_split;
END GET_TAB_2_FC;
/*........................*/
--4
FUNCTION GET_RECORD_FC  (p_str IN VARCHAR2, p_delimiter IN VARCHAR2)
    RETURN T_ROW
is
    j INT := 0;
    i INT := 1;
    len INT := 0;
    len1 INT := 0;
    str VARCHAR2 (4000);
    str_split T_ROW ;

BEGIN
    len := LENGTH (p_str);
    len1 := LENGTH (p_delimiter);


        j := INSTR (p_str, p_delimiter, i);

        IF j = 0
        THEN
            j := len;
             str := SUBSTR (p_str, i);
             str_split.id := 1;
             str_split.NAME:= str;
        ELSE
            str := SUBSTR (p_str, i, j - i);
            i := j + len1;
            --str_split.id := to_number(str);
            str_split.id := str;
            str_split.NAME:=SUBSTR (p_str, i);
        END IF;


    RETURN str_split;
END GET_RECORD_FC;
/*........................*/

end DOTNET_STRINGTOTAB_PKG;
/

