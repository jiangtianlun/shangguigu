CREATE VIEW XJYCHGL_VW AS
  select BZID,
       ljid,
       sum(sl) SCZS,
       sum(nvl(BFSL, 0)) BFSL,
       round(((sum(nvl(SL,0))-sum(nvl(BFSL,0)))/sum(SL)),3) YCHGL,
       to_char(scrq, 'yyyymm') NFYF
  from ZJ_XJJL1_TB
 group by BZID, to_char(scrq, 'yyyymm'), ljid
/

