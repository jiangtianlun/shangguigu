CREATE VIEW CGYCLYJHHJ_JHSLFJ_VW AS
  with t as (select distinct dy.wlid wlid,
             yjh.jhsl*dy.pbgx jhyclsl,
             yjh.jhsl jhsl,
             dy.fjlx fjlx,dy.ljid ljid,
             dy.kuan kuan,
             yjh.nfyf nfyf
             from scyjh_tb yjh
             left join ljwldy_tb dy on yjh.ljid=dy.ljid
             --where nfyf=201706
             where yjh.sjsl>0
             and yjh.jhsl>0
             and dy.sfyx=1
             and dy.ljlx=0
             and yjh.djlx=1)--djlx=1为月计划单
 /*t为零件计划数量*配比关系分解出来的结果，有两部分：零件到原材料，零件到半成品*/
 select sum(sl) jhslfj,wlid,nfyf from(
 /*fjlx = 0,零件到原材料*/
 select sum(case
              when wl.jldwid = 1 then
               ceil(kuan * 0.001 * jhyclsl)
              else
               ceil(jhyclsl)
            end) sl,
        t.wlid,
        t.nfyf
   from t
   left join wlzd_tb wl on t.wlid = wl.id
  where t.fjlx = 0
  group by t.wlid,wl.jldwid,t.nfyf
  union all
  /*fjlx = 1,零件到半成品*/
            select sum(case
                         when wl.jldwid <> 1 then
                          jhyclsl
                         else
                          ceil(zh.xs * 0.001 * jhyclsl)--20170604kuan->zh.xs
                       end) sl,
                   zh.cgwlid wlid,
                   t.nfyf
              from t
              left join wlzhdy_tb zh on t.wlid = zh.scwlid
              left join wlzd_tb wl on zh.cgwlid = wl.id
             where t.fjlx = 1
               and zh.sfyx = 1
             group by zh.cgwlid,t.nfyf
) group by wlid,nfyf
/

