CREATE function trig_create_fc (tabname varchar2,
                                              usrname varchar2,
                                                 dblink_name varchar2)

  ----------------------------------------------------------------------------------------------
      --create by fanchengwei on 2010-1-6
        --for security item    using create a distribution trigger
  ----------------------------------------------------------------------------------------------
  return varchar2 is
  usr_name varchar2(32 char) := upper(usrname);
  tab_name varchar2(32 char) := upper(tabname);
  trg_name varchar2(32 char) := replace(tab_name,'_TB','_TRG');
  pk_col_name varchar2(32 char);
  dblink_str varchar(33 char) := '@' || dblink_name;

  trg_start varchar2(32767 byte) := 'create or replace trigger ' || trg_name
                                    || chr(10) || 'after insert or update or delete on ' ||
                                    tab_name || chr(10) || 'for each row' ||
                                    chr(10) || 'begin' || chr(10);
  del_str varchar2(32767 byte);
  updt_str varchar2(32767 byte);
  updt_tmp_str varchar2(4000 byte);
  ins_str varchar2(32767 byte);
  ins_col_nm_str varchar2(4000 byte);
  ins_col_val_str varchar2(4000 byte);

  trg_end varchar2(100 char) := chr(10) || 'end ' || trg_name || ';';

  type tab_col_type is table of varchar2(128 char) index by binary_integer;
  tab_col_var tab_col_type;

  Result clob;

  begin

       select column_name bulk collect into tab_col_var from user_tab_columns
        where table_name = tab_name;

       select column_name into pk_col_name from user_constraints a,user_cons_columns b
        where a.constraint_name = b.constraint_name and b.owner = usr_name
          and b.table_name = tab_name and a.table_name= tab_name and a.constraint_type = 'P';
    -------------------------------- create delete string  --------------------------------------------
       del_str := 'if deleting then' || chr(10) || 'delete from '
                  || tab_name || dblink_str || ' where ' || pk_col_name || ' = :old.'|| pk_col_name
                  || ';' || chr(10) || 'end if ;' ;
    -------------------------------- create update string  --------------------------------------------
         for i in 1 .. tab_col_var.count loop
          updt_tmp_str := updt_tmp_str || ' ' || tab_col_var(i) || ' = :new.'||tab_col_var(i) || ',';
         end loop;
         
          updt_tmp_str := rtrim(updt_tmp_str,',');
       updt_str := 'if updating then' || chr(10) || 'update '
                   || tab_name || dblink_str ||' set ' || updt_tmp_str || ' where '
                   || pk_col_name || ' = :old.'|| pk_col_name|| ';' || chr(10) || 'end if ;' ;

         for i in 1 .. tab_col_var.count loop
          ins_col_nm_str := ins_col_nm_str || tab_col_var(i) || ', ' ;
          ins_col_val_str := ins_col_val_str || ' :new.'||tab_col_var(i) || ',' ;
         end loop;

          ins_col_nm_str := rtrim(ins_col_nm_str,', ');
          ins_col_val_str := rtrim(ins_col_val_str,',');
     -------------------------------- create insert string  --------------------------------------------
        ins_str := 'if inserting then' || chr(10) || 'insert into '
                   || tab_name || dblink_str || ' (' || ins_col_nm_str || ')'
                   || ' values (' || ins_col_val_str || ') ;' || chr(10) || 'end if ;' ;

        result := trg_start || del_str || chr(10) || updt_str || chr(10) || ins_str || trg_end ;

     return(Result);

  end trig_create_fc ;
/

