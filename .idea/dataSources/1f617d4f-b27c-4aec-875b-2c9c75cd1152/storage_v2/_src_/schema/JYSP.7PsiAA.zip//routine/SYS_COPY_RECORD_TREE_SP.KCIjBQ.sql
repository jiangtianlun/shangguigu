CREATE procedure sys_copy_record_tree_sp(
           p_table_name varchar2,
           p_bm number,
    --       p_new_bm out number,
           p_tree_level  number :=1,
           p_father_talbe varchar2:=null,
           p_father_bm number:=null) is
 --2006.3.28 created by tangfeng   --复制记录树过程
 --注: 此为递归过程,当第一次调用时请不要给有默认值的参数赋值,或者赋默认值
 --    树中的表必须有唯一主键,不能是联合主键
 --调用方法: 1. copy_record_tree('tablename',3,v_newbm) ;
          -- 2. copy_record_tree('tablename',3,v_newbm,1,null,null)
 v_tablename varchar2(100):=trim(upper(p_table_name));
 v_pkbm number:=p_bm;
 v_treelevel number:=p_tree_level;
 v_fathertable varchar2(100):=trim(upper(p_father_talbe));
 v_fatherbm number:=p_father_bm;
 --临时变量声明---------
 v_pk_field varchar2(100);
 v_fk_field varchar2(100);
 v_other_field varchar2(100);
 v_fields varchar2(1000);
 v_seqvalue number;
 v_sql varchar2(4000);
 v_sontable varchar2(100);
 v_sonfk_field varchar2(100);
 v_sonpk_field varchar2(100);
 v_sonid number;

 v_outid number;

 ---游标声明--------------
 type ref_cur is REF CURSOR;
 cur_son_recs ref_cur;

 cursor find_pk_field(var_tablename varchar2) is
   select col.column_name
   from user_cons_columns col,
        user_constraints con
   where col.constraint_name=con.constraint_name
         and con.constraint_type='P'
         and col.table_name=var_tablename;

 cursor find_fk_field(var_father varchar2,var_son varchar2) is
    select col.column_name
    from user_constraints fkcon,user_constraints pkcon,user_cons_columns col
    where  fkcon.constraint_type='R' and fkcon.table_name=var_son
        and fkcon.r_constraint_name=pkcon.constraint_name
        and pkcon.table_name=var_father
        and fkcon.constraint_name=col.constraint_name;

 cursor find_other_field(var_father varchar2,var_son varchar2)  is
   select cols.COLUMN_NAME
    from user_tab_columns cols
    where cols.TABLE_NAME=var_son
    minus
    select col.column_name
       from user_cons_columns col,
            user_constraints con
       where col.constraint_name=con.constraint_name
             and con.constraint_type='P'
             and col.table_name=var_son
    minus
    select col.column_name
        from user_constraints fkcon,user_constraints pkcon,user_cons_columns col
        where  fkcon.constraint_type='R' and fkcon.table_name=var_son
            and fkcon.r_constraint_name=pkcon.constraint_name
            and pkcon.table_name=var_father  --此值可能为空,空表示取树根表字段
            and fkcon.constraint_name=col.constraint_name;

 cursor find_sontable(v_tablename varchar2) is
   select
       a.table_name,
       (select col.column_name from user_cons_columns col
        where col.constraint_name=a.constraint_name),
       (select col.column_name from user_cons_columns col,user_constraints con
        where col.constraint_name=con.constraint_name and con.constraint_type='P'
         and col.table_name=a.table_name)

    from
    (
        select son.table_name,son.constraint_name

        from
        (select con.* from user_constraints con
        where con.table_name=v_tablename and con.constraint_type='P'
        )  father, user_constraints son
        where son.r_constraint_name=father.constraint_name and son.constraint_type='R'
    ) a  ;

 --函数声明--------------
 function func_find_seq(v_tablename varchar2) return varchar2 is
 begin
   return 'seq'||substr(v_tablename,1,length(v_tablename)-3);
 end;

begin
   --找主键
   open find_pk_field(v_tablename);
   fetch find_pk_field into v_pk_field;
   close find_pk_field;

   if v_pk_field is null then
      raise NO_DATA_FOUND;
   end if;
   --找外键, 最顶层树根不执行此操作
   if v_treelevel>1 then
      open find_fk_field(v_fathertable,v_tablename) ;
      fetch find_fk_field into v_fk_field;
      close find_fk_field;
      if v_fk_field is null then
         raise NO_DATA_FOUND;
      end if;
   end if;
   --找其它字段,并且形成字串
   open find_other_field(v_fathertable,v_tablename);
   loop
     fetch find_other_field into v_other_field;
     exit when find_other_field%notfound;
     v_fields:=v_fields || v_other_field ||',';
   end loop;
   close find_other_field;
   if length(v_fields) is not null then
      v_fields:=rtrim(v_fields,',');
   end if;
   --开始插入本表,假定P_BM的记录存在--
   if v_treelevel=1 then
     execute immediate 'select '|| func_find_seq(v_tablename)||'.nextval from dual' into v_seqvalue;
     v_sql:= 'insert into '||v_tablename||'('||v_pk_field||','||v_fields||') '
           ||' select '||to_char(v_seqvalue)||','||v_fields||' from '||v_tablename
           ||' where '||v_pk_field||'='||to_char(v_pkbm);

   else

       execute immediate 'select '|| func_find_seq(v_tablename)||'.nextval from dual' into v_seqvalue;
       v_sql:= 'insert into '||v_tablename||'('||v_pk_field||','||v_fk_field||','||v_fields||') '
             ||' select '||to_char(v_seqvalue)||','||to_char(v_fatherbm)||','||v_fields||' from '||v_tablename
             ||' where '||v_pk_field||'='||to_char(v_pkbm);

   end if;

   execute  immediate v_sql ;

   --递归复制子树--
   open find_sontable(v_tablename);
   loop
      fetch find_sontable into v_sontable,v_sonfk_field,v_sonpk_field;
      exit when find_sontable%notfound;

      v_sql:='select '||v_sonpk_field||' from '||v_sontable||' where '||v_sonfk_field||'='||to_char(v_pkbm);
      open cur_son_recs for v_sql;

      loop
        fetch cur_son_recs into v_sonid;
        exit when cur_son_recs%notfound;
        sys_copy_record_tree_sp(v_sontable,v_sonid,--v_outid,
                       v_treelevel+1,v_tablename,v_seqvalue);

      end loop;
      close cur_son_recs;

   end loop;
   close find_sontable;
   ------------------------------------
   if v_treelevel=1 then
      commit;
 --    p_new_bm:=v_seqvalue;
   end if;

/*   exception
     when others then
        if v_treelevel=1 then
           rollback;
           raise_application_error(-20000,'error occurs,see stack info');
        else
           raise ;
        end if;*/
end;
/

