CREATE VIEW YCLBYKCJY_VW AS
  select WLID,GYSID,CKID,YF,NVL(BQJC,0) BQJC,(nvl(R01,0)+nvl(R02,0)+nvl(R03,0)+nvl(R04,0)+nvl(R05,0)+nvl(R06,0)+nvl(R07,0)+
nvl(R08,0)+nvl(R09,0)+nvl(R10,0)+nvl(R11,0)+nvl(R12,0)+nvl(R13,0)+nvl(R14,0)+
nvl(R15,0)+nvl(R16,0)+nvl(R17,0)+nvl(R18,0)+nvl(R19,0)+nvl(R20,0)+nvl(R21,0)+
nvl(R22,0)+nvl(R23,0)+nvl(R24,0)+nvl(R25,0)+nvl(R26,0)+nvl(R27,0)+nvl(R28,0)+
nvl(R29,0)+nvl(R30,0)+nvl(R31,0)) BYZR,(nvl(C01,0)+nvl(C02,0)+nvl(C03,0)+nvl(C04,0)+nvl(C05,0)+nvl(C06,0)+nvl(C07,0)+
nvl(C08,0)+nvl(C09,0)+nvl(C10,0)+nvl(C11,0)+nvl(C12,0)+nvl(C13,0)+nvl(C14,0)+
nvl(C15,0)+nvl(C16,0)+nvl(C17,0)+nvl(C18,0)+nvl(C19,0)+nvl(C20,0)+nvl(C21,0)+
nvl(C22,0)+nvl(C23,0)+nvl(C24,0)+nvl(C25,0)+nvl(C26,0)+nvl(C27,0)+nvl(C28,0)+
nvl(C29,0)+nvl(C30,0)+nvl(C31,0)) BYZC,(nvl(BQJC,0)+
nvl(R01,0)+nvl(R02,0)+nvl(R03,0)+nvl(R04,0)+nvl(R05,0)+nvl(R06,0)+nvl(R07,0)+
nvl(R08,0)+nvl(R09,0)+nvl(R10,0)+nvl(R11,0)+nvl(R12,0)+nvl(R13,0)+nvl(R14,0)+
nvl(R15,0)+nvl(R16,0)+nvl(R17,0)+nvl(R18,0)+nvl(R19,0)+nvl(R20,0)+nvl(R21,0)+
nvl(R22,0)+nvl(R23,0)+nvl(R24,0)+nvl(R25,0)+nvl(R26,0)+nvl(R27,0)+nvl(R28,0)+
nvl(R29,0)+nvl(R30,0)+nvl(R31,0)-nvl(C01,0)-nvl(C02,0)-nvl(C03,0)-nvl(C04,0)-
nvl(C05,0)-nvl(C06,0)-nvl(C07,0)-
nvl(C08,0)-nvl(C09,0)-nvl(C10,0)-nvl(C11,0)-nvl(C12,0)-nvl(C13,0)-nvl(C14,0)-
nvl(C15,0)-nvl(C16,0)-nvl(C17,0)-nvl(C18,0)-nvl(C19,0)-nvl(C20,0)-nvl(C21,0)-
nvl(C22,0)-nvl(C23,0)-nvl(C24,0)-nvl(C25,0)-nvl(C26,0)-nvl(C27,0)-nvl(C28,0)-
nvl(C29,0)-nvl(C30,0)-nvl(C31,0)) BYJY from yclkc_kcbbmt_vw
/

