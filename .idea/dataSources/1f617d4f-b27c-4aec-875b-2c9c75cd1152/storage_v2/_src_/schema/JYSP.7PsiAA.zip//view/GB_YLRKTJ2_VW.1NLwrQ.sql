CREATE VIEW GB_YLRKTJ2_VW AS
  select a."NY",a."GYSID",a."SL",a."WLID",b.gysbh,b.gysmc as gys,f.wlmc,f.wlgg,b.gysmc||','||f.wlmc||f.wlgg as gysmc from (select ny,gysid,wlid,sum(sl)sl from
(select gysid,sl,to_char(rq,'yyyy-mm') ny,wlid from GB_ylrk_tb)
group by ny,gysid,wlid)a
left join GB_gyszd_tb b on a.gysid=b.id
left join GB_wlzd_tb f on a.wlid=f.id
/

