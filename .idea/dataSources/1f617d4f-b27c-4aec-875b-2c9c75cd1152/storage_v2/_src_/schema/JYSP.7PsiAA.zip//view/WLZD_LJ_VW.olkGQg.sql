create view WLZD_LJ_VW as
select
dy.cartypeid as cartypeid,
wl.id as id,
       wlbh,
       wlmc ，
       lb.lbmc,
       decode(ljid, null, '(没有选中)', '(选中)') || trim(wlmc) || '(' || trim(wlbh) || ')' as ljQC
  from wlzd_tb wl
  left join cartypeljdy_tb dy on wl.id = dy.ljid left join wllb_tb lb on wl.wllbid = lb.id
 where wl.sfyx = 1
   and wl.ckid in (1273)
 order by wlbh
/

