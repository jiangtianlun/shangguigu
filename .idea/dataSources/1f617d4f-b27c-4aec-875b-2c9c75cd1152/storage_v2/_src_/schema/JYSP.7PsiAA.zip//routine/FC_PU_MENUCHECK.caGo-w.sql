CREATE function FC_PU_MENUCHECK(P_ID     in varchar2,
                                           P_MENUID in varchar2)
  return number as
  result number;
begin
  result := 0;
  if P_MENUID = 'null' or P_MENUID is null  or P_MENUID = 'NULL' then
    result := 1;
  elsif instr(',' || P_MENUID || ',', ',' || P_ID || ',') > 0 then
    result := 1;
  end if;
  return(result);
end FC_PU_MENUCHECK;


/

