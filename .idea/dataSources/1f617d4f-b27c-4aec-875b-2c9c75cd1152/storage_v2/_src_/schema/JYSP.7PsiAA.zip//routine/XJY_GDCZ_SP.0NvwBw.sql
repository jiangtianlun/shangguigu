CREATE procedure XJY_GDCZ_SP(p_sTable1  in varchar2, ----------父表
                                         p_sTable_2 in varchar2, ---------子表
                                         p_id       in number,
                                         p_zdrid    in number)
  return number is
  PRAGMA AUTONOMOUS_TRANSACTION; --自治事务
  P_xlh number;
begin
  select seqxstd.KCCKD1 into p_xlh from dual;
  insert into KCCKD1_TB
    (id, DJLXID, DJZT, ZDRQ, zdrid, LYR, BMID, KHID, bz,YWRQ)
    select p_xlh,
           DJLXID,
           0,
           sysdate,
           p_zdrid,
           LYR,
           BMID,
           KHID,
           BZ,
           SYSDATE
      from KCCKD1_TB
     where id = p_id;
  insert into KCCKD2_TB
    (id,
     fid,XSTDMXID,WLID,SFSL,BZ,CKID,CLFS,BLQK
     )
    select seqKCCKD2.nextval,
           p_xlh,
           xshtmxid,
           wlid,
           SFSL,BZ,CKID,CLFS,BLQK
      from KCCKD2_TB
     where fid = p_id;
  update KCCKD1_TB set DJZT=-1 where id = p_id;
  commit;
exception
  when others then
    rollback;
    return - 1;
end XJY_GDCZ_SP;
/

