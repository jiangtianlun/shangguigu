CREATE VIEW XK_MASTER_VW AS
  select id,
       u_name as name,
       u_name_full,
       lastTime,
       lastIp,
       state,
       xk_Master.user_id
  from xk_Master,auth_user_tb
 where xk_Master.User_Id=auth_user_tb.user_id(+)
/

