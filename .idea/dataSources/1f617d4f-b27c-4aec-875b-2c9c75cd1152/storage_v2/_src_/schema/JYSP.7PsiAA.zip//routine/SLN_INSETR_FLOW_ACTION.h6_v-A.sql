CREATE procedure SLN_INSETR_FLOW_ACTION(P_ACTION_ID     NUMBER,
                                                   P_JOIN_ID       NUMBER,
                                                   P_U_TYPE        VARCHAR2,
                                                   P_U_DESCRIPTION VARCHAR2,
                                                   P_U_TIME        DATE) as

  v_count number;
  --v_time  date := to_date(P_U_TIME, 'yyyy-mm-dd hh24:mi:ss');
begin
  /* if (P_ACTION_ID is null) then*/
  select count(1)
    into v_count
    from FLOW_ACTION_TB
   where u_time = (select max(U_TIME) as rq
                     from FLOW_ACTION_TB
                    where u_time <= P_U_TIME --to_date(P_U_TIME, 'yyyy-mm-dd hh24:mi:ss')
                   )
     and join_id = P_JOIN_ID
     and U_TYPE = P_U_TYPE;
  if (v_count = 0) then
    INSERT INTO FLOW_ACTION_TB
      (ACTION_ID, JOIN_ID, U_TYPE, U_DESCRIPTION, U_TIME)
    VALUES
      (SEQFLOW_ACTION.NEXTVAL,
       to_number(P_JOIN_ID),
       to_char(P_U_TYPE),
       to_char(P_U_DESCRIPTION),
       P_U_TIME
       );
  end if;
  /* else
    UPDATE FLOW_ACTION_TB
       SET U_TYPE        = P_U_TYPE,
           U_DESCRIPTION = P_U_DESCRIPTION,
           U_TIME        =P_U_TIME -- to_date(P_U_TIME, 'yyyy-mm-dd hh24:mi:ss')
     WHERE ACTION_ID = P_ACTION_ID
       AND JOIN_ID = P_JOIN_ID;
  
  end if;*/

  commit;
end SLN_INSETR_FLOW_ACTION;
/

