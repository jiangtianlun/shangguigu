CREATE function flow_GetTimeSpan(f_TACHE_ID    in integer,
                                            f_instance_id in integer)
  return integer is
  v          integer := 0;
  v_span     number;
  v_type     number;
  v_tache_no number;
  v_spans    number;
  v_c        number;
begin
  select TACHE_LIMITTM, TACHE_LIMITUNIT, TACHE_NO
    into v_span, v_type, v_tache_no
    from flow_tache_tb
   where TACHE_ID = f_TACHE_ID;

  select sysdate - his_chktime
    into v_spans
    from (select h.his_chktime, rownum rn
            from flow_history_tb h
           where h.tache_no_next = v_tache_no ---
             and h.instance_id = f_instance_id
           order by h.his_chktime desc) t
   where rn = 1; ---

  if v_type = 0 then
    v_c := v_spans;
  elsif v_type = 1 then
    v_c := v_spans * 60;
  elsif v_type = 2 then
    v_c := v_spans * 60 * 60;
  end if;
  return v_c - v_span;
end;
/

