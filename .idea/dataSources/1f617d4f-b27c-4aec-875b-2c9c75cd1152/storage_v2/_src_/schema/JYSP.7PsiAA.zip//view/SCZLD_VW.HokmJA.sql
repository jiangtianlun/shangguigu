CREATE VIEW SCZLD_VW AS
  select bzid, ljid, czz, jyy, scrq, sl, djzt, zdrq, djbh,gxzdid,gxxh
  from sczld_tb
 where djzt = 1
order by zdrq desc
/

