CREATE VIEW GB_SBJYTX_VW AS
  select a."ID",a."SBID",a."JYRQ",a."JYXM",a."JYR",a."JYJL",a."JYDW",a."BZ",a."XCJYRQ",a."XCJY",b.sbbh,b.sbmc,b.sblx,case when XCJYRQ is null then null else Round(xcjyrq-sysdate,3) end as r0,
case when XCJYRQ is not null and (xcjyrq-sysdate<5 and xcjyrq-sysdate>-5 and nvl(XCJY,0)<>1) then 1 else 0 end as r1,nvl(XCJY,0) as r3
 from (select * from GB_SBJYJL_TB where xcjyrq is not null) a left join XC_SBTZ_TB b on a.sbid=b.id
/

