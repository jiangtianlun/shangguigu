CREATE function getModulePicUrl(p_moduleid in number)
  return varchar as
  result      varchar(400);
  p_flowCount number;
begin
  select count(*)
    into p_flowCount
    from oa_flow_tb t
   where t.moduleid = p_moduleid;
  if p_flowCount=0 then
     result:='<a href="../../WorkFlow/FlowPictureExt/WorkFlowChart.aspx?moduleid='||p_moduleid||'" target="_blank">查看流程图</a>';
/*     result:='<a href="../../WorkFlow/DrawFlowPicture/DrawFlowPicture.aspx?moduleid='||p_moduleid||'" target="_blank">查看流程图</a>';*/
  else
     result:='';
     end if;
  return result;
end getModulePicUrl;
/

