CREATE package body SYS_RECORDTREE_DEL_PG is

  procedure DEL_ZB_SP(p_bm number, p_tn varchar2) is
    --2006.08.04 Create by lishiji 删除所有子表记录 参数1 要删除的主表主键,参数2 要删除的主表名称
    cursor c_tn is
      select t.constraint_name as c1,
             t.table_name,
             t3.constraint_name as c3
        from user_constraints t, user_constraints t2, user_constraints t3
       where t.constraint_type = 'R'
         and t.r_constraint_name = t2.constraint_name
         and t2.constraint_type = 'P'
         and t3.constraint_type = 'P'
         and t3.table_name = t.table_name
         and t2.table_name = upper(p_tn);
    v_tn c_tn%rowtype;

    cursor c_ys(c_co varchar2) is
      select r.constraint_name
        from user_constraints r
       where r.r_constraint_name = c_co
         and r.constraint_type = 'R';
    v_ys c_ys%rowtype;

    cursor c_col(c_con varchar2) is --受约束的键明
      select column_name
        from user_cons_columns
       where constraint_name = c_con
         and rownum = 1;

    v_col_ys varchar2(100);
    v_col_zj varchar2(100);

    type cbm is ref cursor;
    c_bm cbm;
    v_bm number;

    v_sql_bm varchar2(1000);
    v_sql    varchar2(1000);
  begin
    open c_tn;
    loop
      fetch c_tn
        into v_tn;
      exit when c_tn%notfound;

      open c_col(v_tn.c1); --得到受约束的键明
      fetch c_col
        into v_col_ys;
      close c_col;

      open c_col(v_tn.c3); --得到主的键明
      fetch c_col
        into v_col_zj;
      close c_col;

      v_sql_bm := 'select ' || v_col_zj || ' from ' || v_tn.table_name ||
                  ' where ' || v_col_ys || ' = ' || p_bm;
      open c_bm for v_sql_bm;
      loop
        fetch c_bm
          into v_bm;
        exit when c_bm%notfound;

        open c_ys(v_tn.c3); --是否继续有引用
        fetch c_ys
          into v_ys;
        if c_ys%notfound or v_bm is null then
          v_sql := 'delete from ' || v_tn.table_name || ' where ' ||
                   v_col_zj || ' =' || to_char(nvl(v_bm, -999));
          /*      insert into clear_log values (v_sql, v_bm, v_sql_bm);*/
          execute immediate v_sql;
        else
          DEL_ZB_SP(v_bm, v_tn.table_name);
          v_sql := 'delete from ' || v_tn.table_name || ' where ' ||
                   v_col_zj || ' =' || to_char(nvl(v_bm, -999));
          execute immediate v_sql;
          /*      insert into clear_log values (v_sql, v_bm, v_sql_bm);*/
        end if;
        close c_ys;

      end loop;
      v_bm := null;
    end loop;
    close c_tn;
    commit;
  end DEL_ZB_SP;
  /*kjfpokefpokfokwapofkawpofkpaokfpoakfpoakpfkpakfpakfpksapfskfp;skpfsapdkf;a,fosakfs,kfoisafd*/
  procedure SYS_RECORDTREE_DEL_SP(p_bm number, p_tn varchar2) is
    v_sql varchar2(1000);
    cursor c_cn is
      select t1.column_name
        from user_constraints t, user_cons_columns t1
       where t.table_name = upper(p_tn)
         and constraint_type = 'P'
         and t.constraint_name = t1.constraint_name;
     v_cn varchar2(30);
  begin

    DEL_ZB_SP(p_bm, p_tn);

    open c_cn;
    fetch c_cn into v_cn;
    if c_cn%found then
    v_sql := 'delete from ' || p_tn || ' where '||v_cn||' = ' || to_char(p_bm);
    execute immediate v_sql;
    commit;
    end if;
    close c_cn;
  end SYS_RECORDTREE_DEL_SP;

end SYS_RECORDTREE_DEL_PG;


/

