CREATE function GETZZLevelsub(P_BM number, P_level number)
  return number is
  Result number;
  v_bm   number;
  cursor v_cs_0(p_0_bm number) is
    select ORG_ID_SUPERIOR from auth_organization_tb where ORG_ID = p_0_bm;
--获取层次，时林OA系统
begin
  open v_cs_0(P_BM);
  fetch v_cs_0
    into v_bm;
  close v_cs_0;
  if v_bm is null then
    Result := P_level;
  else
    Result := GETZZLevelsub(v_bm,P_level + 1);
  end if;
  return(Result);
end GETZZLevelsub;


/

