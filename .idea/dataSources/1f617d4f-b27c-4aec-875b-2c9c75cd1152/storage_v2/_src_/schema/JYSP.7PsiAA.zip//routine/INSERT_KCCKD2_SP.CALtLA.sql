CREATE procedure INSERT_KCCKD2_SP(p_fid in number,p_num in number)
as
----xjy新增几行的意思
 v_num number:= p_num;
begin
loop
exit when v_num < 1;
insert into KCCKD2_TB(ID,FID) SELECT SEQKCCKD2.NEXTVAL,p_fid FROM DUAL;
v_num := v_num -1;
end loop;
end INSERT_KCCKD2_SP;
/

