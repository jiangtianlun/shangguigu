CREATE package body SLNAUTOPKG is
  --////////////////////////获取下拉框所需信息/////////////////////--
  procedure GET_KeyValue(user_id_in       in number,
                         def_table_name   in varchar2,
                         id_column_name   in varchar2,
                         name_column_name in varchar2,
                         result_cursor    out refcursor) is
  
    cursor foundcur is
      select t.sql_string
        from table_path_tb t
       where lower(t.to_tb) = lower(def_table_name);
    sql_string varchar2(4000);
    found_path boolean;
  begin
    open foundcur;
    fetch foundcur
      into sql_string;
    found_path := foundcur%Found;
    close foundcur;
    if found_path then
    
      sql_string := 'select distinct ' || def_table_name || '.' ||
                    id_column_name || ' as RID,' || def_table_name || '.' ||
                    name_column_name || ' as RNAME  ' || sql_string ||
                    user_id_in;
      open result_cursor for sql_string;
    end if;
  end GET_KeyValue;
  --////////////////////////行列转换/////////////////////--
  procedure Row_Column_Convert(sql_string_in in varchar2,
                               sql_query_in  in varchar2,
                               v_query_in    in varchar2,
                               y_col_name    varchar2,
                               x_col_name    varchar2,
                               val_col_name  varchar2,
                               result_cursor out refcursor) is
    from_sql   varchar2(3000);
    select_sql varchar2(1000);
    v_sql      varchar2(4000);
    type col_table_type is table of varchar2(30) index by binary_integer;
    x_col_table     col_table_type;
    x_colname_table col_table_type;
    in_sql_temp     varchar2(2000);
    v_temp          number;
  begin
    v_temp   := instr(upper(sql_string_in), 'FROM');
    from_sql := ' ' || substr(sql_string_in,
                              v_temp,
                              length(sql_string_in) - v_temp + 1);
    from_sql := rtrim(from_sql, ';');
    v_sql    := 'select distinct ' || x_col_name || from_sql;
    execute immediate v_sql bulk collect
      into x_col_table;
  
    if x_col_table.count < 1 then
    /*  result_cursor := null;*/
    open result_cursor for 'select null from dual';
    else
      select replace(sql_query_in, '@1', v_query_in) into v_sql from dual;
      in_sql_temp := '';
      for i in 1 .. x_col_table.count loop
        in_sql_temp := in_sql_temp || '''' || x_col_table(i) || ''',';
      end loop;
    
      in_sql_temp := ' (' || rtrim(in_sql_temp, ',') || ') ';
      select replace(v_sql, '@2', in_sql_temp) into v_sql from dual;
      execute immediate v_sql bulk collect
        into x_colname_table;
    
      select_sql := 'select ' || y_col_name || ' as time,';
      for i in 1 .. x_col_table.count loop
        select_sql := select_sql || 'sum(decode(' || x_col_name || ',''' ||
                      x_col_table(i) || ''',' || val_col_name || ',0)) as ' ||
                      x_colname_table(i) || ',';
      end loop;
      v_sql := rtrim(select_sql, ',') || from_sql || ' group by ' ||
               y_col_name || ' order by ' || y_col_name;
      open result_cursor for v_sql;
    end if;
  end Row_Column_Convert;
  --------------------插入属性-------------------------------------------------
  procedure InsertProperty(p_name in varchar2, p_type in number) is
    cursor cur_found is
      select count(*)
        from ko_property_tb t
       where t.property_name = p_name
         and t.property_type = p_type;
       
         rd_count number;
  begin
    open cur_found ;
    fetch cur_found into rd_count;  
    if rd_count<1 then  
      insert into ko_property_tb
          (property_id, property_name, property_type)
        values
          (seqko_property.nextval, p_name, p_type);
     end if;
  close cur_found;
  end InsertProperty; 
  --///////////////////////////插入对象//////////////////////////////////////////
  procedure InsertObject( cls_id in number,obj_name in varchar2) is
    cursor cur_found is
      select count(*)
        from ko_obj_tb t
       where t.object_name = obj_name
         and t.class_id = cls_id;
    rd_count number;
  begin
    open cur_found;
    fetch cur_found
      into rd_count;
    if rd_count<1 then
      insert into ko_obj_tb
        (object_id, class_id, object_name)
      values
        (seqko_obj.nextval, cls_id, obj_name);
    end if;
    close cur_found;
  end InsertObject;
  --////////////////////插入对象数据/////////////////////////////////////
  procedure InsertObjectData(cls_id   in number,
                             obj_name in varchar2,
                             p_name   in varchar2,
                             val      in varchar2) is
    cursor cur_found is
      select count(*)
        from ko_propdata_tb t
       where t.object_id in (select object_id
                               from ko_obj_tb
                              where object_name = obj_name
                                and class_id = cls_id)
         and t.property_id in
             (select property_id
                from ko_property_tb
               where property_name = p_name);
      
       rd_count number;
  begin
    open cur_found;
    fetch cur_found
      into rd_count;
    if rd_count<1 then
      insert into ko_propdata_tb
        (propdata_id, object_id, property_id, propdata_va)
      values
        (seqko_propdata.nextval,
         (select object_id
            from ko_obj_tb
           where object_name = obj_name
             and class_id = cls_id
             and rownum = 1),
         (select property_id
            from ko_property_tb
           where property_name = p_name
             and rownum = 1),
         val);
    else
      update ko_propdata_tb t
         set propdata_va = val
       where t.object_id in (select object_id
                               from ko_obj_tb
                              where object_name = obj_name
                                and class_id = cls_id)
         and t.property_id in
             (select property_id
                from ko_property_tb
               where property_name = p_name);
    end if;
    close cur_found;
  end InsertObjectData;
  --////////////////删除所有对象数据//////////////////////-----
  procedure DeleClassObjPropAll 
  is
  begin
    delete from ko_class_action_tb;
    delete from ko_class_style_tb;
    delete from ko_class_property_tb;
    delete from ko_property_group_tb;
    delete from ko_propdata_tb ;
    delete from ko_property_tb;
    delete from ko_obj_action_tb;
    delete from ko_obj_tb;
    delete from ko_class_tb;
  end DeleClassObjPropAll;
  -----------////////////////////////////////------------------
procedure CreateGraphicBase(pu in varchar2, cid out varchar2) is

  p_u varchar2(100) := pu;

  cursor cur_class is
    select * from suf_programunit_tb u where u.pu_bm = p_u;

  cur_clas_rd cur_class%rowtype;

begin
  open cur_class;
  fetch cur_class
    into cur_clas_rd;
  if cur_class %found then
    insert into ko_class_tb
      (class_id, class_name, u_state)
    values
      (seqko_class.nextval, cur_clas_rd.pu_name, p_u);
  end if;
  select max(class_id) into cid from ko_class_tb;
  close cur_class;

end CreateGraphicBase;
  
end SLNAUTOPKG;
/

