CREATE PROCEDURE IMPORT_WLJC_SP(P_IMPTASK_BM IN NUMBER) IS
  CURSOR CUR_IMPDATA IS
    SELECT C03 LJH, ---零件号
           C04 LJMC, ---零件名称
           C05 JCS, ---结存数          
           C06 BZ  ---备注
           
      FROM ZX_SWAPDATA_TB T
     WHERE T.IMPTASK_BM = P_IMPTASK_BM;
  V_LJ  CUR_IMPDATA%ROWTYPE;
  V_CNT NUMBER;
  /* v_wl_cnt NUMBER;
  v_LJID NUMBER;
  V_ZFID number;*/
BEGIN
  SAVEPOINT V_SP_0000;
  /*SELECT TEMPADDITION  INTO V_ZFID FROM ZX_SWAPDATA_VW;*/
  OPEN CUR_IMPDATA;
  LOOP
    FETCH CUR_IMPDATA
      INTO V_LJ;
    EXIT WHEN CUR_IMPDATA%NOTFOUND;
    SELECT COUNT(1)
      INTO V_CNT
      FROM YS_WLJC_TB
     WHERE TRIM(LJH) = TRIM(V_LJ.LJH);
       /*AND TRIM(JHRQ) = TRIM(V_LJ.JHRQ)
       and fid = V_ZFID;*/
    /*select count(id)
      into v_wl_cnt
      from WLZD_TB
     where trim(WLBH) = trim(V_LJ.LJBH);
    if v_wl_cnt = 1 then
      select id
        into V_LJID
        from WLZD_TB
       where trim(WLBH) = trim(V_LJ.LJBH);
    else
      V_LJID := -1;
    end if;*/
    IF V_CNT = 0 THEN
      INSERT INTO YS_WLJC_TB
        (ID, LJH, LJMC,JCS,BZ)
        SELECT SEQYS_WLJC.NEXTVAL,
               V_LJ.LJH,
               V_LJ.LJMC,             
               nvl(V_LJ.JCS, 0),               
               V_LJ.BZ
          FROM DUAL;
    END IF;
    IF V_CNT <> 0 THEN
      UPDATE YS_WLJC_TB
         SET
             LJH = V_LJ.LJH,
             LJMC = V_LJ.LJMC,             
             JCS = nvl(V_LJ.JCS, 0),            
             BZ=V_LJ.BZ
       WHERE TRIM(LJH) = TRIM(V_LJ.LJH);
    END IF;
  END LOOP;
  CLOSE CUR_IMPDATA;
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    RAISE_APPLICATION_ERROR(-20009, SQLERRM);
    ROLLBACK TO SAVEPOINT V_SP_0000;
    delete from ZX_SWAPDATA_TB T
     WHERE T.IMPTASK_BM = P_IMPTASK_BM
       and nvl(T.STATE, 0) <> 1;
    commit;
END IMPORT_WLJC_SP;
/

