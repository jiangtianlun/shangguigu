CREATE package DOTNET_STRINGTOTAB_PKG is

  -- Author  : USER
  -- Created : 2009-2-23 9:43:05
  -- Purpose : 处理下拉框语句

  -- Public type declarations
   TYPE T_ROW IS RECORD(NAME varchar2(2000),ID varchar2(2000));

  -- Public function and procedure declarations
  FUNCTION GET_TAB_FC (p_str IN VARCHAR2, p_delimiter IN VARCHAR2)
    RETURN t_dic_table ;
  FUNCTION GET_RECORD_FC (p_str IN VARCHAR2, p_delimiter IN VARCHAR2)
    RETURN T_ROW ;
  FUNCTION GET_TAB_1_FC (p_str IN VARCHAR2)
    RETURN t_dic_table ;
  FUNCTION GET_TAB_2_FC (p_str IN VARCHAR2, p_delimiter IN VARCHAR2)
    RETURN t_dic_table ;

end DOTNET_STRINGTOTAB_PKG;
/

