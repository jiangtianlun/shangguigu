CREATE package p_view_param  is
       --参数一
   function set_KSRQ(KSRQ VARCHAR2) return VARCHAR2 ;
   function get_KSRQ  return date;
   --参数二
   function set_JSRQ(JSRQ VARCHAR2) return VARCHAR2;
   function get_JSRQ  return date;

   end p_view_param;
--
/

