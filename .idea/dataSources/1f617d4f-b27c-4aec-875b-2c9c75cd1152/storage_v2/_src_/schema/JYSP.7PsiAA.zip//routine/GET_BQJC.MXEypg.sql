CREATE FUNCTION GET_BQJC(wlid Number)
 return  NUMBER as
 BQJC1 number:=0;
begin
  SELECT bqjc into bqjc1 FROM WLKC_VW T where T.WLID=wlid;
  return BQJC1;
END GET_BQJC;
/

