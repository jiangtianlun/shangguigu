CREATE procedure ZJ_YCLJYJHMX_SP(p_fid in number,p_num in number)
as
--
 v_num number:= p_num;
begin
loop
exit when v_num < 1;
insert into ZJ_YCLJYJHMX_TB(ID,FID) SELECT SEQZJ_YCLJYJHMX.NEXTVAL,p_fid FROM DUAL;
v_num := v_num -1;
end loop;
end ZJ_YCLJYJHMX_SP;
/

