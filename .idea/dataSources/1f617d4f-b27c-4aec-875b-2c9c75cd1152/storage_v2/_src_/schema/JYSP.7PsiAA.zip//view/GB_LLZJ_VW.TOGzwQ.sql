CREATE VIEW GB_LLZJ_VW AS
  select gysid,ny,wlid,jl,count(*) as cs from (select gysid,to_char(rq,'yyyy-mm') as ny,wlid,jl from gb_llzj_tb where to_char(rq,'yyyy-mm')>='2019-01' and nvl(zt,0)=2) group by gysid,ny,wlid,jl
/

