CREATE VIEW JBHTHZ_VW AS
  select jbtb.PU_BM,WS_BM, PU_NAME, PU_COMMENT, ajax, srm, jblj, '' CB_PATH, '' sm
  from (select PU_BM,
               WS_BM,
               WS_PATH jblj,
               substr(replace(REGEXP_SUBSTR(ws_content, '(url).*(ashx)'),' ',''),6) ||
               substr(replace(REGEXP_SUBSTR(ws_content, '(post).*(ashx)'), ' ',''),7) ajax,
               substr(replace(REGEXP_SUBSTR(ws_content,'(autocomplete).*(ashx)'),' ',''),15) srm
          from SUF_WEBSCRIPT_TB
         where (instr(ws_content, 'ashx') > 0 and (instr(ws_content, 'url') > 0
                or instr(ws_content, 'post') > 0
                or instr(ws_content, 'autocomplete') > 0))
            or (ws_path is not null and ws_path not like '%drilldown%' and
                ws_path not like '%exporting%' and
                ws_path not like '%neSelected%' and
                ws_path not like '%js%jp%' and
                ws_path not like '%jquery%' and
                ws_path not like '%draggable-legend%' and
                ws_path not like '%highcharts%' and
                ws_path not like '%theme%' and
                ws_path not like '%YKT_close%' and
                ws_path not like '%YKT_initialize%')) jbtb
  left join SUF_PROGRAMUNIT_TB cxtb
    on jbtb.PU_BM = cxtb.PU_BM
 group by jbtb.PU_BM,WS_BM, PU_NAME, PU_COMMENT, ajax, srm, jblj
union all
select httb.PU_BM,
       null WS_BM,
       PU_NAME,
       PU_COMMENT,
       '' ajax,
       '' srm,
       '' jblj,
       CB_PATH,
       sm
  from (select PU_BM, CB_PATH, CB_CONTENT || CB_COMMENT sm
          from SUF_CODEBEHIND_TB
         where CB_PATH is not null) httb
  left join SUF_PROGRAMUNIT_TB cxtb
    on httb.PU_BM = cxtb.PU_BM
 group by httb.PU_BM, PU_NAME, PU_COMMENT, CB_PATH, sm
/

