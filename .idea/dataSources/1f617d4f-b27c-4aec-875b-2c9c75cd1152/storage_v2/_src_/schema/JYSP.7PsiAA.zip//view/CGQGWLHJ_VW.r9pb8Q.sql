CREATE VIEW CGQGWLHJ_VW AS
  select cg2.wlid,sum(cg2.sl) sl,cg2.bz from cgqgd2_tb cg2 where cg2.fid in (1475) group by cg2.wlid,cg2.bz
/

