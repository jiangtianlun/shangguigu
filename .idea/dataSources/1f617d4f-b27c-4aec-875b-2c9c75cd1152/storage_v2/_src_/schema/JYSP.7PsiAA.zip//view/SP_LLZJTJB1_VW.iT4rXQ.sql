CREATE VIEW SP_LLZJTJB1_VW AS
  select rq,gysid,hgsl,bhgsl,Round(hgsl*100.0/(nvl(hgsl,0)+nvl(bhgsl,0)),2) as hgl from
(select rqq as rq,gysid,sum(hgsl)hgsl,sum(bhgsl)bhgsl from
(select gysid,hgsl,bhgsl,to_char(t.rq,'yyyy-mm')rqq from sp_lljy_tb t)group by rqq,gysid)order by rq,gysid
/

