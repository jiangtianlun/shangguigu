CREATE VIEW OA_MESSAGE_VW AS
  select a."MESSAGE_ID",a."MESSAGESTATUS_ID",a."MESSAGE_SENDERID",a."MESSAGE_SENDDATE",a."MESSAGE_NAME",a."MESSAGE_CONTENT",a."MESSAGE_ISVISIBLE",a."MESSAGE_URL",a."MESSAGE_ATTACHMENT",a."MESSAGETYPE_ID",b.messagesend_receiverid,b.messagesend_isread,b.messagesend_readdate,
  b.messagesend_isnew
    from oa_message_tb a,oa_messagesend_tb b
    where a.message_id=b.message_id
/

