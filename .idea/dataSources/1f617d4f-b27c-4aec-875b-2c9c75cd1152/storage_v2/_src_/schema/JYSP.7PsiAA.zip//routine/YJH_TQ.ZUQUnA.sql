CREATE procedure YJH_TQ(NY in varchar2) is
  V_CNT NUMBER;
begin     -------AND DJZT=1
  FOR COMM IN(select LJBH,LJID,ID,LJMC,JYSL,SJSL,NFYF AS RQ from scyjh_tb where NFYF=NY) LOOP
   begin    
     SELECT COUNT(*) INTO V_CNT FROM PC_YJH_TB WHERE LJBH = COMM.LJBH and TRIM(NFYF)=NY;   
     IF V_CNT = 0 THEN
      BEGIN
       INSERT INTO PC_YJH_TB (ID,DJZT,LJID,SCYJHID,LJBH,LJMC,JYSL,SJSL,NFYF)
         SELECT SEQPC_YJH.NEXTVAL,
                0,-----草稿
                COMM.LJID,
                COMM.ID,
                COMM.LJBH,
                COMM.LJMC,
                nvl(COMM.JYSL,0),
                nvl(COMM.SJSL,0),
                COMM.RQ 
                FROM DUAL;
      END;
     END IF;--IF V_CNT=0 THEN    
   end;
  end LOOP;  
  COMMIT;
end YJH_TQ;
/

