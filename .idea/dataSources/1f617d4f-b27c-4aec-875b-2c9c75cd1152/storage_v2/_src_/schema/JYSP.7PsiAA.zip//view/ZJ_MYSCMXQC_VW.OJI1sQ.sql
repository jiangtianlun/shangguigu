CREATE VIEW ZJ_MYSCMXQC_VW AS
  with scsl as(select ljid,gxzdid,gxxh,yf,sum(sl) sl,sum(xjsl) xjsl,sum(XJBFSL) XJBFSL,
sum(ZJSL) ZJSL,sum(fxs) fxs,sum(fxhgs) fxhgs,sum(Bfbhgs) Bfbhgs
from (select sczld.ljid ljid,sczld.gxzdid gxzdid,sczld.gxxh gxxh,
       TO_CHAR(sczld.scrq, 'YYYYMM') YF,
       NVL(sczld.sl,0) sl, -------先拼接生产指令单的数量
       NVL(ZJ_XJJL1.Sl,0)  XJSL, -----巡检数量
       NVL(ZJ_XJJL1.Bfsl,0)    XJBFSL, ----巡检报废数量
       NVL(ZJ_CPJYJL.SL,0)     ZJSL, -----终检数量
       NVL(ZJ_CPJYJL.Fxs,0)    fxs, ----返修数
       NVL(ZJ_CPJYJL.Fxhgs,0)  fxhgs, ----返修数
       nvl(ZJ_CPJYJL.Bfbhgs,0) Bfbhgs -------报废不合格数
  from  sczld_tb sczld
  LEFT JOIN ZJ_XJJL1_TB ZJ_XJJL1 on  sczld.id=ZJ_XJJL1.Sczldid
  left join ZJ_CPJYJL_TB ZJ_CPJYJL on ZJ_XJJL1.id=ZJ_CPJYJL.Zj_Xjjl1id
 where sczld.djzt = 1 and ZJ_XJJL1.DJZT=1)------------这里的过滤条件限制的多
 GROUP BY  YF,ljid,gxzdid,gxxh),
 yclsl as  (SELECT YF,ljid,wlid,GXZDID,GXXH,SUM(llsl) LLSL, SUM(SYSL) SYSL
                  FROM (select TO_CHAR(sczld.scrq, 'YYYYMM') YF,
                      LJSCWLDY.scwlid wlid,
                      LJSCWLDY.GXZDID GXZDID,
                      LJSCWLDY.GXXH GXXH,
                      LJSCWLDY.ljid ljid,
                      nvl(slzldmx.llsl,0) llsl, ----生产指令单的开单领料数量
                      nvl(ZJ_XJJL2.SYSL,0) SYSL ------巡检原材料使用数量
              from LJSCWLDY_TB LJSCWLDY left join sczldmx_tb slzldmx on LJSCWLDY.scwlid=slzldmx.wlid
               left join ZJ_XJJL2_TB ZJ_XJJL2 ON  slzldmx.ID =ZJ_XJJL2.Sczldmxid
               LEFT JOIN ZJ_XJJL1_TB ZJ_XJJL1 ON ZJ_XJJL2.FID=ZJ_XJJL1.ID
               left join sczld_tb sczld on slzldmx.fid=sczld.id
               AND LJSCWLDY.GXZDID=sczld.Gxzdid
               AND LJSCWLDY.GXXH=sczld.Gxxh
                where --------sczld.djzt = 1 AND
                ZJ_XJJL1.DJZT=1 and LJSCWLDY.sfyx=1) GROUP BY  YF,ljid,wlid,GXZDID,GXXH)
 select LJSCWLDY.LJID   LJID,
        LJSCWLDY.SCWLID WLID,
        LJSCWLDY.GXZDID GXZDID,
        LJSCWLDY.GXXH   GXXH,
        scsl.YF         YF,
        scsl.SL         sl,
        scsl.XJSL       xjsl,
        scsl.XJBFSL     XJBFSL,
        scsl.ZJSL       zjsl,
        scsl.FXS        fxs,
        scsl.FXHGS      fxhgs,
        scsl.BFBHGS     BFBHGS,
        yclsl.LLSL      LLSL,
        yclsl.SYSL      SYSL
   from LJSCWLDY_TB LJSCWLDY
   LEFT JOIN scsl ON SCSL.LJID = LJSCWLDY.LJID
                 and LJSCWLDY.sfyx = 1
                 AND LJSCWLDY.GXZDID = SCSL.GXZDID
                 AND LJSCWLDY.GXXH = SCSL.GXXH
   LEFT JOIN yclsl ON LJSCWLDY.ljID = yclsl.ljID
                  and LJSCWLDY.scwlID = yclsl.wlID
                  AND LJSCWLDY.GXZDID = yclsl.GXZDID
                  AND LJSCWLDY.GXXH = yclsl.GXXH
                  and SCSL.yf = yclsl.yf
  order by ljid asc
/

