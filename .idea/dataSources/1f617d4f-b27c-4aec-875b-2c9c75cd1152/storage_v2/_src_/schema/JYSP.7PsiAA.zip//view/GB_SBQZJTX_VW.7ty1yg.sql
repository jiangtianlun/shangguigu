CREATE VIEW GB_SBQZJTX_VW AS
  select a."ID",a."SBID",a."QJRQ",a."QJXM",a."QJR",a."QJJL",a."QJDW",a."BZ",a."XCQJRQ",a."XCQJ",b.sbbh,b.sbmc,b.sblx,case when XCQJRQ is null then null else Round(xcqjrq-sysdate,3) end as r0,
case when XCQJRQ is not null and (xcqjrq-sysdate<5 and xcqjrq-sysdate>-5 and nvl(XCQJ,0)<>1) then 1 else 0 end as r1,nvl(XCQJ,0) as r3
 from (select * from GB_SBQZJJL_TB where xcqjrq is not null) a left join XC_SBTZ_TB b on a.sbid=b.id
/

