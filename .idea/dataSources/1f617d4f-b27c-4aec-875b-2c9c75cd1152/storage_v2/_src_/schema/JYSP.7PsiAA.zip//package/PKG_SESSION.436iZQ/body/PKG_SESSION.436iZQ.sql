CREATE PACKAGE BODY pkg_session IS

  sv_parameters parm_type;

  PROCEDURE set_val(p_idx IN VARCHAR2, p_value IN VARCHAR2) IS
  BEGIN
    sv_parameters(TRIM(UPPER(p_idx))) := SUBSTR(p_value, 1, 1000);
  
    RETURN;
  END set_val;

  PROCEDURE set_val(p_idx IN VARCHAR2, p_value IN NUMBER) IS
  BEGIN
    set_val(p_idx, TO_CHAR(p_value));
    RETURN;
  END set_val;

  PROCEDURE set_val(p_idx IN VARCHAR2, p_value IN DATE) IS
  BEGIN
    set_val(p_idx, TO_CHAR(p_value, 'YYYY-MM-DD HH24:MI:SS'));
    RETURN;
  END set_val;

  FUNCTION get_val(p_idx IN VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    RETURN sv_parameters(TRIM(UPPER(p_idx)));
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RETURN NULL;
  END get_val;

  FUNCTION get_val_number(p_idx IN VARCHAR2) RETURN NUMBER IS
  BEGIN
    RETURN TO_NUMBER(get_val(p_idx));
  END get_val_number;

  FUNCTION get_val_date(p_idx IN VARCHAR2) RETURN DATE IS
  BEGIN
    RETURN TO_DATE(get_val(p_idx), 'YYYY-MM-DD HH24:MI:SS');
  EXCEPTION
    WHEN OTHERS THEN
      return sysdate;
  END get_val_date;

END pkg_session;
/

