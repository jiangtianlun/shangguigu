CREATE VIEW ZX_SWAPDATA_VW AS
  select '201802,782,1' as tempaddition from dual
/

