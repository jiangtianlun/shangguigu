CREATE VIEW WLKC_VW AS
  SELECT WLID,WLBH,WLMC,GGXH,sum(SQJC)SQJC,sum(BQRK) BQRK,sum(BQCK) BQCK,ROUND(sum(BQJC),0) BQJC from ----物料库存汪鑫 2017.03.02
(select WLID,0 SQJC,0 BQRK,0 BQCK, SSSL  BQJC from KCRKD2_TB RKD2 left join KCRKD1_TB RKD1 on RKD2.FID = RKD1.ID
         where  RKD1.YWRQ <=sysdate  and  RKD1.DJZT = 1
		union all select WLID,0  SQJC,0 BQRK,0  BQCK,  -SFSL  BQJC  from KCCKD2_TB CKD2 left join KCCKD1_TB CKD1 ON CKD2.FID = CKD1.ID
         where CKD1.YWRQ <=sysdate and  CKD1.DJZT = 1
		 )A inner join (select id,wlbh,wlmc,ggxh,jldwid from WLZD_TB ) WL on A.wlid = wl.id group by WLID,wlbh,wlmc,ggxh,jldwid order by wlbh
/

