CREATE VIEW OA_ALL_USERS_VW AS
  select user_id,
       --created by cwm 090715
       --可以重写，注意必须要包含user_id,u_name_full,org_id这三个字段
       u_name_full,
       org_id
  from auth_user_tb
/

