CREATE VIEW GB_CPCKTJ1_VW AS
  select a."NY",a."KHID",a."CPID",a."CKSL",b.khmc,c.cpbh||','||c.gg||','||c.cpmc as cp from
(select ny,khid,cpid,sum(cksl)cksl from (select cpid,khid,cksl,to_char(ckrq,'yyyy-mm')ny from GB_cpck_tb)
 group by ny,khid,cpid)a left join GB_khzd_tb b on a.khid=b.id
 left join GB_cpzd_tb c on a.cpid=c.id order by a.ny,a.khid,a.cpid
/

