CREATE VIEW CGYCLJHHJ_VW AS
  select wlid,nfyf,sum(sl) sl,DJLX from (                                    
                             select wlid,nfyf,ceil(sum(CASE WHEN WLJLDWID=1 THEN kuan*0.001*XQSL ELSE xqsl END)) sl,DJLX 
					                               from cgyclyjh_tb WHERE NFYF='201802' and DJZT=0 and fjlx=0 group by NFYF, wlid,DJLX                                    
                                    union all
                                   select wlid, nfyf, ceil(sum(sl)) sl,DJLX  from (select cg.wlid, cg.nfyf, (CASE WHEN WLJLDWID<>1 THEN XQSL ELSE xqsl * zhdy.xs * 0.001 END ) sl,DJLX
          from CGBCPYJHHJ_TB cg left join wlzhdy_tb zhdy on cg.bcpid=zhdy.scwlid where nfyf = '201802'  and djzt = 0  ) group by DJLX,wlid, nfyf) WHERE  DJLX=1group by wlid,nfyf,DJLX
/

