CREATE VIEW VW_XMLB AS
  select 11 id,'lbA' txt from dual
union
select 22 id,'lbB' txt from dual
/

