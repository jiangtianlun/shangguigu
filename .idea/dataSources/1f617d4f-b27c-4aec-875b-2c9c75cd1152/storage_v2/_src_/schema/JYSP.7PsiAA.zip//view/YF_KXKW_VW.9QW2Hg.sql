CREATE VIEW YF_KXKW_VW AS
  select "ID","KW","SY"  --空闲面料空位
  from yf_mlkwzd_tb t
 where id not in (select kwid
                    from yf_mlck_tb
                   where rkrq is not null
                     and ckrq is null)
 order by kw
/

