CREATE procedure deletemodule_sp(p_moduleid number) is
begin
delete from oa_version_tb ver
 where ver.hisid in
       (select his.hisid
          from oa_history_tb his
         where his.tacheid in
               (select tache.tacheid
                  from oa_tache_tb tache
                 where tache.moduleid = p_moduleid));
                 
delete from oa_history_tb his
 where his.tacheid in (select tache.tacheid
                         from oa_tache_tb tache
                        where tache.moduleid = p_moduleid);
                        
delete from oa_flowtask_tb task where task.moduleid = p_moduleid;

  delete oa_roletache_tb t
   where t.tacheid in (select ta.tacheid
                         from oa_tache_tb ta
                        where ta.moduleid = p_moduleid);

  delete from oa_tache_tb ta where ta.moduleid = p_moduleid;

  delete from oa_flow_tb flow where flow.moduleid = p_moduleid;

  delete from oa_module_tb module where module.moduleid = p_moduleid;

  commit;
end deletemodule_sp;
/

