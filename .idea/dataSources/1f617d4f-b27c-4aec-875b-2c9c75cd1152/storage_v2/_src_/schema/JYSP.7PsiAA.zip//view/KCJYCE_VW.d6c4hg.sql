CREATE VIEW KCJYCE_VW AS
  select kc.wlid,kc.gysid,kc.byjy,jy.qckc,abs(kc.byjy-jy.qckc) kcce,kc.ckid,jy.nfyf from yclbykcjy_vw kc right join kcjy_tb jy on kc.wlid=jy.wlid and kc.yf=to_char(add_months(trunc(to_date(jy.nfyf,'yyyymm')),-1),'yyyymm') and kc.gysid=jy.gysid where  jy.ckid in (1212,1214)
union all
select kc.wlid,null gysid,kc.byjy,jy.qckc,abs(kc.byjy-jy.qckc) kcce,kc.ckid,jy.nfyf from bykcjy_vw kc left join kcjy_tb jy on kc.wlid=jy.wlid and kc.yf=to_char(add_months(trunc(to_date(jy.nfyf,'yyyymm')),-1),'yyyymm') where  jy.ckid in (1257,1273,1334,1335)
/

