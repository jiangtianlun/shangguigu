CREATE VIEW MJBYJL_VW AS
  select "MJID","NF","BYXM",
"'M01'_BYQK" as M01,"'M02'_BYQK" as M02,"'M03'_BYQK" as M03,"'M04'_BYQK" as M04,
"'M05'_BYQK" as M05,"'M06'_BYQK" as M06,"'M07'_BYQK" as M07,"'M08'_BYQK" as M08,
"'M09'_BYQK" as M09,"'M10'_BYQK" as M10,"'M11'_BYQK" as M11,"'M12'_BYQK" as M12
from

    (select mjid,mm,nf,byqk,byxm from
        (select mjby.mjid,mjby.qw,null tmfxy,null xqkw,null qtbyxm, null qtbyxm2,
               'M' || to_char(mjby.byrq, 'mm') mm, to_char(mjby.byrq, 'yyyy') nf  from mjbyjl_tb mjby
         union all
         select mjby.mjid,null qw,mjby.tmfxy,null xqkw,null qtbyxm, null qtbyxm2,
               'M' || to_char(mjby.byrq, 'mm') mm, to_char(mjby.byrq, 'yyyy') nf from mjbyjl_tb mjby
                union all
         select mjby.mjid,null qw,null tmfxy,mjby.xqkw,null qtbyxm, null qtbyxm2,
               'M' || to_char(mjby.byrq, 'mm') mm, to_char(mjby.byrq, 'yyyy') nf from mjbyjl_tb mjby
         union all
         select mjby.mjid,null qw,null tmfxy,null xqkw,mjby.qtbyxm,null qtbyxm2,
               'M' || to_char(mjby.byrq, 'mm') mm , to_char(mjby.byrq, 'yyyy') nf from mjbyjl_tb mjby
         union all
         select mjby.mjid,null qw,null tmfxy,null xqkw,null qtbyxm,null qtbyxm2,
               'M' || to_char(mjby.byrq, 'mm') mm  , to_char(mjby.byrq, 'yyyy') nf from mjbyjl_tb mjby
         )
    unpivot (byqk for byxm in (qw as '清污',tmfxy as '涂抹防锈油',xqkw as '型腔孔位',qtbyxm as '其他保养项目',qtbyxm2 as '其他保养项目2')))

pivot(SUM(byqk) byqk for mm in ('M01', 'M02', 'M03', 'M04', 'M05', 'M06', 'M07', 'M08', 'M09', 'M10', 'M11', 'M12'))
/

