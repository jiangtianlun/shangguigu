CREATE procedure SYS_RowTOCol_SP(
P_PU   number,  
P_TAB1          VARCHAR2,  --数据表/视图
P_FIXCOLS       VARCHAR2,  --固定列 
--v_FIXCOLSNUM    NUMBER,
P_DATACOL       VARCHAR2,  --数据列
P_TAB2          VARCHAR2,  --指标表
P_RELATIONCOL   VARCHAR2,  --关系列
P_RELATIONSJ    VARCHAR2,  --关系列上级
P_RELATIONMC    VARCHAR2,  --关系列名称
P_FIXHEAD       VARCHAR2,  --固定表头部分
P_TAB3          VARCHAR2,  --数据保存的表
p_SUBHEAD       VARCHAR2,  --活动列固定子表头
p_tab3_pk       VARCHAR2   --保存表的主键字段
) is

--2010-05-07 行转列处理
--传入：pu;
--     数据表/视图：固定列；数据列
--     指标表；
--     关系列；关系列上级；关系列名称
--      固定表头部分，
--     数据保存的表，保存表的主键字段
--     活动列固定子表头

v_sp  long;
v_sp1  long;
sql_cur_changedata  varchar2(2000):=null;
sql_insert  varchar2(2000):=null;
sql_open_changedata varchar2(2000):=null;
sql_open_changedata_fc varchar2(2000):=null;
sql_update_where      varchar2(4000):=null;
sql_update_where_fc varchar2(4000):=null;
sql_insupd_para     varchar2(2000):=null;
sql_insupd_ishave     varchar2(2000):=null;
sql_insupd_if    varchar2(2000):=null;
sql_insupd_insert     varchar2(2000):=null;
sql_insupd_insert_val     varchar2(2000):=null;
sql_insupd_update     varchar2(2000):=null;
sql_insupd_update_where     varchar2(2000):=null;
sql_update_changdata_set     varchar2(2000):=null;
sql_update_changdata_using   varchar2(2000):=null;

v_sql1  varchar2(2000):=null;
v_sql2  varchar2(2000):=null;
v_sql3  varchar2(2000):=null;
v_sql4  varchar2(2000):=null;
v_sql5  varchar2(2000):=null;

/*v_sql5  varchar2(2000):=null;
v_sql6  varchar2(2000):=null;*/

P_spmc varchar2(200):='SYS_PU'||P_PU||'_rowtocol_sp';
p_spmc1 varchar2(200) := 'SYS_PU'||P_PU||'_rowtocol_insupd_sp'; 

v_FIXCOLS  varchar2(2000);
v_FIX    varchar2(2000);
v_str      varchar2(200);
v_num      number  ;
i          number;
j          number;
V_FIXCOLSNUM  number;
insupd_para_num   number;
v_DATACOL   varchar2(2000);
v_datanum   number;


/*
P_PU   number:=18;
P_TAB1          VARCHAR2(400) :='sys_changdata_vw';
P_FIXCOLS       VARCHAR2(2000):='U_NAME';
P_FIXCOLSNUM    NUMBER:=1;
P_DATACOL       VARCHAR2(400) :='SCORE_DATA';
P_TAB2          VARCHAR2(400) :='test_course_tb';
P_RELATIONCOL   VARCHAR2(400) :='COURSE_ID';
P_RELATIONSJ    VARCHAR2(400)  :='COURSE_SJ' ; --
P_RELATIONMC    VARCHAR2(400) :='COURSE_MC';
P_FIXHEAD       VARCHAR2(1000) :='PU_BM#姓名(datasource)';
P_TAB3   VARCHAR2(400) :='test_score1_tb';

p_tab3_pk VARCHAR2(400) :='score_id1';
*/

begin
     -- 处理多个固定列
     if P_FIXCOLS is not null then
        select  rtrim(P_FIXCOLS,',') into v_FIX from dual;
     end if;
     v_FIX := v_FIX||',';

     -- 1 cur_changedata
     sql_cur_changedata := 'cursor cur_changedata(var_item number';
     v_sql1 := ' ) is 
     select ';
     
     --2 insert into suf_changedata_tb 固定列
     sql_insert:='v_sql := ''insert into suf_changedata_tb(changedata_bm,pu_bm';
     v_sql2:= ') 
              values(:changedata_bm,:pu_bm';
     v_sql3:= ' execute immediate v_sql using v_pk,'||P_PU;
     
     --3 open cur_changedata
     sql_open_changedata:= 'open cur_changedata(cur_item_rt.'||P_RELATIONCOL;
     sql_open_changedata_fc := 'open cur_changedata(cur_item_fc_rt.'||P_RELATIONCOL;
     
     -- 4 update table
     sql_update_where := ' '''||p_spmc1||'( ';
     v_sql4 := ''||p_spmc1 ||'(';
     -- SYS_PU1_rowtocol_insupd_sp(@PARA_C_1,@PARA_C_3,@PARA_C_4,1);
     
     --5 保存时，判断记录是否已存在（insert/update）
     sql_insupd_ishave :='select count(*) into v_num from '||P_TAB3||' where 1=1 ';
     
     --6 保存时,insert 语句
     sql_insupd_insert:='insert into '||P_TAB3||' ('||p_tab3_pk||'';
     sql_insupd_insert_val := ' values (seq'||substr(p_tab3,0,length(p_tab3)-3)||'.nextval';    
     
     --7 保存时,update 语句
     /*sql_insupd_update := 'UPDATE '||P_TAB3||' SET '||P_DATACOL||' = ';*/
     sql_insupd_update := 'UPDATE '||P_TAB3||' SET ';
     sql_insupd_update_where := ' where 1=1 ';
     
     
     ------ 解析固定列 --------------------------------
     i:= 1;
     insupd_para_num :=0;
     while (v_FIX is not null)
     loop
         v_num := instr(v_FIX,',');
         v_str := substr(v_FIX,0,v_num-1);
         v_FIX:=replace(v_FIX,v_str||',','');
         
         if ( instr(v_str,'[') > 0) then 
             v_str := ltrim(v_str,'[');
             v_str := rtrim(v_str,']');
             
             sql_update_where := sql_update_where||'@PARAMETER_C_'||i||','; 
             sql_insupd_update_where := sql_insupd_update_where||' and '||v_str||' = PARAMETER_'||insupd_para_num; 
             sql_insupd_para := sql_insupd_para||'PARAMETER_'||insupd_para_num||' varchar2,';
             sql_insupd_ishave := sql_insupd_ishave||' and '||v_str||' = PARAMETER_'||insupd_para_num;
             sql_insupd_insert := sql_insupd_insert||','||v_str;
             sql_insupd_insert_val := sql_insupd_insert_val||',PARAMETER_'||insupd_para_num;
             
             insupd_para_num:=insupd_para_num+1;
         end if;
         
         sql_cur_changedata := sql_cur_changedata || ', var_'||v_str||' varchar2';
         v_sql5 := v_sql5 || ' and '||v_str||' = var_'||v_str;
         
         sql_insert :=sql_insert||',c_'||i;
         v_sql2:= v_sql2 || ',:c_'||i;
         v_sql3:= v_sql3 || ',cur_distinct_rt.'||v_str;
         
         sql_open_changedata :=sql_open_changedata||',cur_distinct_rt.'||v_str;
         sql_open_changedata_fc := sql_open_changedata_fc||',cur_distinct_rt.'||v_str;
         v_FIXCOLS := v_FIXCOLS ||v_str||',';

         i :=i+1;
     end loop; 
     sql_insert := sql_insert||v_sql2||')''; 
                  '||v_sql3||';';
     sql_open_changedata := sql_open_changedata || ');';
     sql_open_changedata_fc := sql_open_changedata_fc || ');';
     v_FIXCOLS := rtrim(v_FIXCOLS,',');
     
     V_FIXCOLSNUM := i-1;
     ------ 解析固定列 --------------------------------end
     
     ------- 解析数据列 ;保存的过程：用到的参数处理---------------------------
     j:= insupd_para_num;
     i:= 1;
     v_DATACOL := rtrim(P_DATACOL,',')||','; 
     while(v_DATACOL is not null)
     loop
         v_num := instr(v_DATACOL,',');
         v_str := substr(v_DATACOL,0,v_num-1);
         v_DATACOL:=replace(v_DATACOL,v_str||',','');
         v_sql1 :=v_sql1||v_str||' as DATA_'||i||',';
         sql_update_changdata_set := sql_update_changdata_set||'cur_changedata_rt.DATA_'||i||',';
         i:=i+1;
         
         sql_insupd_para := sql_insupd_para||'PARAMETER_'||j||' varchar2,';
         sql_insupd_insert_val :=sql_insupd_insert_val||','||'PARAMETER_'||j;
         sql_insupd_update := sql_insupd_update||v_str||' = PARAMETER_'||j||',';
         sql_insupd_if := sql_insupd_if||' PARAMETER_'||j||' is not null or';
         j:=j+1;
         
     end loop;
     v_sql1 := rtrim(v_sql1,',')||' from '||P_TAB1||' 
     where '||P_RELATIONCOL||' = var_item ';
     sql_update_changdata_set := rtrim(sql_update_changdata_set,',');
     
     sql_insupd_para :=  rtrim(sql_insupd_para||'PARAMETER_'||j||' varchar2',',');
     sql_insupd_insert_val := sql_insupd_insert_val||','||'PARAMETER_'||j||');';
     sql_insupd_update := rtrim(sql_insupd_update,',');
     sql_cur_changedata := sql_cur_changedata||v_sql1||v_sql5||';';
     
     
     v_datanum := i-1;
     ------- 解析数据列 ---------------------------end
     
     -- 保存的过程：  用到的参数处理
     --(1)
     sql_insupd_ishave := sql_insupd_ishave||' and '||P_RELATIONCOL||'=PARAMETER_'||j||';';
     --(3)
     sql_insupd_insert := sql_insupd_insert||','||P_DATACOL||','||P_RELATIONCOL||') ';
     --(4)
     --sql_insupd_update := sql_insupd_update||' PARA_'||insupd_para_num;
     sql_insupd_update_where :=sql_insupd_update_where||' and '||P_RELATIONCOL||'=PARAMETER_'||j||';';
     --(5)
     --sql_update_where_fc := sql_update_where||'@PARA_C_'||insupd_para_num||','' ||cur_item_fc_rt.'||P_RELATIONCOL||'||'');''';
     sql_update_where_fc := sql_update_where||'@PARAMETER_C_';
     
     
     --一 动态生成  处理保存功能的sp  语句
     v_sp1:=
'create or replace procedure '||P_spmc1||'('||sql_insupd_para||') is 
v_num   number;

begin
     '||sql_insupd_ishave||'
     
     if '|| sql_insupd_if||'  v_num is not null then
         if v_num = 0 then
            '||sql_insupd_insert||'
            '||sql_insupd_insert_val||
            '
         else            
              '||sql_insupd_update||'
             '||sql_insupd_update_where||'

         end if;
     end if;

commit;

end '|| P_spmc1||' ;' ;
    execute immediate v_sp1 ;

     --二 动态生成  处理行转列的sp  语句
     v_sp:=
'create or replace procedure '||P_spmc||'(
Pstrsql   out varchar2,
Pstrhead  out varchar2,
Pstrupdate out varchar2
) is 
P_RELATIONSJ    VARCHAR2(400) :='''||P_RELATIONSJ||''';

 v_sql   varchar2(2000); 
 v_pk    number;
 i       number :=0;
 v_num   number;
 j        number:=0;
 data_num number ;
 v_sql2   varchar2(2000); 
 
--1 固定列 
cursor cur_distinct is 
   select distinct '||V_FIXCOLS||' from '||P_TAB1||' ;
cur_distinct_rt  cur_distinct%rowtype; 
--21 指标:1级
cursor cur_item is 
   select * from '||P_TAB2||' ;
cur_item_rt  cur_item%rowtype;  

--22 指标：2级
type acur is ref cursor;
sjcur acur;
fccur acur;
v_sql_fc1 varchar2(1000):= ''select * from '||P_TAB2||'  where  '||P_RELATIONSJ||' is null order by '||P_RELATIONCOL||''';
v_sql_fc2 varchar2(1000);

cur_item_sj_rt  '||P_TAB2||'%rowtype; 
cur_item_fc_rt  '||P_TAB2||'%rowtype; 

--3 数据

'||sql_cur_changedata||'
cur_changedata_rt  cur_changedata%rowtype;

begin
     delete  from suf_changedata_tb where pu_bm = '||P_PU||';
     
     -- 输出 sql
     if P_RELATIONSJ is null OR P_RELATIONSJ = ''null'' then 
         select count(*) into v_num from '||P_TAB2||' ;
     else
         v_sql :=''select count(*)  from '||P_TAB2||'  where '||P_RELATIONSJ||' is not null'' ;
         OPEN sjcur FOR V_SQL;
         fetch sjcur into v_num;
         close sjcur;
     end if;

     v_num := v_num*'||v_datanum||' + '||V_FIXCOLSNUM||' ;
     Pstrsql := ''select null as xh,changedata_bm, pu_bm'';
    
     j:=1;
     while(j<=v_num)
     loop
         Pstrsql := Pstrsql||'', C_''||j ;
         --Pstrupdate := Pstrupdate||'',C_''||j||'' = @C_''||j ;
         j:=j+1;
     end loop;
     Pstrsql := Pstrsql||'' from suf_changedata_tb '';
    
     
     -- 输出表头,输出保存语句 : 区分是否分层
     Pstrhead :='''||P_FIXHEAD||'''; 
     j:= '||V_FIXCOLSNUM||'+1;
     if P_RELATIONSJ is null OR P_RELATIONSJ = ''null'' then 
         for cur_item_rt in cur_item
         loop
             Pstrhead := Pstrhead||''#''||cur_item_rt.'||P_RELATIONMC||'||'' '||p_SUBHEAD||''';
             
             i:=0;
             Pstrupdate := Pstrupdate||'||sql_update_where||''';
             while(i<'||v_datanum||')
             loop
                 Pstrupdate := Pstrupdate|| ''@PARAMETER_C_''||j||'','';
                 j:=j+1;
                 i:=i+1;
             end loop;
             Pstrupdate := Pstrupdate||cur_item_rt.'||P_RELATIONCOL||'||'');'';
         end loop;
     else
         open sjcur for v_sql_fc1;
         loop
             fetch sjcur into cur_item_sj_rt;
         exit when  sjcur%notfound ;
              Pstrhead := Pstrhead||''#''||cur_item_sj_rt.'||P_RELATIONMC||'||'' '';

              v_sql_fc2 := ''select * from '||P_TAB2||'  where  '||P_RELATIONSJ||' =''|| cur_item_sj_rt.'||P_RELATIONCOL|| ';
              open fccur for v_sql_fc2 ;
              loop
                  fetch fccur into cur_item_fc_rt;
              exit when fccur%notfound;
                  Pstrhead := Pstrhead||cur_item_fc_rt.'||P_RELATIONMC||'||'','';
                  
                  i:=0;
                 Pstrupdate := Pstrupdate||'||sql_update_where||''';
                 while(i<'||v_datanum||')
                 loop
                     Pstrupdate := Pstrupdate|| ''@PARAMETER_C_''||j||'','';
                     j:=j+1;
                     i:=i+1;
                 end loop;
                 Pstrupdate := Pstrupdate||cur_item_fc_rt.'||P_RELATIONCOL||'||'');'';

              end loop;
              close fccur ;
              Pstrhead := rtrim(Pstrhead,'','');
         end loop;
         close sjcur;

     end if;

     
     for cur_distinct_rt in cur_distinct
     loop
         select seqsuf_changedata.nextval into v_pk from dual;
         '||sql_insert||'
         
         i:= '||V_FIXCOLSNUM||' ;
         -- 指标只有一级
         if P_RELATIONSJ is null  OR P_RELATIONSJ = ''null'' then 
             for cur_item_rt in cur_item
             loop
                 i:=i+1;

                 '||sql_open_changedata||'
                 fetch cur_changedata  into cur_changedata_rt;

                 if cur_changedata%found then
                     v_sql := ''update suf_changedata_tb set '';
                     data_num := 1;
                     while (data_num <= '||v_datanum||')      
                     loop
                         v_sql := v_sql||'' c_''||i||'' = :cx''||i||'','';
                         data_num :=data_num+1;
                         i:=i+1;
                     end loop;
                     i:=i-1;
                     v_sql := rtrim(v_sql,'','')||'' where changedata_bm = :v_pk'';
                     execute immediate v_sql using '||sql_update_changdata_set||',v_pk ;
                 else
                     i:= i+'||v_datanum||'-1;
                 end if ;
                 
                 close cur_changedata;
             end loop;
         -- 指标有2级
         else
             open sjcur for v_sql_fc1;
             loop
                 fetch sjcur into cur_item_sj_rt;
             exit when  sjcur%notfound ;
                  v_sql_fc2 := ''select * from '||P_TAB2||'  where  '||P_RELATIONSJ||' =''|| cur_item_sj_rt.'||P_RELATIONCOL|| ';
                  open fccur for v_sql_fc2 ;
                  loop
                      fetch fccur into cur_item_fc_rt;
                  exit when fccur%notfound;
                       i:=i+1;
                       
                       '||sql_open_changedata_fc||'
                       
                       fetch cur_changedata  into cur_changedata_rt;

                       --
                       if cur_changedata%found then
                           v_sql := ''update suf_changedata_tb set '';
                             data_num := 1;
                             while (data_num <= '||v_datanum||')      
                             loop
                                 v_sql := v_sql||'' c_''||i||'' = :cx''||i||'','';
                                 data_num :=data_num+1;
                                 i:=i+1;
                             end loop;
                             i:=i-1;
                             v_sql := rtrim(v_sql,'','')||'' where changedata_bm = :v_pk'';
                             execute immediate v_sql using '||sql_update_changdata_set||',v_pk ;
                       else
                           i:= i+'||v_datanum||'-1;    
                       end if ;
                       
                       close cur_changedata;
                  end loop;
                  close fccur;

             end loop;
             close sjcur;
             
         end if;
  
     end loop;
  
    commit;
 end '||P_spmc||' ;'
 ;
 execute immediate v_sp ;


end SYS_RowTOCol_SP;
/

