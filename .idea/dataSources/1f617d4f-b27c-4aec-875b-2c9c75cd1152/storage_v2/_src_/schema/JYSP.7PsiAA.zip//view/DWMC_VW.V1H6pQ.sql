CREATE VIEW DWMC_VW AS
  select ID, LBBH  as KHBH,LBMC  khmc,fid LBID from wllb_tb where fid in ( 104,323)
UNION ALL
SELECT ID , GYSBH,GYSMC KHMC, GYSLBID LBID FROM GYSZD_TB GYS
where  exists(select 1 from GYSLB_tb  GYSLB where GYSLB.id=GYS.GYSLBID and GYSlb.fid=2)
/

