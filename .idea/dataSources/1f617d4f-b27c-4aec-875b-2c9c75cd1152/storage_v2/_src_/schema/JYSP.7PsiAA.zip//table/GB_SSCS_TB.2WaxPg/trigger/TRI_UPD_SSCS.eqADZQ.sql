CREATE TRIGGER TRI_UPD_SSCS
  AFTER UPDATE OF RQ1
  ON GB_SSCS_TB
  FOR EACH ROW
  BEGIN
   if (to_char(:NEW.RQ1,'mi')<>to_char(:OLD.RQ1,'mi') and :NEW.CSBH=:OLD.CSBH) then --相隔1分钟保存1次历史记录
    IF  (:NEW.PH IS NOT NULL) THEN
      begin
       insert into GB_SSCS_BAK_TB (ID,CSBH,CSZ,RQ1,PH,JD) values (SEQGB_SSCS_BAK.NEXTVAL,:NEW.CSBH,:NEW.CSZ,:NEW.RQ1,:NEW.PH,:NEW.JD);
      end;
    END IF;
   end if;
 END;
/

