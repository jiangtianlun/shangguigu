CREATE VIEW ZJ_BHGSLTJ_VW AS
  select bzid,
sum(sczs) sczs,--终检的实收总数
sum(fxs)+sum(bfbhgs) bhgs,--终检中的不合格数
round(((sum(bfbhgs)+sum(fxs))/sum(sczs)),3) bhgl,---不合格率
--sum(fxhgs) fxhgs,
sum(sl1) sl1,
sum(sl2) sl2,
sum(sl3) sl3,
sum(sl4) sl4,
sum(sl5) sl5,
sum(sl6) sl6,
sum(sl7) sl7,
sum(sl8) sl8,
sum(sl9) sl9,
sum(sl10) sl10,
YF
from(select t2.bzid bzid,
       nvl(t2.sl,0) sczs,
       nvl(t2.fxs,0) fxs,
       --nvl(t2.fxhgs,0) fxhgs,
       nvl(t2.bfbhgs,0) bfbhgs,
       nvl(t1.bhgyy1sl, 0) sl1,
       nvl(t1.bhgyy2sl, 0) sl2,
       nvl(t1.bhgyy3sl, 0) sl3,
       nvl(t1.bhgyy4sl, 0) sl4,
       nvl(t1.bhgyy5sl, 0) sl5,
       nvl(t1.bhgyy6sl, 0) sl6,
       nvl(t1.bhgyy7sl, 0) sl7,
       nvl(t1.bhgyy8sl, 0) sl8,
       nvl(t1.bhgyy9sl, 0) sl9,
       nvl(t1.bhgyy10sl, 0) sl10,
       to_char(scrq, 'yyyymm') YF,
       t2.ljid ljid,
       t3.wllbid wllbid
  from zj_cpjyjl_tb t2
  left join zj_bhgyyslmx_tb t1 on t1.fid = t2.id
  left join wlzd_tb t3 on t3.id=t2.ljid
  where djzt=1 and wllbid not in(320) )
  group by bzid,yf
/

