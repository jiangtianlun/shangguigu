CREATE VIEW ZJ_KHCPZZHGLTJ_VW AS
  select wlzd.wllbid,
       --t1.bzid,
       t1.ljid,
       sum(nvl(t1.sl,0))+sum(nvl(t2.bfsl,0)) SCZS,
       sum(nvl(t1.sl,0))-(sum(nvl(bfbhgs,0))+(sum(nvl(fxs,0))-sum(nvl(fxhgs,0)))) zzhgs,
       round((sum(nvl(t1.sl,0))-(sum(nvl(bfbhgs,0))+(sum(nvl(fxs,0))-sum(nvl(fxhgs,0)))))/(sum(nvl(t1.sl,0))+sum(nvl(t2.bfsl,0))),4) zzhgl,
       to_char(t1.scrq,'YYYYMM') NFYF
  from ZJ_CPJYJL_TB t1
  left join Zj_Xjjl1_Tb t2 on t1.Zj_Xjjl1id = t2.id
  left join wlzd_tb wlzd on wlzd.id=t1.ljid
  where t1.djzt=1  and to_char(t1.scrq, 'yyyymm')='201711'
 group by grouping sets((wlzd.wllbid,to_char(t1.scrq,'YYYYMM'), t1.ljid),wlzd.wllbid)
/

