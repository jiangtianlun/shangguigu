CREATE VIEW SP_KCCKMX_YX_VW AS
  select t1.djbh,
       t1.djzt,
       t1.djlxid,
       t1.ckid,
       t1.shrid,
       trunc(t1.zdrq, 'dd') zdrq,
       t1.bmid,
       t1.lyrid,
       t1.pch,
       t2."ID",
       t2."FID",
       t2."WLID",
       t2."QLSL",
       t2."SFSL",
       t2."DJ",
       t2."BZ",
       t2.ph,
       t2.je
  from sp_kcckd1_tb t1, sp_kcckd2_tb t2
 where t1.id = t2.fid
   and djzt = 1
   and t1.djbh != '生成单号出错'
   and t1.djbh is not null
   and wlid is not null
/

