CREATE VIEW MJBYDJJH_VW AS
  select tz.id,---模具保养点检计划单
        tz.mjbh,
        tz.mjmc,
        tz.ggxh,
        jh.nf,
        jh.yf,
        jh.nf || jh.yf byny,
        jh.wczt,
        jh.wcrq
   from mjbydjjh_tb jh
   left join mjtz_tb tz on tz.id = jh.mjid
/

