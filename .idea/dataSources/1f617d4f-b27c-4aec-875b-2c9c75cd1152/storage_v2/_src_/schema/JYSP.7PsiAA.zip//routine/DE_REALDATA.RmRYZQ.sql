CREATE procedure De_RealData(p_tag in varchar, p_val in number) is
  v_count number;
  v_tagid number;

begin

  select tag_id into v_tagid from dat_tag_tb t where t.tag = p_tag;
  if (v_tagid is null) then
    v_tagid := 0;
  end if;
  select count(1) into v_count from dat_reading_tb where tag_id = v_tagid;
  if (v_count = 1) then
    update dat_reading_tb set reading = p_val where tag_id = v_tagid;
  else
    insert into dat_reading_tb (tag_id, reading) values (v_tagid, p_val);
  end if;
  
end De_RealData;
/

