CREATE VIEW GB_YLRKTJ1_VW AS
  select a."NY",a."GYSID",a."WLID",a."SL",a."RKPH",c.wlbh||','||c.wlgg||','||c.wlmc as wlmc,b.gysbh,b.gysmc from (select ny,gysid,wlid,rkph,sum(sl)sl from
(select wlid,gysid,sl,to_char(rq,'yyyy-mm') ny,rkph from GB_ylrk_tb) group by ny,gysid,wlid,rkph)a
left join GB_gyszd_tb b on a.gysid=b.id
left join GB_wlzd_tb c on a.wlid=c.id
/

