CREATE PACKAGE pkg_session IS

  TYPE parm_type IS TABLE OF varchar2(1000) index BY VARCHAR2(30);

  PROCEDURE set_val(p_idx IN VARCHAR2, p_value IN VARCHAR2);
  PROCEDURE set_val(p_idx IN VARCHAR2, p_value IN NUMBER);
  PROCEDURE set_val(p_idx IN VARCHAR2, p_value IN DATE);

  FUNCTION get_val(p_idx IN VARCHAR2) RETURN VARCHAR2;
  FUNCTION get_val_number(p_idx IN VARCHAR2) RETURN NUMBER;
  FUNCTION get_val_date(p_idx IN VARCHAR2) RETURN DATE;

  PRAGMA RESTRICT_REFERENCES(get_val, WNDS, WNPS);
  PRAGMA RESTRICT_REFERENCES(get_val_number, WNDS, WNPS);
  PRAGMA RESTRICT_REFERENCES(get_val_date, WNDS, WNPS);

END pkg_session;
/

