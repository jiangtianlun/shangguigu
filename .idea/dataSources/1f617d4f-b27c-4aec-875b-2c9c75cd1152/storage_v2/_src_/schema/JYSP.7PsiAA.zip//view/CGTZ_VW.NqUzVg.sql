CREATE VIEW CGTZ_VW AS
  select t3.gysmc, --供应商名称【采购台账】
       t1.dhrq,
       --to_char(t1.dhrq, 'yyyy-MM-dd') as dhrq,--订货日期
       t2.wlid,--物料ID
       t4.wlbh,--物料编号
       t4.wlmc,--物料名称
       t4.ggxh,--规格型号
       t5.dwmc as jldw,--计量单位
       t2.sl,--采购数量
       t2.ksjhrq,--开始交货日期
       t2.jzjhrq,--截止交货日期
       t2.bz,--备注
       t2.dhrq as dhrqmx, --定单明细中的交货日期
       t1.gysid, --供应商编号
       t2.id,
       t5.id as jldwid
  from cgdd2_tb t2
  left join cgdd1_tb t1 on t2.fid = t1.id
  left join gyszd_vw t3 on t1.gysid = t3.id
  left join wlzd_tb t4 on t2.wlid = t4.id
  left join jldw_tb t5 on t4.jldwid = t5.id
 where t2.sl <> 0 and t1.djzt=1 and t1.dhrq>=(sysdate-365) and t3.SFYX=1
 order by t3.gysmc, t1.dhrq, t4.wlbh --按供应商，订货日期，物料编号 排序
/

