CREATE VIEW SP_JYXMMX_VW AS
  select a.id,a.fid,b.jyxmmc,a.jsyq,b.lb from sp_jyxmzd2_tb a left join sp_jyxmzd1_tb b on a.fid=b.id order by b.lb,a.jsyq
/

