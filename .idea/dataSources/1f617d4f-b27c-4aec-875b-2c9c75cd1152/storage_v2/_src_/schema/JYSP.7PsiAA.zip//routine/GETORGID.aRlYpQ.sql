CREATE function getorgid(p_orgid in number) return number is
  result number;
begin
  result := p_orgid;
  return result;
end getorgid;
/

