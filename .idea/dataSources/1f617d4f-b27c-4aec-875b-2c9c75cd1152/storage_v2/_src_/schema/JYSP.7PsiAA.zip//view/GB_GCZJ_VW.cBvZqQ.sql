CREATE VIEW GB_GCZJ_VW AS
  select gyid,ny,jl,count(*) as cs from (select gyid,to_char(rq,'yyyy-mm') as ny,jl from gb_gczj_tb where to_char(rq,'yyyy-mm')>='2019-01' and nvl(zt,0)=2) group by gyid,ny,jl
/

