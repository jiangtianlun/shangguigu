CREATE VIEW YS_ZZSYMX_VW AS
  select yszzid YSZZID,GSLB GSLB
from YS_ZZ_TB  left join (select id,GSLB from YS_ZZZD_TB) t on t.id=YS_ZZ_TB.yszzid  group by yszzid,GSLB
/

