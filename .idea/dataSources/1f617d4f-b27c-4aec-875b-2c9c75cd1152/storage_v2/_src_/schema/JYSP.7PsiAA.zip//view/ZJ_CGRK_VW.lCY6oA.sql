CREATE VIEW ZJ_CGRK_VW AS
  select "ID","FID","WLID","GYSID","DJ","SSSL","DHRQ","RKRQ","BZ","CGDD2ID","KCYKD1ID","PCH","HWHID","DJZT","RD1ID","RKDH"
  from KCRKD2_TB rk2 LEFT JOIN (select djzt ,DJLXid,djbh rkdh,id rd1id,hdbz,cxid from KCRKD1_TB) rk1 on rk2.fid = rk1.rd1id
 WHERE rk1.DJZT = 1 and cxid is null and hdbz=0 and  rk2.rkrq > sysdate -3 AND RK1.DJLXid=3
/

