CREATE function GET_PROPDATA_N_FC(P_OBJ_ID   NUMBER,
                                             P_OBJSX_BM NUMBER)
-- 2007-06-21 create by yangxinzhong  
 return number is
  Result obj_propdata_tb.PROPDATA_N%type;
begin

  SELECT PROPDATA_N
    INTO Result
    FROM OBJ_PROPDATA_TB
   WHERE OBJ_ID = P_OBJ_ID
     AND OBJSX_BM = P_OBJSX_BM;
  return(Result);
EXCEPTION
  WHEN OTHERS THEN
    return NULL;
end GET_PROPDATA_N_FC;
/

