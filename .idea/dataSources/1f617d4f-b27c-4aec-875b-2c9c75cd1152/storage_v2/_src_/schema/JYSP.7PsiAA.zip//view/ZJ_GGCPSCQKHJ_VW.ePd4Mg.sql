CREATE VIEW ZJ_GGCPSCQKHJ_VW AS
  select
zjljid,
sum(zjsl)+sum(xjbfsl) sczs,--实际生产总数,倒推，不以巡检填的数量为准
sum(zjsl)-sum(zjbfbhgs) zzhgs,---终检最终合格数，用终检的验收数量减去终检的报废数
sum(xjbfsl)+sum(zjbfbhgs) sczbhgs,---总的报废数量，巡检加终检的报废数量（也算上了返修数）
round((sum(zjsl)-sum(zjbfbhgs))/(sum(zjsl)+sum(xjbfsl)) ,3) zzhgl,--最终合格率，用终检的验收数量减去终检报废的数量，除以巡检的生产总数
sum(zjsl1)+sum(xjsl1) bhgsl1,
sum(zjsl2)+sum(xjsl2) bhgsl2,
sum(zjsl3)+sum(xjsl3) bhgsl3,
sum(zjsl4)+sum(xjsl4) bhgsl4,
sum(zjsl5)+sum(xjsl5) bhgsl5,
sum(zjsl6)+sum(xjsl6) bhgsl6,
sum(zjsl7)+sum(xjsl7) bhgsl7,--质检成品不合格率合计
sum(zjsl8)+sum(xjsl8) bhgsl8,
sum(zjsl9)+sum(xjsl9) bhgsl9,
sum(zjsl10)+sum(xjsl10) bhgsl10,
sum(zjsl11)+sum(xjsl11) bhgsl11,
sum(zjsl12)+sum(xjsl12) bhgsl12,
sum(zjsl13)+sum(xjsl13) bhgsl13,
to_char(zjscrq,'YYYYMM') NFYF
from
(select zj.id zjid,
       zj.ljid zjljid,
       zj.wllbid zjwllbid,
       zj.djzt zjdjzt,
       zj.bzid zjbzid,
       zj.scrq zjscrq,
       zj.sl zjsl,
       zj.fxs zjfxs,
       zj.fxhgs zjfxhgs,
       zj.bfbhgs zjbfbhgs,
       zj.gxxh,
       zj.zj_xjjl1id zjzj_xjjl1id,
       zj.fid zjfid,
       zj.djlx zjdjlx,
       zj.sl1 zjsl1,
       zj.sl2 zjsl2,
       zj.sl3 zjsl3,
       zj.sl4 zjsl4,
       zj.sl5 zjsl5,
       zj.sl6 zjsl6,
       zj.sl7 zjsl7,
       zj.sl8 zjsl8,
       zj.sl9 zjsl9,
       zj.sl10 zjsl10,
       zj.sl11 zjsl11,
       zj.sl12 zjsl12,
       zj.sl13 zjsl13,
       xj.id xjid,
       xj.ljid xjljid,
       xj.wllbid xjwllbid,
       xj.djzt xjdjzt,
       xj.bzid xjbzid,
       xj.scrq xjscrq,
       xj.sl xjsl,
       xj.bfsl xjbfsl,
       xj.gxxh xjgxxh,
       xj.fid xjfid,
       xj.djlx xjdjlx,
       xj.sl1 xjsl1,
       xj.sl2 xjsl2,
       xj.sl3 xjsl3,
       xj.sl4 xjsl4,
       xj.sl5 xjsl5,
       xj.sl6 xjsl6,
       xj.sl7 xjsl7,
       xj.sl8 xjsl8,
       xj.sl9 xjsl9,
       xj.sl10 xjsl10,
       xj.sl11 xjsl11,
       xj.sl12 xjsl12,
       xj.sl13 xjsl13
  from (select ZJ_CPJYJL.id id,
               ZJ_CPJYJL.ljid ljid,
               wlzd.wllbid wllbid,
               ZJ_CPJYJL.djzt djzt,
               ZJ_CPJYJL.bzid bzid,
               ZJ_CPJYJL.scrq scrq,
               nvl(ZJ_CPJYJL.sl, 0) sl,
               nvl(ZJ_CPJYJL.fxs, 0) fxs,
               nvl(ZJ_CPJYJL.fxhgs, 0) fxhgs,
               nvl(ZJ_CPJYJL.BFbhgs, 0) bfbhgs,
               ZJ_CPJYJL.GXXH gxxh,
               ZJ_CPJYJL.Zj_XJJL1id Zj_XJJL1id,
               --t1.id ,
               t1.fid,
               t1.DJLX,
               nvl(t1.bhgsl1, 0) sl1,
               nvl(t1.bhgsl2, 0) sl2,
               nvl(t1.bhgsl3, 0) sl3,
               nvl(t1.bhgsl4, 0) sl4,
               nvl(t1.bhgsl5, 0) sl5,
               nvl(t1.bhgsl6, 0) sl6,
               nvl(t1.bhgsl7, 0) sl7,
               nvl(t1.bhgsl8, 0) sl8,
               nvl(t1.bhgsl9, 0) sl9,
               nvl(t1.bhgsl10, 0) sl10,
               nvl(t1.bhgsl11, 0) sl11,
               nvl(t1.bhgsl12, 0) sl12,
               nvl(t1.bhgsl13, 0) sl13
          from ZJ_CPJYJL_TB ZJ_CPJYJL
          left join (select * from ZJ_GGBHGSLMX_TB where DJLX = 1) t1 on ZJ_CPJYJL.id =
                                                                         t1.fid
          left join wlzd_tb wlzd on ZJ_CPJYJL.ljid = wlzd.id
         where wllbid  in (320)
           and djzt = 1
           --and to_char(scrq, 'YYYYMM') = 201705
           ) zj
           left join
           (select ZJ_XJJL1.id id,
                    ZJ_XJJL1.ljid ljid,
                    wlzd.wllbid wllbid,
                    ZJ_XJJL1.djzt djzt,
                    ZJ_XJJL1.bzid bzid,
                    ZJ_XJJL1.scrq scrq,
                    nvl(ZJ_XJJL1.sl, 0) sl,
                    nvl(ZJ_XJJL1.BFSL, 0) BFSL,
                    ZJ_XJJL1.GXXH GXXH,
                    --t2.id id2,
                    t2.fid,
                    t2.DJLX,
                    nvl(t2.bhgsl1, 0) sl1,
               nvl(t2.bhgsl2, 0) sl2,
               nvl(t2.bhgsl3, 0) sl3,
               nvl(t2.bhgsl4, 0) sl4,
               nvl(t2.bhgsl5, 0) sl5,
               nvl(t2.bhgsl6, 0) sl6,
               nvl(t2.bhgsl7, 0) sl7,
               nvl(t2.bhgsl8, 0) sl8,
               nvl(t2.bhgsl9, 0) sl9,
               nvl(t2.bhgsl10, 0) sl10,
               nvl(t2.bhgsl11, 0) sl11,
               nvl(t2.bhgsl12, 0) sl12,
               nvl(t2.bhgsl13, 0) sl13
               from ZJ_XJJL1_TB ZJ_XJJL1
               left join (select * from ZJ_GGBHGSLMX_TB where DJLX = 0) t2 on ZJ_XJJL1.id =
                                                                              t2.fid
               left join wlzd_tb wlzd on ZJ_XJJL1.ljid = wlzd.id
              where GXXH = (select MAX(GXXH)
                              from LJSCWLDY_TB LJSCWLDY
                             WHERE LJSCWLDY.LJID = ZJ_XJJL1.LJID)
                and wllbid  in (320)
                and djzt = 1
                --and to_char(scrq, 'YYYYMM') = 201705
                ) xj on zj.zj_xjjl1id =xj.id
                order by zj.scrq) ggcpbhgltj
                ---group by grouping sets( (zjbzid,to_char(zjscrq,'YYYYMM'),zjljid ),zjbzid)
                group by zjljid,to_char(zjscrq,'YYYYMM') ---having to_char(zjscrq,'YYYYMM')='201705'
/

