CREATE VIEW VW_PUFIELD AS
  select fld_bm ,fld_key,fld_entitykey  from suf_field_tb
/

