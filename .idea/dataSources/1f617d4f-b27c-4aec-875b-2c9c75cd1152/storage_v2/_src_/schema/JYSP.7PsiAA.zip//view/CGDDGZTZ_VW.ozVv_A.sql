CREATE VIEW CGDDGZTZ_VW AS
  with cgjfd as (select sssl,b.ywrq as rkrq,cgdd2id from cgjfd2_tb a left join (select id,ywrq from cgjfd1_tb t1 where t1.djzt=1 and t1.zdrq>sysdate-365)b on a.fid=b.id) --将采购交付单父子表做关联
select "GYSMC","DHRQ","WLID","WLBH","WLMC","GGXH","JLDW","SL","KSJHRQ","JZJHRQ","BZ","DHRQMX","GYSID","ID",jldwid,
 "'01'" as d01,"'02'" as d02,"'03'" as d03,"'04'" as d04,"'05'" as d05,"'06'" as d06,"'07'" as d07,"'08'" as d08,"'09'" as d09,"'10'" as d10, --将字段'01'改名为d01,'02'改名为d02,......
 "'11'" as d11,"'12'" as d12,"'13'" as d13,"'14'" as d14,"'15'" as d15,"'16'" as d16,"'17'" as d17,"'18'" as d18,"'19'" as d19,"'20'" as d20,--将字段'11'改名为d11,'12'改名为d12,......
 "'21'" as d21,"'22'" as d22,"'23'" as d23,"'24'" as d24,"'25'" as d25,"'26'" as d26,"'27'" as d27,"'28'" as d28,"'29'" as d29,"'30'" as d30,"'31'" as d31 --将字段'21'改名为d21,'22'改名为d22,......
 from (select a2.*,case when a2.m1=a2.m2 then 1 else -1 end as fh from --a2.m1>a2.m2 or a2.m1<a2.m2 then -1 else 1 end as fh from
 (select a1.*,cgjfd.sssl,to_char(cgjfd.rkrq,'dd') dd,to_char(cgjfd.rkrq,'mm')m1,to_char(a1.dhrq,'mm')m2 from cgtz_vw a1 left join --将采购台账a1 与 采购交付单2做关联，a2.sssl：到货数量,dd:到货日期（日）
  cgjfd on a1.id=cgjfd.cgdd2id  --a2是1年内已审核的采购交付单,rkrq是到货日期
 )a2)
 pivot (sum(sssl*fh) for dd in ('01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31')) --行变列转换
 order by gysid,dhrq,wlid --按供应商ID，订货日期，物料ID排序
/

