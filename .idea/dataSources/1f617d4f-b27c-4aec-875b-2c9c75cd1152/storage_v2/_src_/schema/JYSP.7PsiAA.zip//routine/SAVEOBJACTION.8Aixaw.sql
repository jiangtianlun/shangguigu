CREATE procedure saveObjAction(obj_id   in number,
                                          p_name   in varchar2,
                                          assetid  in number,
                                          Act_type in number) is
  v_obj_act_id number := 0;
  pro_id       number := 0;
  /*vsql varchar2(1000);*/
  cursor cur_objAct is
    select t.object_action_id
      from ko_obj_action_tb t
     where t.object_id = obj_id
       and t.project_id = pro_id
       and t.object_action_type = act_type;

  cursor cur_getP_id is
    select id
      from ko_project_tb t
     where t.pro_name = p_name
       and rownum = 1;
begin
  --vsql :='select id  from ko_project_tb t where t.pro_name='||pro_name||' and rownum=1';
  --select id  into pro_id from ko_project_tb t where t.pro_name=pro_name and rownum=1 ;

  open cur_getP_id;
  loop
    fetch cur_getP_id
      into pro_id;
    exit when cur_getP_id %notfound;
  end loop;
  close cur_getP_id;
  ---into pro_id
  --- 判断是否存在对应的ObjAction ,存在就更新，不存在插入
  open cur_objAct;
  loop
    fetch cur_objAct
      into v_obj_act_id;
    exit when cur_objAct %notfound;
  end loop;
  close cur_objAct;

  if v_obj_act_id <> 0 then
    update ko_obj_action_tb t
       set t.asset_id = assetid
     where t.object_id = obj_id
       and t.project_id = pro_id
       and t.object_action_type = Act_type;
  else
  
    insert into ko_obj_action_tb
      (object_action_id,
       object_action_type,
       object_id,
       asset_id,
       project_id)
    values
      (seqobjaction.nextval, Act_type, obj_id, assetid, pro_id);
  end if;

end saveObjAction;

  --ko_project_tb
/

