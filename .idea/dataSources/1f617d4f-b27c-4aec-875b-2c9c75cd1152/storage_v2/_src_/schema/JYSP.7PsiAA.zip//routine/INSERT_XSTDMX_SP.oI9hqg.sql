CREATE procedure INSERT_XSTDMX_SP(p_fid in number,p_num in number)
as
--
 v_num number:= p_num;
begin
loop
exit when v_num < 1;
insert into XSTDMX_TB(ID,FID) SELECT SEQXSTDMX.NEXTVAL,p_fid FROM DUAL;
v_num := v_num -1;
end loop;
end INSERT_XSTDMX_SP;
/

