CREATE package DotNet is
type T_CURSOR is ref cursor;
PROCEDURE DotNetPagination --完成分页功能
(
Pindex in number, --分页索引
Psql in long, --产生dataset的sql语句
Psize in number, --页面大小
Pcount out number, --返回分页总数
v_cur out T_CURSOR, --返回当前页数据记录
Prcount out number --返回记录总数
);
end DotNet;

/

