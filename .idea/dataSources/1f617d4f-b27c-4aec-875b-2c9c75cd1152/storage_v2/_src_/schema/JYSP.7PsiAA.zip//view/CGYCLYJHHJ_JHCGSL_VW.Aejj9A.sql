CREATE VIEW CGYCLYJHHJ_JHCGSL_VW AS
  select cg.id,cg.wlid,ceil(case when nvl(cg.xqsl,0)-nvl(cg.yclkc,0)-nvl(cg.bcpyclkc,0)<0 then 0 else nvl(cg.xqsl,0)-nvl(cg.yclkc,0)-nvl(cg.bcpyclkc,0) end) jhcgsl2 from CGYCLYJHHJ_TB cg left join wlzd_tb wl on cg.wlid=wl.id where cg.djzt=0 and cg.djlx=2
/

