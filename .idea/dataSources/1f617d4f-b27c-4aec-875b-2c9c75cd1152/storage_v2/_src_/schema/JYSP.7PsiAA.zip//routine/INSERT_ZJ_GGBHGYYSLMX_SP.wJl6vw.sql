CREATE procedure INSERT_ZJ_GGBHGYYSLMX_SP(p_fid in number,p_num in number)
as
----Wy.PU63803新增1行
 v_num number:= p_num;
begin
loop
exit when v_num < 1;
insert into ZJ_GGBHGSLMX_TB (ID,FID,Djlx) SELECT SEQZJ_GGBHGSLMX.NEXTVAL,p_fid,1 FROM DUAL;
v_num := v_num -1;
end loop;
end INSERT_ZJ_GGBHGYYSLMX_SP;
/

