CREATE VIEW VW_PU_DIFFSTATISTICAL AS
  select sd.DESCRIPTION_ID DID,
       sc.CROL_BM DKEY,
       sc.PU_BM PU,
       sd.Description_Date DDATE,
       0 as DTYPE,
       (select count(DESCRIPTION_ID)
          from vw_newdescription
         where sd.description_id = description_id) DSTATYPE
  from suf_control_tb sc, suf_description_tb sd
 where sd.DESCRIPTION_KEY = sc.CROL_BM
   and DESCRIPTION_TP = 1
   and DESCRIPTION_TYPE = 1
   and sc.crol_pagetype=0
--控件卡片
union all
select sd.DESCRIPTION_ID DID,
       sc.CROL_BM DKEY,
       sc.PU_BM PU,
       sd.Description_Date DDATE,
       1 as DTYPE,
       (select count(DESCRIPTION_ID)
          from vw_newdescription
         where sd.description_id = description_id) DSTATYPE
  from suf_control_tb sc, suf_description_tb sd
 where sd.DESCRIPTION_KEY = sc.CROL_BM
   and DESCRIPTION_TP = 1
   and DESCRIPTION_TYPE = 1
   and sc.crol_pagetype=1
union all
--数据域 网格
select sd.DESCRIPTION_ID DID,
       sf.fld_bm DKEY,
       sf.PU_BM PU,
       sd.Description_Date DDATE,
       2 as DTYPE,
       (select count(DESCRIPTION_ID)
          from vw_newdescription
         where sd.description_id = description_id) DSTATYPE
  from suf_field_tb sf, suf_description_tb sd
 where sd.DESCRIPTION_KEY = sf.fld_bm
   and DESCRIPTION_TP = 2
   and DESCRIPTION_TYPE = 1
union all
--数据域 卡片
select sd.DESCRIPTION_ID DID,
       sf.fld_bm DKEY,
       sf.PU_BM PU,
       sd.Description_Date DDATE,
       3 as DTYPE,
       (select count(DESCRIPTION_ID)
          from vw_newdescription
         where sd.description_id = description_id) DSTATYPE
  from suf_field_tb sf, suf_description_tb sd
 where sd.DESCRIPTION_KEY = sf.fld_bm
   and DESCRIPTION_TP = 3
   and DESCRIPTION_TYPE = 1
union all
--程序单元
select sd.DESCRIPTION_ID DID,
       sp.pu_bm DKEY,
       sp.pu_bm PU,
       sd.Description_Date DDATE,
       4 as DTYPE,
       (select count(DESCRIPTION_ID)
          from vw_newdescription
         where sd.description_id = description_id) DSTATYPE
  from suf_programunit_tb sp, suf_description_tb sd
 where sd.DESCRIPTION_KEY = sp.pu_bm
   and DESCRIPTION_TP = 4
   and DESCRIPTION_TYPE = 1
/

