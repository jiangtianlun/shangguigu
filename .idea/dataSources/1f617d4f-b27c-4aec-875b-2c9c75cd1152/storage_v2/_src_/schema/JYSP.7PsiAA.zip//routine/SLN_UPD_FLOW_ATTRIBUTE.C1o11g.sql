CREATE PROCEDURE SLN_UPD_FLOW_ATTRIBUTE(
                                              P_ATTRIBUTE_ID in number,
                                              P_UNIT_ID in number,
                                              P_U_NAME in varchar2,
                                              P_U_TYPE in varchar2,
                                              P_U_MEMO in varchar2,
                                              P_U_FORMULA in varchar2,
                                              P_ATTRIBUTE_ISKEY in number,
                                              P_FLAG in number,--新增0，更新1标志
                                              P_U_NO in varchar2,
                                              P_U_ALARM in varchar2
                                              ) as

begin
if(P_FLAG=0) then
    insert into FLOW_ATTRIBUTE_TB(
       ATTRIBUTE_ID,
       UNIT_ID,
       U_NAME,
       U_TYPE,
       U_MEMO,
       U_FORMULA,
       ATTRIBUTE_ISKEY,
       U_NO,
       U_ALARM) values(
       P_ATTRIBUTE_ID,
       P_UNIT_ID,
       P_U_NAME,
       P_U_TYPE,
       P_U_MEMO,
       P_U_FORMULA,
       P_ATTRIBUTE_ISKEY,
       P_U_NO,
       P_U_ALARM);

else
    update FLOW_ATTRIBUTE_TB set
       UNIT_ID = P_UNIT_ID,
       U_NAME=P_U_NAME,
       U_TYPE=P_U_TYPE,
       U_MEMO=P_U_MEMO,
       U_FORMULA=P_U_FORMULA,
       ATTRIBUTE_ISKEY=P_ATTRIBUTE_ISKEY,
       U_NO=P_U_NO,
       U_ALARM=P_U_ALARM
       where ATTRIBUTE_ID=P_ATTRIBUTE_ID;
end if;
commit;
end SLN_UPD_FLOW_ATTRIBUTE;
/

