CREATE VIEW GET_TABLE_RECORDS_VW AS
  select t.num_rows JLSL, t.table_name BM,t2.comments BMZS
          from dba_tab_statistics t
          left join user_tab_comments t2 on t.table_name = t2.table_name
         where t.owner = 'JYSP'
           and t.table_name != 'A'
           and t.table_name not like '%SUF_%'
           and t.table_name not like 'DAT_%'
           and t.table_name not like 'KO_%'
           and t.table_name not like 'OA_%'
           and t.table_name not like 'AUTH_%'
           and t.table_name not like 'DF_%'
           and t.table_name not like 'FLOW_%'
           and t.table_name not like 'XK_%'
           and t.table_name not like 'ORA_%'
           and t.table_name not like 'RPT_%'
           and t.table_name not like 'BASE_%'
           and t.table_name not like 'ZX_%'
           and t.table_name like 'SP_%'
           and t.table_name not like 'OBJ_%'
           and t.table_name not like 'SYS_%'
           and t.table_name not like 'BB_%'
           and t.table_name not like 'TABLE_%'
           and t.table_name not like 'ASK_%'
           and t.table_name not like 'TEST_%'
           and t.table_name not like 'TEST_%'
/

