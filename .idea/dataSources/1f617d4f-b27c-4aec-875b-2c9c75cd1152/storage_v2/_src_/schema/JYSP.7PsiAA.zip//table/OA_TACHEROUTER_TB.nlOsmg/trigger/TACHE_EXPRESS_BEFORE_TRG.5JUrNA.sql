CREATE TRIGGER TACHE_EXPRESS_BEFORE_TRG
  BEFORE INSERT OR UPDATE OR DELETE
  ON OA_TACHEROUTER_TB
  FOR EACH ROW
  declare
begin
  case
    when inserting or updating then
      data_tacheid.tacheid := :new.tacheid;
    when deleting then
      data_tacheid.tacheid := :old.tacheid;
  end case;
end tache_express_before_trg;

/

