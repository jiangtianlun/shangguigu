CREATE VIEW YF_MLRKHZ_VW AS
  select mlid, gysid, ddbh,rkrq, sum(sl) rksl
    from (select mlid, gysid,ddbh,to_char(rkrq, 'yyyy-mm') rkrq, sl
            from yf_mlck_tb t
           where rkrq is not null)
   group by mlid, gysid, ddbh,rkrq
   order by rkrq, gysid, ddbh,mlid
/

