CREATE TRIGGER DAT_READING_TG
  AFTER UPDATE
  ON DAT_READING_TB
  FOR EACH ROW
  BEGIN

        IF UPDATING THEN
            INSERT INTO dat_history_tb
            VALUES(SEQDAT_HISTORY.NEXTVAL,
                   :new.tag_id ,
                   SYSDATE,
                   :NEW.reading
                   );
         END IF;

END dat_reading_TG;

/

