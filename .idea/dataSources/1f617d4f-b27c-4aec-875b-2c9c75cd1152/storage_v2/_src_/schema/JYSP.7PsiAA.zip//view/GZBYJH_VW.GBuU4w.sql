CREATE VIEW GZBYJH_VW AS
  select tz.id,---工装保养计划单
        tz.gzbh,
        tz.gzmc,
        jh.nf,
        jh.yf,
        jh.nf || jh.yf byny,
        jh.wczt,
        jh.wcrq
   from gzbyjh_tb jh
   left join gztz_tb tz on tz.id = jh.gzid
/

