CREATE VIEW WLXCRK_VW AS
  select wllbid,KHMC,yszzid,sum(nvl(sysl,0)) SYSL,sum(nvl(hssl,0)) HSSL,to_char(ywrq, 'YYYYMM') YWRQ
  from KCCKD2_TB kcckd2
  left join KCCKD1_TB kcckd1 on kcckd2.fid = kcckd1.id
  left join wlzd_tb wlzd on wlzd.id=kcckd2.wlid
  left join khzd_vw khzd on wlzd.wllbid=khzd.id
 where djlxid in (6, 161)
  and to_char(ywrq, 'YYYYMM') = 201708
 --order by kcckd2.id
 group by wllbid,KHMC,yszzid,to_char(ywrq, 'YYYYMM')
 having yszzid is not null
/

