CREATE FUNCTION GET_WLMC(gys Number)
 return  VARCHAR2 IS COMMS VARCHAR2(2000) DEFAULT ' ';
begin
  FOR COMM IN(select a.lbmc from (select distinct wl.wllbid from wlgysdy_tb dy left join wlzd_tb wl on dy.wlid=wl.id where dy.gysid=gys)t left join wllb_tb a on a.id=t.wllbid) LOOP
   begin
     COMMS := COMMS  || COMM.lbmc || ',';
   end;
  end LOOP;  
  return substr(COMMS,0,length(COMMS)-1);
END GET_WLMC;
/

