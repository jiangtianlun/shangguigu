CREATE procedure oa_delegate_del_sp is
  --  oa_delegate_del_sp 删除委托数据

begin
  delete from oa_delegationmenu_tb;
  delete from oa_delegation_tb;
  commit;

end oa_delegate_del_sp;
/

