CREATE VIEW VW_LATESTDESCRIPTION AS
  select aa.DESCRIPTION_ID,
       aa.DESCRIPTION_DES,
       aa.DESCRIPTION_KEY,
       aa.DESCRIPTION_TYPE,
       aa.DESCRIPTION_STATE,
       aa.DESCRIPTION_DATE,
       aa.description_tp
  from suf_description_tb AA,
       (select max(DESCRIPTION_DATE) DDATE,
               DESCRIPTION_KEY,
               DESCRIPTION_TYPE
          from suf_description_tb
         group by DESCRIPTION_KEY, DESCRIPTION_TYPE) BB
 where aa.description_key = bb.description_key
   and aa.description_type = bb.description_type
   and aa.description_date = bb.DDATE
/

