CREATE VIEW CGBCPYJHHJ_VW AS
  select wlid,wl.wlbh wlbhdl,sum(xqsl) sl ,chang,kuan,gao,fjlx,nfyf,DJLX from cgyclyjh_tb cg left join wlzd_tb wl on cg.wlid=wl.id  where cg.nfyf='201801' and cg.djzt=0 and cg.fjlx=1 AND cg.djlx=1 group by DJLX, wlid,wl.wlbh,nfyf,chang,kuan,gao,fjlx
/

