CREATE VIEW ZJ_CPMTZZHGLTJ_VW AS
  select t1.bzid,
        t1.ljid,
        nvl(t1.sl, 0)+nvl(t2.bfsl,0) szzs,--用终检的数量加上巡检报废的数量
        nvl(t1.sl, 0) -(nvl(t1.bfbhgs, 0) + (nvl(t1.fxs, 0) - nvl(t1.fxhgs, 0))) zzhgs,
        --终检的实际数量减去终检报废的数量以及可返修不合格数与返修合格数的差额，再除以巡检的生产总数
        round((nvl(t1.sl, 0) -(nvl(t1.bfbhgs, 0) + (nvl(t1.fxs, 0) - nvl(t1.fxhgs, 0))))/(nvl(t1.sl, 0)+nvl(t2.bfsl,0)),3) zzhgl,
        t1.scrq NFYF
        --to_char(t1.scrq,'YYYYMM') NFYF
   from ZJ_CPJYJL_TB t1
   left join Zj_Xjjl1_Tb t2 on t1.Zj_Xjjl1id = t2.id where t1.djzt=1
/

