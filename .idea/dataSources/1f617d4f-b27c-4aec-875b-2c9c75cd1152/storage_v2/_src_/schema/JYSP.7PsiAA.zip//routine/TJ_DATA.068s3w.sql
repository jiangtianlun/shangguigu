CREATE procedure tj_data as
  -- 当前存储过程用到的变量
  v_tableName VARCHAR2(100);
  v_sql  varchar2(200);
  v_count integer;

  -- 获取当前数据库中的所有表
  CURSOR TABLE_LOOP IS SELECT Table_name FROM User_tables;
  begin
    -- 打开游标
    delete from A;
    OPEN TABLE_LOOP;
      LOOP
        FETCH TABLE_LOOP INTO v_tableName;
          EXIT WHEN TABLE_LOOP %NOTFOUND;
              v_sql:= 'select count(1) from '||v_tableName;
              execute immediate v_sql into v_count;
              insert into a values (v_tableName,v_count);
      END LOOP;
    CLOSE TABLE_LOOP;
end;
/

