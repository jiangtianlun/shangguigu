CREATE VIEW ORA_VW_ASPNET_MEMUSERS AS
  SELECT m.UserId,
       m.PasswordFormat,
       m.MobilePIN,
       m.Email,
       m.LoweredEmail,
       m.PasswordQuestion,
       m.PasswordAnswer,
       m.IsApproved,
       m.IsLockedOut,
       m.CreateDate,
       m.LastLoginDate,
       m.LastPasswordChangedDate,
       m.LastLockoutDate,
       m.FailedPwdAttemptCount,
       m.FailedPwdAttemptWinStart,
       m.FailedPwdAnswerAttemptCount,
       m.FailedPwdAnswerAttemptWinStart,
       m.Comments,
       u.ApplicationId,
       u.UserName,
       u.MobileAlias,
       u.IsAnonymous,
       u.LastActivityDate
FROM ora_aspnet_Membership m, ora_aspnet_Users u
WHERE m.UserId = u.UserId
WITH READ ONLY
/

