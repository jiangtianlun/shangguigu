CREATE procedure get_wl_refer_count(p_wlid in number) is
v_cnt number:=0;
begin  
SELECT  COUNT(1) into v_cnt FROM TABLE(FK_UTIL.get_refered_count('WLZD_TB', p_wlid)) WHERE REFER_COUNT >0;
if v_cnt =0 then 
update wlzd_tb set sfyx=0 where  sfyx =1 and id = p_wlid ;
else
 RAISE_APPLICATION_ERROR(-20002,'该物料已被引用，不能设置无效！');
end if; 
end get_wl_refer_count;

/

