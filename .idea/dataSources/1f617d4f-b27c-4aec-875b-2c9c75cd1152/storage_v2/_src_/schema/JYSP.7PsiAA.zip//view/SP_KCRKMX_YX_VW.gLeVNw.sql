CREATE VIEW SP_KCRKMX_YX_VW AS
  select t1.djbh,
       t1.djzt,
       t1.djlxid,
       t1.ckid,
       t1.shrid,
       trunc(t1.zdrq, 'dd') zdrq,
       t2."ID",
       t2."FID",
       t2."WLID",
       t2."GYSID",
       t2."SSSL",
       t2."DJ",
       t2."BZ",
       t2.ph,
       t2.je
  from sp_kcrkd1_tb t1, sp_kcrkd2_tb t2
 where t1.id = t2.fid
   and t1.djzt = 1
   and t1.djbh != '生成单号出错'
   and wlid is not null
union all
select t2.djbh,
       t2.djzt,
       t2.djlxid,
       t2.ckid,
       t2.shrid,
       trunc(t2.zdrq, 'dd') zdrq,
       t2.id,
       t2.fid,
       t2."WLID",
       t2."GYSID",
       t2."SSSL",
       t2."DJ",
       t2."BZ",
       t2.ph,
       t2.je
  from sp_kcrkd2_tb t2
 where t2.djbh is not null and t2.djzt = 1
   with read only
/

