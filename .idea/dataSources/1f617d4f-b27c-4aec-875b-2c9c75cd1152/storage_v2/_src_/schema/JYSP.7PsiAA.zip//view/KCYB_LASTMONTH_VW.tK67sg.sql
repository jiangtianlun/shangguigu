CREATE VIEW KCYB_LASTMONTH_VW AS
  select wlid,wl.ckid,sum(sssl) rksl,sum(sfsl) cksl,to_char(add_months(sysdate,-1), 'yyyy') nf,to_char(add_months(sysdate,-1), 'mm') yf
from
--徐文豪2017-11-11,提取上个月的成品零件总入库和总出库数量
(select ck2.wlid, null sssl, ck2.sfsl
          from kcckd1_tb ck1
          left join kcckd2_tb ck2 on ck1.id = ck2.fid
         where ck1.djzt=1 and ck1.ywrq between trunc(add_months(sysdate,-1), 'mm')
                        and last_day(add_months(sysdate, -1))
        union all
        select rk2.wlid, rk2.sssl sl, null sfsl
          from kcrkd1_tb rk1
          left join kcrkd2_tb rk2 on rk1.id = rk2.fid
        where rk1.djzt=1 and rk1.ywrq between trunc(add_months(sysdate,-1), 'mm')
                        and last_day(add_months(sysdate, -1))
)bykcyb,  wlzd_tb wl
 where wl.ckid in (1273, 1257)
   and bykcyb.wlid = wl.id
group by bykcyb.wlid, wl.ckid
/

