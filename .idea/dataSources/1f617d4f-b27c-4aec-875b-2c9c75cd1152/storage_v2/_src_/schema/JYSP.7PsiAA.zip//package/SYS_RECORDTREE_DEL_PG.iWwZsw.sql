CREATE package SYS_RECORDTREE_DEL_PG is

  -- Author  : lishiji
  -- Created : 2006-12-21 9:42:04
  -- Purpose : 递归删除父表,及子表记录

  procedure DEL_ZB_SP(p_bm number, p_tn varchar2);
  procedure SYS_RECORDTREE_DEL_SP(p_bm number, p_tn varchar2);

end SYS_RECORDTREE_DEL_PG;


/

