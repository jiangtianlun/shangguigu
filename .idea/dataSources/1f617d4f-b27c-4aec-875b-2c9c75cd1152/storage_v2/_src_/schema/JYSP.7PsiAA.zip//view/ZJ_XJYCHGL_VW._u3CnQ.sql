CREATE VIEW ZJ_XJYCHGL_VW AS
  select BZID,
       ljid,
       sum(sl) SCZS,
       sum(nvl(BFSL, 0)) BFSL,
       round(((sum(nvl(SL,0))-sum(nvl(BFSL,0)))/sum(SL)),3) YCHGL,
       to_char(scrq, 'yyyymm') NFYF
  from ZJ_XJJL1_TB
  where to_char(scrq, 'yyyymm')=201705 and DJZT=1
 group by grouping sets((BZID,to_char(scrq, 'yyyymm')  ,ljid),bzid)
/

