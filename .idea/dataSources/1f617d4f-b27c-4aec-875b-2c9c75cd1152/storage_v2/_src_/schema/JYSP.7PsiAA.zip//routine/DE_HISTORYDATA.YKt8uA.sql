CREATE procedure De_HistoryData(p_tag  in varchar,
                                           p_val  in number,
                                           p_time in varchar2) is
  v_count number;
  v_tagid number;
  v_time  date := to_date(p_time, 'yyyy-mm-dd hh24:mi:ss');

begin

  select tag_id into v_tagid from dat_tag_tb t where t.tag = p_tag;

  if (v_tagid is null) then
    v_tagid := 0;
  end if;

  select count(1)
    into v_count
    from dat_history_tb
   where tag_id = v_tagid
     and u_time = v_time;

  if (v_count = 1) then
    update dat_history_tb
       set reading = p_val
     where tag_id = v_tagid
       and u_time = v_time;
  else
    insert into dat_history_tb
      (history_id, tag_id, reading, u_time)
    values
      (seqdat_history.nextval, v_tagid, p_val, v_time);
  end if;
end De_HistoryData;
/

