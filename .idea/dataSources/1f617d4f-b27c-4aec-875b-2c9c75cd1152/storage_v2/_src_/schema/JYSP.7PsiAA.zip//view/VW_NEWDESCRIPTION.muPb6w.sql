CREATE VIEW VW_NEWDESCRIPTION AS
  select aa.DESCRIPTION_ID,aa.description_key,aa.description_type
  from suf_description_tb AA,
       (select min(DESCRIPTION_DATE) DDATE,
               DESCRIPTION_KEY,
               DESCRIPTION_TYPE
          from suf_description_tb
         group by DESCRIPTION_KEY, DESCRIPTION_TYPE) BB
 where aa.description_key = bb.description_key
   and aa.description_type = bb.description_type
   and aa.description_date = bb.DDATE
/

