CREATE PROCEDURE SLN_UPD_FLOW_UNIT(P_UNIT_ID in number,
                                              P_OBJ_ID  in number,
                                              P_GROUP_ID in number,
                                              P_U_NAME in varchar2,
                                              P_U_TYPE in varchar2,
                                              P_U_MEMO in varchar2,
                                              P_FLAG in number,
                                              P_U_NO in varchar2--新增0，更新1标志
                                              ) as
    
begin
if(P_FLAG=0) then
    insert into FLOW_UNIT_TB(
       UNIT_ID,
       OBJ_ID,
       GROUP_ID,
       U_NAME,
       U_TYPE,
       U_MEMO,
       U_NO) values(
       P_UNIT_ID,
       P_OBJ_ID,
       P_GROUP_ID,
       P_U_NAME,
       P_U_TYPE,
       P_U_MEMO,
       P_U_NO);

else
    update Flow_Unit_Tb set
       OBJ_ID=P_OBJ_ID,
       GROUP_ID=P_GROUP_ID,
       U_NAME=P_U_NAME,
       U_TYPE=P_U_TYPE,
       U_MEMO=P_U_MEMO,
       U_NO=P_U_NO
       where UNIT_ID=P_UNIT_ID;
end if;
commit;
end;
/

