CREATE function BASE_LENGTHLIMIT_FC(P_TEXT in varchar2,
                                               P_LEN  in number)
  return varchar2 as
  Result varchar2(4000);
begin
  if length(P_TEXT) <= P_LEN then
    Result := P_TEXT;
  else
    Result := substr(P_TEXT, 0, P_LEN) || '....';
  end if;
  return(Result);
end BASE_LENGTHLIMIT_FC;
/

