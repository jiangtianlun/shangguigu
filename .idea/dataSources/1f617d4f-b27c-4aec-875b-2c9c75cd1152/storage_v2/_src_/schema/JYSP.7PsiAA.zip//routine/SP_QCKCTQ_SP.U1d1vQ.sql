CREATE procedure SP_QCKCTQ_SP (P_TQRQ   in varchar,
                                          P_ZDRID  IN number,
                                          P_CKID   IN number,
                                          P_DJLXID IN number) --传入P_TQRQ,P_ZDRID用于提取
 as

begin
  --每月不可重复提取
  if 1 = 1 then
    --设置开始时间为提取日期所在月的上一个月的第一天
    UPDATE SP_SJCS_TB
       SET KSRQ = LAST_DAY(ADD_MONTHS(TO_DATE(P_TQRQ,
                                              'YYYY-MM-DD hh24:mi:ss'),
                                      -2)) + 1
     WHERE 1 = 1;
    --设置结束时间为提取日期所在月的上一个月的最后一天
    UPDATE SP_SJCS_TB
       SET JSRQ = TRUNC(TO_DATE(P_TQRQ, 'YYYY-MM-DD hh24:mi:ss'), 'MM') - 1
     WHERE 1 = 1;

    --根据仓库id执行不同仓库的生成期初库存
    insert into SP_QCKC_TB
          (id, djzt, djlxid, wlid, ckid, qckc,qcje,pdsl,pdje,zdrq, zdrid, ywrq, ph)
          select seqsp_qckc.nextval,
                 0,
                 P_DJLXID,
                 wlid,
                 P_CKID,
                 bqjy,
                 bqjyje,
                 bqjy,
                 bqjyje,
                 to_date(P_TQRQ, 'YYYY-MM-DD'), --制单日期为提取日期
                 P_ZDRID,
                 trunc(to_date(P_TQRQ, 'YYYY-MM-DD'), 'mm'), --业务日期为提取日期所在月份的第一天
                 ph
            from RD_JXC_VW t1
           where t1.ckid = p_ckid
             and not exists
           (select 1
                    from sp_qckc_tb t2
                   where t2.wlid = t1.wlid
                     and t2.qckc = t1.bqjy
                     and t2.ph = t1.ph
                     and to_char(t2.ywrq, 'YYYY-MM-DD') =
                         to_char(trunc(to_date(P_TQRQ, 'YYYY-MM-DD'), 'mm'),
                                 'YYYY-MM-DD'));


  --v_ts := '提取期初库存成功！';
  --return v_ts;
  end if;
  commit;
exception
  when others then
    rollback;
    --return '当月已生成期初库存，不可重复提取！';
end RD_QCKCTQ_SP;
/

