CREATE procedure SYS_CREATE_SYNONYM_SP(P_PTUSER  VARCHAR2) is

-- 2010-05-06 ZXM 创建平台库对象的同义词
V_SQL VARCHAR2(1000);

CURSOR cur_objects is
      select 'create or replace synonym '||t.object_name ||' for '||P_PTUSER||'.'||t.object_name||';  ' as sy
        from user_objects t
       where t.object_type IN
            ( 'TABLE','FUNCTION','PACKAGE BODY','PROCEDURE','SEQUENCE','VIEW') 
       ORDER BY T.OBJECT_TYPE;
cur_objects_rt  cur_objects%rowtype;
      

begin
     -- 1 
     begin
          V_SQL :='create table SUF_synonym_tb(synonym_mc  varchar2(1000) ) ';
          execute immediate V_SQL;
     exception when others then
          V_SQL :='DELETE FROM SUF_synonym_tb';
          execute immediate V_SQL;
     end;
     
     --2  purge recyclebin
     
     --3 
     for cur_objects_rt in cur_objects
     loop
         v_sql:='insert into SUF_synonym_tb(synonym_mc) values(:synonym_mc)';
         execute immediate v_sql using cur_objects_rt.sy;
     end loop;
     
  
end SYS_CREATE_SYNONYM_SP;























/

