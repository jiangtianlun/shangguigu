CREATE function FC_PU_MENUCHANGE(P_MENUID in number,
                                            P_STA    in date,
                                            P_END    in date) return number as
  result number;
  ic     number;
begin
  result := 0;
  select count(DID)
    into ic
    from vw_pu_diffstatistical
   where to_char(PU) in
         (select SUBPU
            from vw_pu_subpu
           where pu = (select pu from vw_menu_pu where MENU_ID = P_MENUID)
          union
          select pu from vw_menu_pu where MENU_ID = P_MENUID)
     and DDATE > P_STA
     and DDATE <= P_END;
  if ic > 0 then
    result := 1;
  end if;
  return(result);
end FC_PU_MENUCHANGE;
/

