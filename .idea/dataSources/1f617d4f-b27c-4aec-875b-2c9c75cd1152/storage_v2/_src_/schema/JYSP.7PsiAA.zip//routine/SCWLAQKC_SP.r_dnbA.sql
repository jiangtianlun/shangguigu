CREATE PROCEDURE SCWLAQKC_SP(P_NFYF  IN VARCHAR2,
                                        P_ZDRID IN NUMBER) IS
  ------徐文豪2017/07/12，根据采购原材料月计划合计生成每月的物料安全库存记录
  ------徐文豪2017/11/10，生成所有物料字典的安全库存记录，加入更新人ID和更新日期

  CURSOR CUR_IMPDATA IS
    SELECT T.ID WLID,CKID
      FROM WLZD_TB T
     WHERE T.CKID IN (1212, 1214, 1273, 1257)
       --AND T.WLLY = 0
       AND T.SFYX = 1;
  V_WL     CUR_IMPDATA%ROWTYPE;
  V_CNT    NUMBER;
  V_YJH    NUMBER;
BEGIN
  SAVEPOINT V_SP_0000;
  OPEN CUR_IMPDATA;
  LOOP
    FETCH CUR_IMPDATA
      INTO V_WL;
    EXIT WHEN CUR_IMPDATA%NOTFOUND;

    SELECT COUNT(1)
      INTO V_YJH
      FROM CGYCLYJHHJ_TB
     WHERE WLID = V_WL.WLID
       AND NFYF = P_NFYF
       AND DJLX = 1;

    SELECT COUNT(1)
      INTO V_CNT 
      FROM WLAQKC_TB
     WHERE WLID = V_WL.WLID
       AND NFYF = P_NFYF;

   IF V_CNT = 0 THEN
    INSERT INTO WLAQKC_TB(ID, WLID, NFYF, ZDRID, ZDRQ, DJZT, CKID)
            SELECT SEQWLAQKC.NEXTVAL,
                   V_WL.WLID,
                   P_NFYF,
                   P_ZDRID,
                   SYSDATE,
                   V_YJH,
                   V_WL.CKID
              FROM DUAL;
   END IF;
   
   IF V_CNT <> 0 THEN
    UPDATE WLAQKC_TB
       SET WLID  = V_WL.WLID,
           NFYF  = P_NFYF,
           ZDRID = P_ZDRID,
           ZDRQ  = SYSDATE,
           DJZT  = V_YJH,
           CKID = V_WL.CKID
     WHERE WLID = V_WL.WLID and NFYF = P_NFYF;
   END IF;
  END LOOP;
  CLOSE CUR_IMPDATA;
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    RAISE_APPLICATION_ERROR(-20009, SQLERRM);
    ROLLBACK TO SAVEPOINT V_SP_0000;
    commit;
END SCWLAQKC_SP;
/

