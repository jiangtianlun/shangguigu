CREATE VIEW CJ_LJSCWLDY_VW AS
  select ljid,gxzdid,gxxh from LJSCWLDY_TB group by ljid,gxzdid,gxxh
/

