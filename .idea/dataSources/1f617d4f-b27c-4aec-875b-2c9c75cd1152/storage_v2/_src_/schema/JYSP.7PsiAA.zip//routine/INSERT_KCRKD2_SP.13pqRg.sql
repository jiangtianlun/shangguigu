CREATE procedure INSERT_KCRKD2_SP(p_fid in number,p_num in number)
as
----xjy新增几行的意思
 v_num number:= p_num;
begin
loop
exit when v_num < 1;
insert into KCRKD2_TB(ID,FID,RKRQ) SELECT SEQKCRKD2.NEXTVAL,p_fid,sysdate FROM DUAL;
v_num := v_num -1;
end loop;
end INSERT_KCRKD2_SP;
/

