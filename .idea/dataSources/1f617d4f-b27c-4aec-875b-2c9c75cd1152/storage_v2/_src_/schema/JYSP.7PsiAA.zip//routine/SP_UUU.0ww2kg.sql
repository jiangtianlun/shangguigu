CREATE procedure sp_uuu(a in number,
                                   b in varchar2 ,
                                   c in number default 1) is
    d  number;
    e  varchar2(20) ;
    f  number;
begin
    d :=a;
    e :=b;
    f :=c;
    dbms_output.put_line(d);
     dbms_output.put_line(e);
      dbms_output.put_line(f);
end sp_uuu;
/

