CREATE PROCEDURE IMPORT_XSTDMXDR_SP(P_IMPTASK_BM IN NUMBER) IS
  CURSOR CUR_IMPDATA IS
    SELECT C03 LJBH, --零件编号
           C04 LJMC, ---零件名称
           C05 GGXH, ---规格型号
           C06 JLDW, -----计量单位
           C07 SL, ----数量
           C08 JHRQ, ----交货日期
           C09 SHDD ---送货地点
    
      FROM ZX_SWAPDATA_TB T
     WHERE T.IMPTASK_BM = P_IMPTASK_BM;
  V_LJ  CUR_IMPDATA%ROWTYPE;
  V_CNT NUMBER;
  -- v_LJID NUMBER;
  --V_USERID NUMBER;

BEGIN
  SAVEPOINT V_SP_0000;
  --SELECT TEMPADDITION INTO V_USERID FROM ZX_SWAPDATA_VW;
  OPEN CUR_IMPDATA;
  LOOP
    FETCH CUR_IMPDATA
      INTO V_LJ;
    EXIT WHEN CUR_IMPDATA%NOTFOUND;
    SELECT COUNT(1)
      INTO V_CNT
      FROM XSTDMXDR_TB X
     WHERE trim(X.LJBH) = trim(V_LJ.LJBH);
    
     IF V_CNT = 0 THEN 
     INSERT INTO XSTDMXDR_TB(ID, LJBH, LJMC, GGXH, JLDW, SL, JHRQ, SHDD)
            SELECT SEQXSTDMXDR.NEXTVAL,
                   V_LJ.LJBH,
                   V_LJ.LJMC,
                   V_LJ.GGXH,
                   V_LJ.JLDW,
                   nvl(V_LJ.SL,0),
                   V_LJ.JHRQ,
                   V_LJ.SHDD
              FROM DUAL;
  
  END IF;
  IF V_CNT <> 0 THEN
    UPDATE XSTDMXDR_TB
       SET LJBH = V_LJ.LJBH,
           LJMC = V_LJ.LJMC,
           GGXH = V_LJ.GGXH,
           JLDW = V_LJ.JLDW,
           SL   = V_LJ.SL,
           JHRQ = V_LJ.JHRQ,
           SHDD = V_LJ.SHDD
    
     WHERE trim(LJBH) = trim(V_LJ.LJBH);
  
  END IF;
  END LOOP;
  CLOSE CUR_IMPDATA;
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    RAISE_APPLICATION_ERROR(-20009, SQLERRM);
    ROLLBACK TO SAVEPOINT V_SP_0000;
    DELETE FROM ZX_SWAPDATA_TB T
     WHERE T.IMPTASK_BM = P_IMPTASK_BM
       AND NVL(T.STATE, 0) <> 1;
    COMMIT;
    END IMPORT_XSTDMXDR_SP;
/

