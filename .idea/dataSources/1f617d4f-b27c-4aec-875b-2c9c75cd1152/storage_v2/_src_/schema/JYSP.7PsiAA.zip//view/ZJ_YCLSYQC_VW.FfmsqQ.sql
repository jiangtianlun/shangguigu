CREATE VIEW ZJ_YCLSYQC_VW AS
  SELECT BZID, YF, wlid,ckid, SUM(llsl) LLSL, SUM(SYSL) SYSL
  FROM (select sczld.bzid bzid,
               TO_CHAR(sczld.scrq, 'YYYYMM') YF,
               slzldmx.wlid wlid,
               slzldmx.llsl llsl, ----生产指令单的开单领料数量
               ZJ_XJJL2.SYSL SYSL, ------巡检原材料使用数量
               wlzd.ckid
          from sczld_tb sczld
          left join sczldmx_tb slzldmx on sczld.id = slzldmx.fid
          LEFT JOIN ZJ_XJJL1_TB ZJ_XJJL1 on ZJ_XJJL1.Sczldid = sczld.id
          left join ZJ_XJJL2_TB ZJ_XJJL2 on slzldmx.ID = ZJ_XJJL2.Sczldmxid
          left join wlzd_tb wlzd on slzldmx.wlid=wlzd.id
         where sczld.djzt = 1 AND  ZJ_XJJL1.DJZT=1
         and wlzd.ckid in (select id from kcbmzd_tb t where t.fid = 1213))
 GROUP BY grouping sets((WLID,BZID, YF,ckid),WLID,NULL)
/

