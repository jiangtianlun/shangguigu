CREATE TYPE "FK_REFERED_COUNT_ROW"                                                                                                                                                                                                                            AS object (
  child_table          varchar2(32),
  parent_id                NUMBER(19),
  refer_count          NUMBER(19)
);


/

