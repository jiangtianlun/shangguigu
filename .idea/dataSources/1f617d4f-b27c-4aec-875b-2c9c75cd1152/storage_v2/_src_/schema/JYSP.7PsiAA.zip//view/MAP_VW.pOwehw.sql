CREATE VIEW MAP_VW AS
  select 1 IID,
1 MValue,
'福建' DisplayValue,
'' Link,
'' Color,
''ToolText
from dual
/

