CREATE VIEW SP_GCZJTJB1_VW AS
  select cpid,ZSL,HG,FQ,FG,TH,Round(nvl(HG,0)*100.0/nvl(ZSL,100000000),2)HGL,Round(nvl(FQ,0)*100.0/nvl(ZSL,100000000),2)FQL,
Round(nvl(FG,0)*100.0/nvl(ZSL,100000000),2)FGL,Round(nvl(TH,0)*100.0/nvl(ZSL,100000000),2)THL from
(select cpid,sum(zsl)ZSL,sum(hg)HG,sum(fq)FQ,sum(fg)FG,sum(th)TH from
(SELECT zsl,hg,fq,fg,th,cpid,to_char(rq,'yyyy-mm')rq FROM SP_JJGCJY1_TB)group by cpid) order by cpid
/

