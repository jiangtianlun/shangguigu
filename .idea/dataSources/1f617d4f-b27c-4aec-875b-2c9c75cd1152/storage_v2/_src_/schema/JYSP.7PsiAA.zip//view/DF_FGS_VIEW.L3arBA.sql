CREATE VIEW DF_FGS_VIEW AS
  select '总部' object_name, -1 object_id
  from dual
union all
select object_name, object_id
  from df_object_tb
 where object_id_supper is null
/

