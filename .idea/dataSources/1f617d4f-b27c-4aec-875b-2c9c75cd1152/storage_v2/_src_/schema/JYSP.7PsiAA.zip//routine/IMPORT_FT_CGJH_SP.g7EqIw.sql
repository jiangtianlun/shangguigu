CREATE PROCEDURE IMPORT_FT_CGJH_SP(P_IMPTASK_BM IN NUMBER) IS
  CURSOR CUR_IMPDATA IS ---徐文豪福特采购计划导入2017/03/05
    SELECT C03 INTERCHANGE_CONTROL_NUM,
           C04 MESSAGE_RELEASE_NUM,
           C05 MESSAGE_RELEASE_DATE,
           C06 MESSAGE_PURPOSE,
           C07 SCHEDULE_TYPE,
           C08 HORIZON_START_DATE,
           C09 HORIZON_END_DATE,
           C10 COMMENT_NOTE,
           C11 SHIP_TO_GSDB_CODE,
           C12 SHIP_FROM_GSDB_CODE,
           C13 INTERMEDIATE_CONSIGNEE,
           C14 PART_NUM,
           C15 PURCHASE_ORDER_NUM,
           C16 PART_RELEASE_STATUS,
           C17 DOCK_CODE,
           C18 LINE_FEED,
           C19 RESERVE_LINE_FEED,
           C20 CONTACT_NAME,
           C21 CONTACT_TELEPHONE,
           C22 FAB_AUTH_QTY,
           C23 FAB_AUTH_START_DATE,
           C24 FAB_AUTH_END_DATE,
           C25 MAT_AUTH_QTY,
           C26 MAT_AUTH_START_DATE,
           C27 MAT_AUTH_END_DATE,
           C28 LAST_RECEIVED_ASN_NUM,
           C29 LAST_SHIPPED_QTY,
           C30 LAST_SHIPPED_DATE,
           C31 CUM_SHIPPED_QTY,
           C32 CUM_START_DATE,
           C33 CUM_END_DATE,
           C34 FORECAST_CUM_QTY,
           C35 FORECAST_NET_QTY,
           C36 UOM,
           C37 FORECAST_STATUS,
           C38 FORECAST_DATE,
           C39 FLEXIBLE_FORCAST_START_DATE,
           C40 FLEXIBLE_FORCAST_END_DATE,
           C41 FORECAST_DATE_QUALR
      FROM ZX_SWAPDATA_TB T
     WHERE T.IMPTASK_BM = P_IMPTASK_BM;
  V_FT_CGJH CUR_IMPDATA%ROWTYPE;
  V_CNT     NUMBER;
BEGIN
  SAVEPOINT V_SP_0000;

  OPEN CUR_IMPDATA;
  LOOP
    FETCH CUR_IMPDATA
      INTO V_FT_CGJH;
    EXIT WHEN CUR_IMPDATA%NOTFOUND;
  
    SELECT COUNT(1)
      INTO V_CNT
      FROM FT_CGJH_TB T
     WHERE trim(T.PART_NUM) = trim(V_FT_CGJH.PART_NUM)
       AND trim(T.forecast_date) = trim(V_FT_CGJH.forecast_date);
  
    IF V_CNT = 0 THEN
      INSERT INTO FT_CGJH_TB
        (ID,
         INTERCHANGE_CONTROL_NUM,
         MESSAGE_RELEASE_NUM,
         MESSAGE_RELEASE_DATE,
         MESSAGE_PURPOSE,
         SCHEDULE_TYPE,
         HORIZON_START_DATE,
         HORIZON_END_DATE,
         COMMENT_NOTE,
         SHIP_TO_GSDB_CODE,
         SHIP_FROM_GSDB_CODE,
         INTERMEDIATE_CONSIGNEE,
         PART_NUM,
         PURCHASE_ORDER_NUM,
         PART_RELEASE_STATUS,
         DOCK_CODE,
         LINE_FEED,
         RESERVE_LINE_FEED,
         CONTACT_NAME,
         CONTACT_TELEPHONE,
         FAB_AUTH_QTY,
         FAB_AUTH_START_DATE,
         FAB_AUTH_END_DATE,
         MAT_AUTH_QTY,
         MAT_AUTH_START_DATE,
         MAT_AUTH_END_DATE,
         LAST_RECEIVED_ASN_NUM,
         LAST_SHIPPED_QTY,
         LAST_SHIPPED_DATE,
         CUM_SHIPPED_QTY,
         CUM_START_DATE,
         CUM_END_DATE,
         FORECAST_CUM_QTY,
         FORECAST_NET_QTY,
         UOM,
         FORECAST_STATUS,
         FORECAST_DATE,
         FLEXIBLE_FORCAST_START_DATE,
         FLEXIBLE_FORCAST_END_DATE,
         FORECAST_DATE_QUALR)
        SELECT SEQFT_CGJH.NEXTVAL,
               V_FT_CGJH.INTERCHANGE_CONTROL_NUM,
               V_FT_CGJH.MESSAGE_RELEASE_NUM,
               V_FT_CGJH.MESSAGE_RELEASE_DATE,
               V_FT_CGJH.MESSAGE_PURPOSE,
               V_FT_CGJH.SCHEDULE_TYPE,
               V_FT_CGJH.HORIZON_START_DATE,
               V_FT_CGJH.HORIZON_END_DATE,
               V_FT_CGJH.COMMENT_NOTE,
               V_FT_CGJH.SHIP_TO_GSDB_CODE,
               V_FT_CGJH.SHIP_FROM_GSDB_CODE,
               V_FT_CGJH.INTERMEDIATE_CONSIGNEE,
               V_FT_CGJH.PART_NUM,
               V_FT_CGJH.PURCHASE_ORDER_NUM,
               V_FT_CGJH.PART_RELEASE_STATUS,
               V_FT_CGJH.DOCK_CODE,
               V_FT_CGJH.LINE_FEED,
               V_FT_CGJH.RESERVE_LINE_FEED,
               V_FT_CGJH.CONTACT_NAME,
               V_FT_CGJH.CONTACT_TELEPHONE,
               V_FT_CGJH.FAB_AUTH_QTY,
               V_FT_CGJH.FAB_AUTH_START_DATE,
               V_FT_CGJH.FAB_AUTH_END_DATE,
               V_FT_CGJH.MAT_AUTH_QTY,
               V_FT_CGJH.MAT_AUTH_START_DATE,
               V_FT_CGJH.MAT_AUTH_END_DATE,
               V_FT_CGJH.LAST_RECEIVED_ASN_NUM,
               V_FT_CGJH.LAST_SHIPPED_QTY,
               V_FT_CGJH.LAST_SHIPPED_DATE,
               V_FT_CGJH.CUM_SHIPPED_QTY,
               V_FT_CGJH.CUM_START_DATE,
               V_FT_CGJH.CUM_END_DATE,
               V_FT_CGJH.FORECAST_CUM_QTY,
               V_FT_CGJH.FORECAST_NET_QTY,
               V_FT_CGJH.UOM,
               V_FT_CGJH.FORECAST_STATUS,
               V_FT_CGJH.FORECAST_DATE,
               V_FT_CGJH.FLEXIBLE_FORCAST_START_DATE,
               V_FT_CGJH.FLEXIBLE_FORCAST_END_DATE,
               V_FT_CGJH.FORECAST_DATE_QUALR
          FROM DUAL;
    END IF;
    IF V_CNT <> 0 THEN
      UPDATE FT_CGJH_TB
         SET Interchange_Control_Num     = V_FT_CGJH.Interchange_Control_Num,
             Message_Release_Num         = V_FT_CGJH.Message_Release_Num,
             Message_Release_Date        = V_FT_CGJH.Message_Release_Date,
             Message_Purpose             = V_FT_CGJH.Message_Purpose,
             Schedule_Type               = V_FT_CGJH.Schedule_Type,
             Horizon_Start_Date          = V_FT_CGJH.Horizon_Start_Date,
             Horizon_End_Date            = V_FT_CGJH.Horizon_End_Date,
             Comment_Note                = V_FT_CGJH.Comment_Note,
             Ship_To_GSDB_Code           = V_FT_CGJH.Ship_To_GSDB_Code,
             Ship_From_GSDB_Code         = V_FT_CGJH.Ship_From_GSDB_Code,
             Intermediate_Consignee      = V_FT_CGJH.Intermediate_Consignee,
             Part_Num                    = V_FT_CGJH.Part_Num,
             Purchase_Order_Num          = V_FT_CGJH.Purchase_Order_Num,
             Part_Release_Status         = V_FT_CGJH.Part_Release_Status,
             Dock_Code                   = V_FT_CGJH.Dock_Code,
             Line_Feed                   = V_FT_CGJH.Line_Feed,
             Reserve_Line_Feed           = V_FT_CGJH.Reserve_Line_Feed,
             Contact_Name                = V_FT_CGJH.Contact_Name,
             Contact_Telephone           = V_FT_CGJH.Contact_Telephone,
             Fab_Auth_Qty                = V_FT_CGJH.Fab_Auth_Qty,
             Fab_Auth_Start_Date         = V_FT_CGJH.Fab_Auth_Start_Date,
             Fab_Auth_End_Date           = V_FT_CGJH.Fab_Auth_End_Date,
             Mat_Auth_Qty                = V_FT_CGJH.Mat_Auth_Qty,
             Mat_Auth_Start_Date         = V_FT_CGJH.Mat_Auth_Start_Date,
             Mat_Auth_End_Date           = V_FT_CGJH.Mat_Auth_End_Date,
             Last_Received_ASN_Num       = V_FT_CGJH.Last_Received_ASN_Num,
             Last_Shipped_Qty            = V_FT_CGJH.Last_Shipped_Qty,
             Last_Shipped_Date           = V_FT_CGJH.Last_Shipped_Date,
             Cum_Shipped_Qty             = V_FT_CGJH.Cum_Shipped_Qty,
             Cum_Start_Date              = V_FT_CGJH.Cum_Start_Date,
             Cum_End_Date                = V_FT_CGJH.Cum_End_Date,
             Forecast_Cum_Qty            = V_FT_CGJH.Forecast_Cum_Qty,
             Forecast_Net_Qty            = V_FT_CGJH.Forecast_Net_Qty,
             UOM                         = V_FT_CGJH.UOM,
             Forecast_Status             = V_FT_CGJH.Forecast_Status,
             Forecast_Date               = V_FT_CGJH.Forecast_Date,
             Flexible_Forcast_Start_Date = V_FT_CGJH.Flexible_Forcast_Start_Date,
             Flexible_Forcast_End_Date   = V_FT_CGJH.Flexible_Forcast_End_Date,
             Forecast_Date_Qualr         = V_FT_CGJH.Forecast_Date_Qualr
             -----一定要加限制条件where语句---
             WHERE trim(PART_NUM) = trim(V_FT_CGJH.PART_NUM)
       AND trim(forecast_date) = trim(V_FT_CGJH.forecast_date);
    END IF;
  
  END LOOP;
  CLOSE CUR_IMPDATA;
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    RAISE_APPLICATION_ERROR(-20009, SQLERRM);
    ROLLBACK TO SAVEPOINT V_SP_0000;
    DELETE FROM ZX_SWAPDATA_TB T
     WHERE T.IMPTASK_BM = P_IMPTASK_BM
       AND NVL(T.STATE, 0) <> 1;
    COMMIT;
END IMPORT_FT_CGJH_SP;
/

