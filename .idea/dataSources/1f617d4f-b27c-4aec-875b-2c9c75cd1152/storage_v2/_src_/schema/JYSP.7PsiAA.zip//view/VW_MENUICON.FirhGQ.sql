CREATE VIEW VW_MENUICON AS
  select file_mc, file_bm
  from zx_file_tb
 where table_name = 'auth_menu_tb'
   and PRIMARYKEY_VALUE = 1
   and file_mc is not null
   and file_date is not null
/

