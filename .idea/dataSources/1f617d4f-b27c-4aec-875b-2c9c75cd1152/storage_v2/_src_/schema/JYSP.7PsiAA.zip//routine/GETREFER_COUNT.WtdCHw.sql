CREATE procedure getrefer_count(p_wlid in number) is

v_cnt number:=0;
begin
  
SELECT  COUNT(1) into v_cnt FROM TABLE(FK_UTIL.get_refered_count('WLZD_TB', p_wlid)) WHERE REFER_COUNT >0;

if v_cnt =0 then 

update wlzd_tb set sfyx=1 where id = p_wlid;

else

 RAISE_APPLICATION_ERROR(-20002,'该物料已被引用，不可删除');
end if; 

end getrefer_count;

/

