CREATE VIEW BCPBYKCSSJY_VW AS
  with bcpkcbbmt as (select "WLID","YF","CKID","'a01'_SSSL" as R01,"'a01'_SFSL" as C01,"'a02'_SSSL" AS R02,"'a02'_SFSL" AS C02,"'a03'_SSSL" AS R03,"'a03'_SFSL" AS C03,"'a04'_SSSL" AS R04,"'a04'_SFSL" AS C04,"'a05'_SSSL" AS R05,"'a05'_SFSL" AS C05,"'a06'_SSSL" AS R06,"'a06'_SFSL" AS C06,
"'a07'_SSSL" AS R07,"'a07'_SFSL" AS C07,"'a08'_SSSL" AS R08,"'a08'_SFSL" AS C08,
"'a09'_SSSL" AS R09,"'a09'_SFSL" C09,"'a10'_SSSL" AS R10,
"'a10'_SFSL" C10,"'a11'_SSSL" R11,"'a11'_SFSL" C11,
"'a12'_SSSL" R12,"'a12'_SFSL" C12,"'a13'_SSSL" R13,
"'a13'_SFSL" C13,"'a14'_SSSL" R14,"'a14'_SFSL" C14,
"'a15'_SSSL" R15,"'a15'_SFSL" C15,"'a16'_SSSL" R16,
"'a16'_SFSL" C16,"'a17'_SSSL" R17,"'a17'_SFSL" C17,
"'a18'_SSSL" R18,"'a18'_SFSL" C18,"'a19'_SSSL" R19,
"'a19'_SFSL" C19,"'a20'_SSSL" R20,"'a20'_SFSL" C20,
"'a21'_SSSL" R21,"'a21'_SFSL" C21,"'a22'_SSSL" R22,
"'a22'_SFSL" C22,"'a23'_SSSL" R23,"'a23'_SFSL" C23,
"'a24'_SSSL" R24,"'a24'_SFSL" C24,"'a25'_SSSL" R25,
"'a25'_SFSL" C25,"'a26'_SSSL" R26,"'a26'_SFSL" C26,
"'a27'_SSSL" R27,"'a27'_SFSL" C27,"'a28'_SSSL" R28,
"'a28'_SFSL" C28,"'a29'_SSSL" R29,"'a29'_SFSL" C29,
"'a30'_SSSL" R30,"'a30'_SFSL" C30,"'a31'_SSSL" R31,
"'a31'_SFSL"  AS C31,
"'BQJC'_BQJC"  AS BQJC
from( select RKD2.WLID WLID,
         0 BQJC,--------本期结存
         NVL(RKD2.SSSL,0) SSSL,
         0     SFSL,
         TO_CHAR(RKD1.YWRQ, 'YYYYMM') YF,
         'a' || TO_CHAR(RKD1.YWRQ, 'DD') dd,----每天的出入库明细
         WLZD.CKID CKID
    from KCRKD2_TB RKD2
    LEFT JOIN KCRKD1_TB RKD1 ON RKD2.FID = RKD1.ID
    LEFT JOIN WLZD_TB WLZD ON RKD2.WLID = WLZD.ID
    ----LEFT JOIN WLDW_TB WLDW ON WLZD.WLDWID = WLDW.ID
    where RKD1.DJZT=1
    UNION ALL
    select CKD2.WLID WLID,
           0 BQJC,------本期结存
           0 SSSL,
         NVL(CKD2.SFSL,0)    SFSL,
         TO_CHAR(CKD1.YWRQ, 'YYYYMM') YF,
         'a' || TO_CHAR(CKD1.YWRQ, 'DD') dd,
         WLZD.CKID CKID
    from KCCKD2_TB CKD2
    LEFT JOIN KCCKD1_TB CKD1 ON CKD2.FID = CKD1.ID
    LEFT JOIN WLZD_TB WLZD ON CKD2.WLID = WLZD.ID
    ----LEFT JOIN WLDW_TB WLDW ON WLZD.WLDWID = WLDW.ID
    --WHERE CKD1.DJZT=1
    union all
     select KCJY.WLID WLID,
         NVL(KCJY.QCKC,0) BQJC,--------本期结存
         0 SSSL,
         0     SFSL,
         to_char(KCJY.YWRQ,'yyyymm') YF,
         'BQJC'  dd,----每天的出入库明细
         WLZD.CKID CKID
    from KCJY_TB KCJY LEFT JOIN WLZD_TB WLZD ON KCJY.WLID=WLZD.ID
    )
    pivot (SUM(BQJC) BQJC, sum(sssl) SSSL,SUM(SFSL)SFSL for dd in ('BQJC','a01','a02','a03','a04','a05','a06','a07','a08','a09','a10','a11','a12','a13','a14','a15','a16','a17','a18','a19','a20','a21','a22','a23','a24','a25','a26','a27','a28','a29','a30','a31'))--行变列转换
    MT ORDER BY yf asc
    )
----半成品仓本月库存实时结余--
----徐文豪20170829 分切、模压半成品仓库(419131、41951)实时库存，用于领料时保证领料数量不大于库存
----入库取审核状态，出库取草稿状态
   select WLID,CKID,YF,NVL(BQJC,0) BQJC,(nvl(R01,0)+nvl(R02,0)+nvl(R03,0)+nvl(R04,0)+nvl(R05,0)+nvl(R06,0)+nvl(R07,0)+
nvl(R08,0)+nvl(R09,0)+nvl(R10,0)+nvl(R11,0)+nvl(R12,0)+nvl(R13,0)+nvl(R14,0)+
nvl(R15,0)+nvl(R16,0)+nvl(R17,0)+nvl(R18,0)+nvl(R19,0)+nvl(R20,0)+nvl(R21,0)+
nvl(R22,0)+nvl(R23,0)+nvl(R24,0)+nvl(R25,0)+nvl(R26,0)+nvl(R27,0)+nvl(R28,0)+
nvl(R29,0)+nvl(R30,0)+nvl(R31,0)) BYZR,(nvl(C01,0)+nvl(C02,0)+nvl(C03,0)+nvl(C04,0)+nvl(C05,0)+nvl(C06,0)+nvl(C07,0)+
nvl(C08,0)+nvl(C09,0)+nvl(C10,0)+nvl(C11,0)+nvl(C12,0)+nvl(C13,0)+nvl(C14,0)+
nvl(C15,0)+nvl(C16,0)+nvl(C17,0)+nvl(C18,0)+nvl(C19,0)+nvl(C20,0)+nvl(C21,0)+
nvl(C22,0)+nvl(C23,0)+nvl(C24,0)+nvl(C25,0)+nvl(C26,0)+nvl(C27,0)+nvl(C28,0)+
nvl(C29,0)+nvl(C30,0)+nvl(C31,0)) BYZC,(nvl(BQJC,0)+
nvl(R01,0)+nvl(R02,0)+nvl(R03,0)+nvl(R04,0)+nvl(R05,0)+nvl(R06,0)+nvl(R07,0)+
nvl(R08,0)+nvl(R09,0)+nvl(R10,0)+nvl(R11,0)+nvl(R12,0)+nvl(R13,0)+nvl(R14,0)+
nvl(R15,0)+nvl(R16,0)+nvl(R17,0)+nvl(R18,0)+nvl(R19,0)+nvl(R20,0)+nvl(R21,0)+
nvl(R22,0)+nvl(R23,0)+nvl(R24,0)+nvl(R25,0)+nvl(R26,0)+nvl(R27,0)+nvl(R28,0)+
nvl(R29,0)+nvl(R30,0)+nvl(R31,0)-nvl(C01,0)-nvl(C02,0)-nvl(C03,0)-nvl(C04,0)-
nvl(C05,0)-nvl(C06,0)-nvl(C07,0)-
nvl(C08,0)-nvl(C09,0)-nvl(C10,0)-nvl(C11,0)-nvl(C12,0)-nvl(C13,0)-nvl(C14,0)-
nvl(C15,0)-nvl(C16,0)-nvl(C17,0)-nvl(C18,0)-nvl(C19,0)-nvl(C20,0)-nvl(C21,0)-
nvl(C22,0)-nvl(C23,0)-nvl(C24,0)-nvl(C25,0)-nvl(C26,0)-nvl(C27,0)-nvl(C28,0)-
nvl(C29,0)-nvl(C30,0)-nvl(C31,0)) BYJY from bcpkcbbmt where ckid in (1334,1335)
/

