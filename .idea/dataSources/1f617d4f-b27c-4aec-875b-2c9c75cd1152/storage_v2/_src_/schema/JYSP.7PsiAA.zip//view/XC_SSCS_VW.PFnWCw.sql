CREATE VIEW XC_SSCS_VW AS
  select csid,max(csz)csz from cs_tb group by csid
/

