CREATE VIEW SP_YSKMX_VW AS
  select khid,
       --djlx, --内贸，外贸
       null djbh,
       '期初小计' yslx,--应收类型
       null djzt,
       --p_view_param.get_KSRQ() ywrq,
       sysdate ywrq,
       null wlid,
       null sl,
       null dj,
       null je,
       sum(ysje) ysje,
       sum(skje) skje,
       null he,
       null bz,
       sum(qmje) qmje
  from (select  khid, fpje YSJE, 0 SKJE, -fpje QMJE
          from sp_xsfp1_tb fp
         where djzt = 1
        union all
        select  khid, 0 YSJE, SKJE, skje QMJE
          from sp_xshk_tb
         where  djzt = 1)
 group by  khid

union all

select khid,
       --djlx, --内贸，外贸
       djbh,
       nvl(yslx, '合计') yslx,
       djzt,
       ywrq,
       wlid,
       sl,
       dj,
       je,
       sum(ysje) ysje,
       sum(skje) skje,
       he,
       bz,
       qmye qmje
  from (select khid,
               --djlx, --内贸，外贸
               djbh,
               yslx,
               djzt,
               ywrq,
               wlid,
               sl,
               dj,
               je,
               ysje,
               skje,
               he,
               bz,
               sum(he) over(PARTITION BY khid ORDER BY khid ASC, YWRQ ASC) QMYE
          from ((select khid,
                        --djlx,
                        djbh,
                        '销售发票' yslx,
                        djzt,
                        zdrq ywrq,
                        null wlid,

                        null sl,
                        null dj,
                        null je,
                        fpje ysje,
                        0 skje,
                        -fpje he,
                        bz
                   from sp_xsfp1_tb
                  where djzt = 1
                 union all
                 select khid,
                        --djlx,
                        djbh,
                        '收款单据' yslx,
                        djzt,
                        ywrq,
                        null wlid,

                        null sl,
                        null dj,
                        null je,
                        0 ysje,
                        skje,
                        skje he,
                        bz
                   from sp_xshk_tb
                  where djzt = 1) union all
                 select khid,
                        --djlx,
                        djbh,
                        '发票明细' yslx,
                        djzt,
                        t1.zdrq ywrq,
                        wlid,

                        sl,
                        hsdj dj,
                        sl * hsdj je,
                        0 ysje,
                        0 skje,
                        0 he,
                        t2.bz
                   from sp_xsfp2_tb t2
                    left join sp_xsfp1_tb t1 on t1.id = t2.fid
                  where t1.djzt = 1

                  )
        )

 group by grouping sets((khid),(khid, djbh, yslx, djzt, ywrq, wlid, sl, dj, je, he, bz, qmye))
/

