CREATE VIEW ZJ_CPZZHGLTJ_VW AS
  select t1.bzid,
       t1.ljid,
       sum(nvl(t2.sl,0)) SCZS,
       sum(nvl(t1.sl,0))-(sum(nvl(bfbhgs,0))+(sum(nvl(fxs,0))-sum(nvl(bfbhgs,0)))) zzhgs,
       --终检的实际数量减去终检报废的数量以及可返修不合格数与返修合格数的差额，再除以巡检的生产总数
       --sum(nvl(t2.BFSL,0)) XJBFS,
       --sum(nvl(t1.sl,0)) ZJSL,
       --sum(nvl(fxs,0)) FXS,
       --sum(nvl(fxhgs,0)) FXHGS,
       --sum(nvl(bfbhgs,0)) BFBHGS,
       round((sum(nvl(t1.sl,0))-(sum(nvl(bfbhgs,0))+(sum(nvl(fxs,0))-sum(nvl(bfbhgs,0)))))/sum(nvl(t2.sl,0)),3) zzhgl,
       to_char(t1.scrq,'YYYYMM') NFYF
  from ZJ_CPJYJL_TB t1
  left join Zj_Xjjl1_Tb t2 on t1.Zj_Xjjl1id = t2.id
  where t1.djzt=1 and to_char(t1.scrq, 'yyyymm')=201705
 group by grouping sets((t1.bzid,to_char(t1.scrq,'YYYYMM'), t1.ljid),t1.bzid)
/

