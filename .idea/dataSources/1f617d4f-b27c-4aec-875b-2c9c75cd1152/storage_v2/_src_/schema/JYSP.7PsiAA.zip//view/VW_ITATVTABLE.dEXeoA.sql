CREATE VIEW VW_ITATVTABLE AS
  select
substr(TABLE_NAME,
                     instr(TABLE_NAME, '_', 1, 1) + 1,
                     instr(TABLE_NAME, '_', -1, 1)-instr(TABLE_NAME, '_', 1, 1)-1 )as TBKEY,
"TABLE_NAME", "TABLE_TYPE", "COMMENTS"
  from user_tab_comments
 where table_name like 'ITATV_%'
/

