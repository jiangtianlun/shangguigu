CREATE procedure insert_sp_kcckd2_sp(p_InsNum in number,p_FID in number) as
  v_InsNum number := p_InsNum;
  v_FID number := p_FID;
  v_CurNum number := 0;
begin
  select count(id) into v_CurNum from sp_kcckd2_tb where fid = v_fid;

  /*限制新增后最大数量*/
  if v_CurNum + v_InsNum > 5 then
     v_InsNum := 0;
  end if;

  loop
  exit when v_InsNum < 1 or p_FID is null;
  /*以下两种插入语句均可以*/
  insert into sp_kcckd2_tb(id,fid) values(seqsp_kcckd2.nextval,v_FID);
  --insert into rd_kcrkd2_tb(id,fid) select seqrd_kcckd2.nextval,v_FID from dual;
  v_InsNum := v_InsNum -1;
  end loop;

end insert_sp_kcckd2_sp;
/

