CREATE function OA_DELEGATIONSTAN_FC(P_PKVID in number)
  return number as
  --  委托状态
  Result number;
  v_val  number;
  v_sub  number;
  v_subs  number;
begin
  Result := 1;
  select nvl(U_VALIDATE, 1), sysdate-1 - DELEGATION_END,sysdate - DELEGATION_STA
    into v_val, v_sub,v_subs
    from oa_delegation_tb
   where DELEGATION_ID = P_PKVID;
  if v_val = 0 then
    Result := 0;
  else
    if v_sub > 0 or v_subs<0 then
      Result := 0;
    end if;
  end if;
  return(Result);
end OA_DELEGATIONSTAN_FC;
/

