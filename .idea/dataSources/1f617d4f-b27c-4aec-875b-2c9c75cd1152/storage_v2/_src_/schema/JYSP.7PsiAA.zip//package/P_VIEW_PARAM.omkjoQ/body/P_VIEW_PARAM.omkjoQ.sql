CREATE package body p_view_param is
       v_KSRQ varchar2(30);
       v_JSRQ varchar2(30);

       -- KSRQ
       function set_KSRQ(KSRQ VARCHAR2) return VARCHAR2 is
       begin
         v_KSRQ := KSRQ;
         RETURN  KSRQ;
        end;

       function get_KSRQ return DATE is
       begin
         return to_date(v_KSRQ,'yyyy-mm-dd hh24:mi:ss');
       end;
       -- JSRQ
       function set_JSRQ(JSRQ VARCHAR2) return VARCHAR2 is
       begin
         v_JSRQ := JSRQ;
         RETURN JSRQ;
        end;

       function get_JSRQ return DATE is
       begin
        return to_date(v_JSRQ,'yyyy-mm-dd hh24:mi:ss');
       end;

   end p_view_param;
/

