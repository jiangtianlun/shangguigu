CREATE package SLNAUTOPKG is

  -- Author  : LIXIAOHUAN
  -- Created : 2009-12-9 10:03:32
  -- Purpose :

  -- Public type declarations
  type refcursor is ref cursor;

  -- Public function and procedure declarations
  --/////////////////获取下拉框所需信息//////////////////--
  procedure GET_KeyValue(user_id_in       in number,
                         def_table_name   in varchar2,
                         id_column_name   in varchar2,
                         name_column_name in varchar2,
                         result_cursor    out refcursor);

  --////////////////////////行列转换/////////////////////--
  procedure Row_Column_Convert(sql_string_in in varchar2,
                               sql_query_in  in varchar2,
                               v_query_in    in varchar2,
                               y_col_name    varchar2,
                               x_col_name    varchar2,
                               val_col_name  varchar2,
                               result_cursor out refcursor);
   ---- //////////////////////插入属性记录//////////////////////////////
  procedure InsertProperty(p_name in varchar2, p_type in number);
  ---- ////////////////////插入对象记录////////////////////////////////
  procedure InsertObject(cls_id in number,obj_name in varchar2);
  --/////////////////////////插入数据/////////////////////////////////////////////
  procedure InsertObjectData(cls_id   in number,
                             obj_name in varchar2,
                             p_name   in varchar2,
                             val      in varchar2);
procedure DeleClassObjPropAll;
procedure CreateGraphicBase(pu in varchar2, cid out varchar2);
end SLNAUTOPKG;
/

