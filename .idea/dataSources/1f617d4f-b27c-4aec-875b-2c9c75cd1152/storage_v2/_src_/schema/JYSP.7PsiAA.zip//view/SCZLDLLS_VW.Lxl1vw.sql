CREATE VIEW SCZLDLLS_VW AS
  select sczld.bzid bzid,
       sczld.ljid ljid,
       sczld.GXZDID GXZDID,
       sczld.gxxh gxxh,
       sczld.scrq SCRQ,
       sczld.djzt djzt,
       sczld.sl sl, -------先拼接生产指令单的数量
       slzldmx.wlid     wlid,
       slzldmx.llsl     llsl, ----生产指令单的开单领料数量
       ZJ_XJJL1.Sl      XJSL, -----巡检数量
       ZJ_XJJL1.Bfsl    XJBFSL, ----巡检报废数量
       ZJ_XJJL2.SYSL    SYSL, ------巡检原材料使用数量
       ZJ_CPJYJL.SL     ZJSL, -----终检数量
       ZJ_CPJYJL.Fxs    fxs, ----返修数
       ZJ_CPJYJL.Fxhgs    fxhgs, ----返修合格数
       ZJ_CPJYJL.Bfbhgs Bfbhgs -------报废不合格数
  from sczld_tb sczld
  left join sczldmx_tb slzldmx on sczld.id = slzldmx.fid
  LEFT JOIN ZJ_XJJL1_TB ZJ_XJJL1 on ZJ_XJJL1.Sczldid = sczld.id
  left join ZJ_XJJL2_TB ZJ_XJJL2 on slzldmx.ID = ZJ_XJJL2.Sczldmxid
  left join ZJ_CPJYJL_TB ZJ_CPJYJL on ZJ_CPJYJL.Zj_Xjjl1id = ZJ_XJJL1.id
 where sczld.djzt = 1 and ZJ_XJJL1.Djzt=1
/

