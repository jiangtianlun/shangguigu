CREATE VIEW CGDHTZ_VW AS
  with clc as (select wl.id,wl.id as wlid,dy.gysid from wlgysdy_tb dy left join wlzd_tb wl on dy.wlid=wl.id where wl.ckid in (1212, 1214)),--材料仓内的物料ID，供应商ID（即WLDWID）
  kcrkd1 as (select id,ywrq from kcrkd1_tb
                         where djlxid = 3  --采购入库
                           and djzt = 1 --审核过的
                           and (ywrq >= sysdate - 370)),--1年之内的审核过的采购入库单父表ID

  gysxx as (select d.id as gysid, f.wlid --关联的物料、供应商信息
                      from gyszd_vw d left join clc f on d.id =f.gysid where d.SFYX=1)


select "GYSID", "RKNY", "WLID", "SSSL", "RKRQ", "WLMC", "GGXH" --采购到货台账明细（每天的到货情况）
  from (select c.gysid, t.rkny, t.wlid, t.sssl, t.rkrq, g.wlmc, g.ggxh --每日到货明细
          from (select a.wlid,
                       a.sssl,
                       --to_char(rkrq, 'yyyy-MM-dd') rkrq,--入库日期
                       --to_char(rkrq, 'yyyy-MM') as rkny --入库年月
                       to_char(kcrkd1.ywrq, 'yyyy-MM-dd') rkrq,--入库日期(将父表的业务日期作为到货入库日期)
                       to_char(kcrkd1.ywrq, 'yyyy-MM') as rkny --入库年月
                  from kcrkd2_tb a left join kcrkd1 on a.fid=kcrkd1.id
                 where wlid in (select id from clc) --材料仓的材料
                   and (rkrq > sysdate - 370)  --and fid in (select id from kcrkd1)
                    ) t --1年之内的采购到货台账
          left join wlzd_tb b on t.wlid = b.id
          left join gysxx c on t.wlid = c.wlid
          left join wlzd_tb g on t.wlid = g.id

        union all

        select gysid, --统计一个月内的服务次数
               rkny,
               -2 as wlid,
               sum(sssl) as sssl, --计算合计数（即每月每个供应商的到货合计数）
               null as rkrq,
               '合计' as wlmc, --求出各供应商每月的服务次数
               null as ggxh
               from (select c.gysid, t.rkny, t.sssl --各供应商的 服务日期（不重复列出）
                          from (select a.wlid,
                                       a.sssl,
                                       to_char(kcrkd1.ywrq, 'yyyy-MM-dd') rkrq,--入库日期(将父表的业务日期作为到货入库日期)
                                       to_char(kcrkd1.ywrq, 'yyyy-MM') as rkny --入库年月
                                  from kcrkd2_tb a left join kcrkd1 on a.fid=kcrkd1.id
                                 where wlid in (select id from clc)--材料仓的材料
                                   and (rkrq > sysdate - 370)
                                   --and fid in (select id from kcrkd1)--1年之内的采购到货台账
                                ) t--1年之内的
                          left join wlzd_tb b on t.wlid = b.id
                          left join gysxx c on t.wlid =c.wlid)
           group by gysid,rkny

        union all

        select gysid, --统计一个月内的服务次数
               rkny,
               -1 as wlid,
               count(*) as sssl, --计算天数（即服务次数）
               null as rkrq,
               '服务次数' as wlmc, --求出各供应商每月的服务次数
               null as ggxh
               from (select distinct c.gysid, t.rkny, t.rkrq --各供应商的 服务日期（不重复列出）
                          from (select a.wlid,
                                       a.sssl,
                                       to_char(kcrkd1.ywrq, 'yyyy-MM-dd') rkrq,--入库日期(将父表的业务日期作为到货入库日期)
                                       to_char(kcrkd1.ywrq, 'yyyy-MM') as rkny --入库年月
                                  from kcrkd2_tb a left join kcrkd1 on a.fid=kcrkd1.id
                                 where wlid in (select id from clc)--材料仓的材料
                                   and (rkrq > sysdate - 370)
                                   --and fid in (select id from kcrkd1)--1年之内的采购到货台账
                                ) t--1年之内的
                          left join wlzd_tb b on t.wlid = b.id
                          left join gysxx c on t.wlid =c.wlid)
           group by gysid,rkny
        )
 order by gysid, rkny, rkrq, wlid desc
/

