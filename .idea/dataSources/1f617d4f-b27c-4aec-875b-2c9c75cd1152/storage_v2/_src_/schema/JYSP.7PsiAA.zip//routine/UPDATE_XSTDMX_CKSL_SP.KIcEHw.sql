CREATE PROCEDURE update_xstdmx_CKSL_SP( p_fid in NUMBER)
   AS
   --得到出库单2的sfsl写到销售提单明细的cksl
BEGIN  
  for c_sor_1 in 
  (select XSTDMXID,SFSL from KCCKD2_TB  where fid = p_fid)     
    loop      
    update xstdmx_tb  set CKSL = c_sor_1.sfsl WHERE ID = c_sor_1.XSTDMXID;
       end loop;
      COMMIT;
END update_xstdmx_CKSL_SP;

--update_xstdmx_CKSL_SP({$PrimaryID$})
/

