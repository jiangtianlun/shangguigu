CREATE VIEW ORA_VW_ASPNET_UIR AS
  SELECT UserId, RoleId
   FROM ora_aspnet_UsersInRoles
    WITH READ ONLY
/

