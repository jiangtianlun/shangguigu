CREATE function FC_GETVISIOVIEW(TABLENAME varchar2,
                                           PKVALUE   NUMBER)
/*return varchar2 is
  Result varchar2(4000);*/
 return clob is
  Result clob;
  vlink  varchar2(2000);
begin
  FOR x in (select file_bm, file_mc
              from zx_file_tb
             where table_name = TABLENAME
               and primarykey_value = pkvalue) loop
    select decode(substr(x.file_mc, instr(x.file_mc, '.')),
                  '.vsd',
                  '<a href=# onclick=window.open("../../SlnSUWF/SUFEXT/VisioView.aspx?file_bm=',
                  '<a href=# onclick=window.open("../../SlnSUWF/SUFEXT/DocView.aspx?file_bm=') ||
           x.file_bm ||
           '","","menubar=no,toolbar=no,width=1024,height=768,resizable=yes")  style="color:Blue">' ||
           x.file_mc || '</a><br>'
      into vlink
      from dual;
    Result := Result || vlink
    /*decode(substr(x.file_mc, instr(x.file_mc, '.')),
                         '.vsd',
                         '<a href=# onclick=window.open("../../SlnSUWF/SUFEXT/VisioView.aspx?file_bm=',
                         '<a href=# onclick=window.open("../../SlnSUWF/SUFEXT/DocView.aspx?file_bm=')  ||
                  x.file_bm ||
                  '","","menubar=no,toolbar=no,width=1024,height=768,resizable=yes")  style="color:Blue">' ||
                  x.file_mc || '</a><br>'*/
     ;
  end loop;
  return(Result);
end FC_GETVISIOVIEW;
/

