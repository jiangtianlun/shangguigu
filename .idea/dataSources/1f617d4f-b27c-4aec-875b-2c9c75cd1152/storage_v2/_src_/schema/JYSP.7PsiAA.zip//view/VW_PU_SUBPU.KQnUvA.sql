CREATE VIEW VW_PU_SUBPU AS
  select PU_BM as PU,
       substr(substr(SI_PARAMETER || '&',
                     instr(upper(SI_PARAMETER), 'PU=') + 3),
              0,
              instr(substr(SI_PARAMETER || '&',
                           instr(upper(SI_PARAMETER), 'PU=') + 3),
                    '&') - 1) as SUBPU
  from suf_subinfo_tb
 where upper(SI_PARAMETER) like '%PU=%'
 and PU_BM is not null
/

