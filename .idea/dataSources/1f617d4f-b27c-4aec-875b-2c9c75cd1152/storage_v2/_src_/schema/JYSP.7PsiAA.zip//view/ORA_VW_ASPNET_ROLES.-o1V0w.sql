CREATE VIEW ORA_VW_ASPNET_ROLES AS
  SELECT ApplicationId, RoleId, RoleName, LoweredRoleName, Description
  FROM ora_aspnet_Roles
   WITH READ ONLY
/

