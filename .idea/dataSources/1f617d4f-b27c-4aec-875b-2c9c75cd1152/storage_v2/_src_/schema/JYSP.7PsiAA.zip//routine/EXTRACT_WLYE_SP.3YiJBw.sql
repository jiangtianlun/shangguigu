CREATE PROCEDURE extract_wlye_sp is
--提取物料库存余额
CURSOR CUR_WLYE IS
   SELECT WLID,sum(YCSL)YCSL
  from (
        select WLID, SSSL YCSL
          from KCRKD2_TB RKD2
          left join KCRKD1_TB RKD1 on RKD2.FID = RKD1.ID
         where to_char(RKD1.YWRQ,'yyyy-mm-dd') between to_char(trunc(add_months(sysdate,-1),'month'),'yyyy-mm-dd') and 
              to_char(trunc(last_day(add_months(sysdate,-1))),'yyyy-mm-dd') 
           and RKD1.DJZT = 1
        union all
        select WLID,-SFSL YCSL
          from KCCKD2_TB CKD2
          left join KCCKD1_TB CKD1 ON CKD2.FID = CKD1.ID
         where to_char(CKD1.YWRQ,'yyyy-mm-dd') between to_char(trunc(add_months(sysdate,-1),'month'),'yyyy-mm-dd') and 
              to_char(trunc(last_day(add_months(sysdate,-1))),'yyyy-mm-dd') 
           and CKD1.DJZT = 1) group by WLID having sum(YCSL)<>0;
   
   V_WLYE CUR_WLYE%ROWTYPE;
   V_CNT  number;
BEGIN  
   savepoint V_SP_0000;  
   open CUR_WLYE;   
   loop fetch  CUR_WLYE into V_WLYE;    
   exit when  CUR_WLYE%NOTFOUND;
   Select count(1) into V_CNT from KCYE_TB Where WLID = V_WLYE.WLID; 
   if V_CNT = 0 then
   Insert into KCYE_TB(WLID,YCSL)  
   values (V_WLYE.WLID,V_WLYE.YCSL); 
   end if;      
   if V_CNT<>0 then  
   update KCYE_TB set YCSL = V_WLYE.YCSL  Where WLID = V_WLYE.WLID;
   end if;  
  end loop;
   
   close CUR_WLYE;
   commit;
   EXCEPTION  WHEN OTHERS THEN RAISE_APPLICATION_ERROR(-20009, SQLERRM);    
   ROLLBACK TO SAVEPOINT V_SP_0000;   
   --delete from ZX_SWAPDATA_TB T WHERE T.IMPTASK_BM = P_IMPTASK_BM 
   --and nvl(T.STATE, 0) <> 1;  
   commit;
   END extract_wlye_sp;
/

