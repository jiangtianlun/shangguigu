CREATE procedure procedure_SP(pk  number,userid number) is

v_sql   varchar2(2000);
v_error varchar2(2000);
begin

     /*v_sql := 'insert into test1_tb (test1_id,test1_mc,test1_dt)
                values(:P_DJ_BM,:P_CJR,:sysdate)';*/
                
                /*  v_sql := 'update auth_user_tb set U_MEMO = :name where user_id = :pk';
     execute immediate v_sql using 'assss',pk ;*/

   begin
       v_sql := 'insert into test1_tb (test1_id,test1_dt,test1_id2)
                    values(:P_DJ_BM,sysdate,:id2)';
         execute immediate v_sql using pk,userid ;
   exception when others then
       rollback;
       v_error :='#出错2！！！#';
       raise_application_error('-20000',v_error);
   end;
   
   

     commit;
     
    /* exception when others then
       rollback;
       v_error :='#出错！！！#';
       raise_application_error('-20000',v_error);*/
      -- RAISE_APPLICATION_ERROR(-20022, 
       
end procedure_SP;
/

