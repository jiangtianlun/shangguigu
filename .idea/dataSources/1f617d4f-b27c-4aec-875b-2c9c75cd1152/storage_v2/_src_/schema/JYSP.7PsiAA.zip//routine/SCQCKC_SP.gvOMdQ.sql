CREATE PROCEDURE SCQCKC_SP(P_CKID IN NUMBER,P_NFYF IN VARCHAR2) IS
  ------生成期初库存，徐文豪2017/03/19
  ------修改徐继亚20170502，根据查询的月份生成下一个月，用于动态月份生成期初库存
  CURSOR CUR_IMPDATA IS
    SELECT WLID, --物料ID
           (nvl(BQJC, 0) + nvl(R01, 0) + nvl(R02, 0) + nvl(R03, 0) +
           nvl(R04, 0) + nvl(R05, 0) + nvl(R06, 0) + nvl(R07, 0) +
           nvl(R08, 0) + nvl(R09, 0) + nvl(R10, 0) + nvl(R11, 0) +
           nvl(R12, 0) + nvl(R13, 0) + nvl(R14, 0) + nvl(R15, 0) +
           nvl(R16, 0) + nvl(R17, 0) + nvl(R18, 0) + nvl(R19, 0) +
           nvl(R20, 0) + nvl(R21, 0) + nvl(R22, 0) + nvl(R23, 0) +
           nvl(R24, 0) + nvl(R25, 0) + nvl(R26, 0) + nvl(R27, 0) +
           nvl(R28, 0) + nvl(R29, 0) + nvl(R30, 0) + nvl(R31, 0) -
           nvl(C01, 0) - nvl(C02, 0) - nvl(C03, 0) - nvl(C04, 0) -
           nvl(C05, 0) - nvl(C06, 0) - nvl(C07, 0) - nvl(C08, 0) -
           nvl(C09, 0) - nvl(C10, 0) - nvl(C11, 0) - nvl(C12, 0) -
           nvl(C13, 0) - nvl(C14, 0) - nvl(C15, 0) - nvl(C16, 0) -
           nvl(C17, 0) - nvl(C18, 0) - nvl(C19, 0) - nvl(C20, 0) -
           nvl(C21, 0) - nvl(C22, 0) - nvl(C23, 0) - nvl(C24, 0) -
           nvl(C25, 0) - nvl(C26, 0) - nvl(C27, 0) - nvl(C28, 0) -
           nvl(C29, 0) - nvl(C30, 0) - nvl(C31, 0)) QCKC, ---期初库存
           CKID
    
      FROM kc_kcbbmt_vw T
     WHERE T.CKID = P_CKID and T.YF=P_NFYF;
  V_KC  CUR_IMPDATA%ROWTYPE;
  V_CNT NUMBER;
  V_WLBHDL VARCHAR2(100);
  xujiya VARCHAR2(100);
BEGIN
  SAVEPOINT V_SP_0000;
  OPEN CUR_IMPDATA;
  LOOP
    FETCH CUR_IMPDATA
      INTO V_KC;
    EXIT WHEN CUR_IMPDATA%NOTFOUND;
     select to_char(add_months(trunc(to_date(P_NFYF,'yyyymm')),1),'yyyymm') INTO xujiya from dual;
    SELECT COUNT(1)
      INTO V_CNT
      FROM KCJY_TB
     WHERE WLID = V_KC.WLID
       -----and TO_CHAR(YWRQ, 'yyyymm') = TO_CHAR(SYSDATE, 'yyyymm');
       and TO_CHAR(YWRQ, 'yyyymm') =(select to_char(add_months(trunc(to_date(P_NFYF,'yyyymm')),1),'yyyymm') YF from dual);
       select substr(WLBH,1,9) WLBHDL  into V_WLBHDL from WLZD_TB where ID=V_KC.WLID;
    IF V_CNT = 0 THEN
      INSERT INTO KCJY_TB
        (ID, WLID, QCKC, DJZT, YWRQ, NFYF, WLBHDL,CKID)
        SELECT SEQKCJY.NEXTVAL, V_KC.WLID, nvl(V_KC.QCKC, 0), 0, add_months(trunc(to_date(P_NFYF,'yyyymm')),1),to_char(add_months(trunc(to_date(P_NFYF,'yyyymm')),1),'yyyymm'),TRIM(V_WLBHDL),V_KC.CKID
          FROM DUAL;
    END IF;
    IF V_CNT <> 0 THEN
      UPDATE KCJY_TB
         SET WLID = V_KC.WLID,
             QCKC = nvl(V_KC.QCKC, 0),
             DJZT = 0,
             YWRQ =add_months(trunc(to_date(P_NFYF,'yyyymm')),1),
             NFYF = to_char(add_months(trunc(to_date(P_NFYF,'yyyymm')),1),'yyyymm'),
             WLBHDL = TRIM(V_WLBHDL),
             CKID=V_KC.CKID
       WHERE WLID = V_KC.WLID
         and TO_CHAR(YWRQ, 'yyyymm') =(select to_char(add_months(trunc(to_date(P_NFYF,'yyyymm')),1),'yyyymm') YF from dual);
     
    END IF;
  END LOOP;
  CLOSE CUR_IMPDATA;
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    RAISE_APPLICATION_ERROR(-20009, SQLERRM);
    ROLLBACK TO SAVEPOINT V_SP_0000;
    commit;
END SCQCKC_SP;
/

