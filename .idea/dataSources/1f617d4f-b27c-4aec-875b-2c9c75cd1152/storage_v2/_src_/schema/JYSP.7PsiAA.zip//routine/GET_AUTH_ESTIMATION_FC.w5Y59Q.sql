CREATE function GET_AUTH_ESTIMATION_FC(
P_TAB1_NAME   VARCHAR2, --表1名
P_TAB1_CLM1   VARCHAR2, --表1字段1
P_TAB1_CLM2   VARCHAR2, --表1字段2
P_TAB2_NAME   VARCHAR2, --表2名
P_TAB2_CLM1   VARCHAR2, --表2字段1
P_TB2CL1_VAL  NUMBER,   --表2字段1 值
P_TAB2_CLM2   VARCHAR2, --表2字段2
P_TB2CL2_VAL  NUMBER    --表2字段2 值
) return  number is
-- 2007,12,18  zxm 

v_result    number;
v_resultdg  number;
v_str       varchar2(2000);
type cur1 is ref cursor;
-- 判断表2 满足2个条件的记录个数
c_isfound2      cur1;
c_isfound2_rt   number;
-- 判断表1 父级为给定值，所对应的子级
c_isfound1      cur1;
v_tb1_col1      number;
-- 判断表2 是否存在 子级记录
c_isfound3      cur1;
c_isfound3_rt   number;

begin
     -- tab2 中满足2个条件的记录个数
     v_str := 'select count(*) from  '||P_TAB2_NAME||
              ' where '||P_TAB2_CLM1||' = '||P_TB2CL1_VAL ||
              '   and '||P_TAB2_CLM2||' = '||P_TB2CL2_VAL ;

     open c_isfound2 for v_str ;
     fetch c_isfound2 into c_isfound2_rt;
     close c_isfound2;
     -- tab2 无记录，返回0
     if c_isfound2_rt = 0 then
        v_result := 0 ;
     -- tab2 有记录，分情况
     else
         -- tab1 没有字段2
         if P_TAB1_CLM2 is null then
            v_result := 1 ;
         -- tab1 有字段2
         else
             v_result := 1 ;
             v_str := ' select '||P_TAB1_CLM1||' from '||P_TAB1_NAME||
                      ' start with  '||P_TAB1_CLM2||' = '||P_TB2CL2_VAL ||
                      ' connect by '||P_TAB1_CLM2||' = prior '||P_TAB1_CLM1;
             --判断表1 父级为给定值，所对应的子级
             open c_isfound1  for v_str;
             loop
                 fetch c_isfound1 into v_tb1_col1;
             exit when c_isfound1%notfound;
                 -- 判断表2 是否存在 子级记录
                 v_str := 'select count(*) from  '||P_TAB2_NAME||
                          ' where '||P_TAB2_CLM1||' = '||P_TB2CL1_VAL ||
                          '   and '||P_TAB2_CLM2||' = '||v_tb1_col1 ;
                 open c_isfound3 for v_str ;
                 fetch c_isfound3 into c_isfound3_rt;
                 close c_isfound3;
                 -- tab2 有子级不存在记录，退出循环 ，返回 0
                 if c_isfound3_rt = 0 then
                    v_result := 0 ;
                    exit;
                 end if;

             end loop ;
             close c_isfound1;
         end if;

     end if;

  return(v_result);
/*exception when others then
   RAISE_APPLICATION_ERROR(-20001, P_TB2CL2_VAL);*/
   
end GET_AUTH_ESTIMATION_FC;
/

