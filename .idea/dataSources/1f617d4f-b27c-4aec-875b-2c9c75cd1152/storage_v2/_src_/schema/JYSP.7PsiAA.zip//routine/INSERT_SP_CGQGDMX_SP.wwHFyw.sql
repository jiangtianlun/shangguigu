CREATE procedure INSERT_SP_CGQGDMX_SP(p_num in number,p_fid in number)
as
 v_num number := p_num;--限制新增几行
 v_MXNUM number := 0;--v_MXNUM 明细数量
begin
loop
exit when v_num < 1;
insert into sp_CGQGDMX_TB (ID,fid) values (SEQRD_CGQGDMX2.NEXTVAL,p_fid);
v_num := v_num -1;
end loop;
end INSERT_SP_CGQGDMX_SP;
/

