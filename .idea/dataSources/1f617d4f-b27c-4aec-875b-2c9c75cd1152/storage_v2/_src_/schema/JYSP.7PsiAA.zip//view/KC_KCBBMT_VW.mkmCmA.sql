CREATE VIEW KC_KCBBMT_VW AS
  select "WLID","YF","CKID","'a01'_SSSL" as R01,"'a01'_SFSL" as C01,"'a02'_SSSL" AS R02,"'a02'_SFSL" AS C02,"'a03'_SSSL" AS R03,"'a03'_SFSL" AS C03,"'a04'_SSSL" AS R04,"'a04'_SFSL" AS C04,"'a05'_SSSL" AS R05,"'a05'_SFSL" AS C05,"'a06'_SSSL" AS R06,"'a06'_SFSL" AS C06,
"'a07'_SSSL" AS R07,"'a07'_SFSL" AS C07,"'a08'_SSSL" AS R08,"'a08'_SFSL" AS C08,
"'a09'_SSSL" AS R09,"'a09'_SFSL" C09,"'a10'_SSSL" AS R10,
"'a10'_SFSL" C10,"'a11'_SSSL" R11,"'a11'_SFSL" C11,
"'a12'_SSSL" R12,"'a12'_SFSL" C12,"'a13'_SSSL" R13,
"'a13'_SFSL" C13,"'a14'_SSSL" R14,"'a14'_SFSL" C14,
"'a15'_SSSL" R15,"'a15'_SFSL" C15,"'a16'_SSSL" R16,
"'a16'_SFSL" C16,"'a17'_SSSL" R17,"'a17'_SFSL" C17,
"'a18'_SSSL" R18,"'a18'_SFSL" C18,"'a19'_SSSL" R19,
"'a19'_SFSL" C19,"'a20'_SSSL" R20,"'a20'_SFSL" C20,
"'a21'_SSSL" R21,"'a21'_SFSL" C21,"'a22'_SSSL" R22,
"'a22'_SFSL" C22,"'a23'_SSSL" R23,"'a23'_SFSL" C23,
"'a24'_SSSL" R24,"'a24'_SFSL" C24,"'a25'_SSSL" R25,
"'a25'_SFSL" C25,"'a26'_SSSL" R26,"'a26'_SFSL" C26,
"'a27'_SSSL" R27,"'a27'_SFSL" C27,"'a28'_SSSL" R28,
"'a28'_SFSL" C28,"'a29'_SSSL" R29,"'a29'_SFSL" C29,
"'a30'_SSSL" R30,"'a30'_SFSL" C30,"'a31'_SSSL" R31,
"'a31'_SFSL"  AS C31,
"'BQJC'_BQJC"  AS BQJC
from( select RKD2.WLID WLID,
         0 BQJC,--------本期结存
         NVL(RKD2.SSSL,0) SSSL,
         0     SFSL,
         TO_CHAR(RKD1.YWRQ, 'YYYYMM')  YF,
         'a' || TO_CHAR(RKD1.YWRQ, 'DD') dd,----每天的出入库明细
         WLZD.CKID CKID
    from KCRKD2_TB RKD2
    LEFT JOIN KCRKD1_TB RKD1 ON RKD2.FID = RKD1.ID
    LEFT JOIN WLZD_TB WLZD ON RKD2.WLID = WLZD.ID
    ----LEFT JOIN WLDW_TB WLDW ON WLZD.WLDWID = WLDW.ID
    where RKD1.DJZT=1
    UNION ALL
    select CKD2.WLID WLID,
           0 BQJC,------本期结存
           0 SSSL,
         NVL(CKD2.SFSL,0)    SFSL,
         TO_CHAR(CKD1.YWRQ, 'YYYYMM') YF,
         'a' || TO_CHAR(CKD1.YWRQ, 'DD') dd,
         WLZD.CKID CKID
    from KCCKD2_TB CKD2
    LEFT JOIN KCCKD1_TB CKD1 ON CKD2.FID = CKD1.ID
    LEFT JOIN WLZD_TB WLZD ON CKD2.WLID = WLZD.ID
    ----LEFT JOIN WLDW_TB WLDW ON WLZD.WLDWID = WLDW.ID
    WHERE CKD1.DJZT=1
    union all
     select KCJY.WLID WLID,
         NVL(KCJY.QCKC,0) BQJC,--------本期结存
         0 SSSL,
         0     SFSL,
         to_char(KCJY.YWRQ,'yyyymm') YF,
         'BQJC'  dd,----每天的出入库明细
         WLZD.CKID CKID
    from KCJY_TB KCJY LEFT JOIN WLZD_TB WLZD ON KCJY.WLID=WLZD.ID
     /*select RKD2.WLID WLID,
         NVL(RKD2.SSSL,0) BQJC,--------本期结存
         0 SSSL,
         0     SFSL,
         to_char(add_months(trunc(RKD1.YWRQ),1),'yyyymm') YF,
         'BQJC'  dd,----每天的出入库明细
         WLZD.CKID CKID
    from KCRKD2_TB RKD2
    LEFT JOIN KCRKD1_TB RKD1 ON RKD2.FID = RKD1.ID
    LEFT JOIN WLZD_TB WLZD ON RKD2.WLID = WLZD.ID
    LEFT JOIN WLDW_TB WLDW ON WLZD.WLDWID = WLDW.ID where RKD1.DJZT=1 AND TO_CHAR(RKD1.YWRQ, 'YYYYMMDD')=(select  to_char(last_day(add_months(sysdate, -1)),'yyyymmdd') last_day from dual)
*/    )
    pivot (SUM(BQJC) BQJC, sum(sssl) SSSL,SUM(SFSL)SFSL for dd in ('BQJC','a01','a02','a03','a04','a05','a06','a07','a08','a09','a10','a11','a12','a13','a14','a15','a16','a17','a18','a19','a20','a21','a22','a23','a24','a25','a26','a27','a28','a29','a30','a31'))--行变列转换
    MT ORDER BY yf asc
/

