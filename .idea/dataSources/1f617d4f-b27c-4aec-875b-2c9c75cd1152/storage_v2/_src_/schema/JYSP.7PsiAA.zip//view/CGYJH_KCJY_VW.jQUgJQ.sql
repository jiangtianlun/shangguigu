CREATE VIEW CGYJH_KCJY_VW AS
  select WLBHDL,NFYF,SUM(decode(QCKC,null,0,QCKC))KCJY FROM WLZD_TB wl left join kcjy_tb jy on wl.id =jy.wlid
where JY.ckid in(1212,1214,1334)
 GROUP BY WLBHDL,NFYF
/

