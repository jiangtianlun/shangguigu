CREATE VIEW CGWLLJDY_VW AS
  select  dy.ljid,dy.wlid,zh.cgwlid,dy.pbgx,dy.fjlx
  from wlzhdy_tb zh
  left join ljwldy_tb dy on zh.scwlid = dy.wlid
 where dy.ljlx = 0 AND dy.sfyx=1
 union all
 select ljid,wlid,wlid cgwlid,pbgx,fjlx from ljwldy_tb where ljlx=0 AND fjlx=0 and sfyx=1
 union all
 select ljid,wlid,wlid cgwlid,pbgx,fjlx from ljwldy_tb where wlid=994
/

