CREATE VIEW MJLLB_VW AS
  select sum(yscms) yscms, mjid, to_char(shrq, 'yyyymm') shny
  from MJSYJL_TB
 group by mjid, to_char(shrq,'yyyymm')
--徐文豪20170901  模具履历表
/

