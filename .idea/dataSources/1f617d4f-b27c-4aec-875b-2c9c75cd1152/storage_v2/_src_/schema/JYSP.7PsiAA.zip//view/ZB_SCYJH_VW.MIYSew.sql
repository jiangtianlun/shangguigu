CREATE VIEW ZB_SCYJH_VW AS
  select id,djlx,djzt,ljid,ljbh,ljmc,bz,nfyf,zdrq from SCYJH_TB
/

