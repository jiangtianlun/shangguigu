CREATE procedure insert_sp_kcrkd2_sp(p_insnum in number,
                                                p_fid    in number,
                                                p_maxnum in number) as
  v_insnum number := p_insnum;    --插入数量
  v_fid    number := p_fid;      --父id
  v_curnum number := 0;          --当前明细数量
begin
  select count(id) into v_curnum from sp_kcrkd2_tb where fid = p_fid;

  /*限制新增后最大数量*/
  if v_curnum + v_insnum > p_maxnum then
    v_insnum := 0;
  end if;

  loop
    exit when v_insnum < 1 or v_fid is null;
    /*以下两种插入语句均可以*/
    insert into sp_kcrkd2_tb
      (id, fid)
    values
      (seqsp_kcrkd2.nextval, v_fid);
    --insert into rd_kcrkd2_tb(id,fid) select seqrd_kcckd2.nextval,v_fid from dual;
    v_insnum := v_insnum - 1;
  end loop;

end insert_sp_kcrkd2_sp;
/

