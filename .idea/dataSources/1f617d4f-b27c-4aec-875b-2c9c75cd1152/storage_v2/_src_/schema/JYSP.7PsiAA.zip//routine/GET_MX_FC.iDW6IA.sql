CREATE FUNCTION GET_MX_FC(p_tb2 in varchar2,
               f_col in varchar2,--外键值
               p_col in number)--子表的外键
 RETURN varchar2 AS
 v_result varchar2(10);
 type cur1 is ref cursor;
 c_isfound2      cur1;
 c_isfound2_rt   number;
 v_str VARCHAR2(2000);
 begin

 --select count (子表.ID) from 子表 where 子表.外键=父表.ID
   v_str:= 'SELECT count(ID)  FROM '||p_tb2|| ' where '||f_col||' = '||p_col;
open c_isfound2 for v_str ;
     fetch c_isfound2 into c_isfound2_rt;
     close c_isfound2;
     --  无记录，返回0
     if c_isfound2_rt = 0 then
        v_result := '' ;
     -- tab2 有记录，分情况
     else
     v_result := '有明细' ;
     end if;
 return v_result;
 end;
/

