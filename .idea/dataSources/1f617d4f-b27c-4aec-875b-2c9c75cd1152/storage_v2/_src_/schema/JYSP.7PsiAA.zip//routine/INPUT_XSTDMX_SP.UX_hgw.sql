CREATE PROCEDURE input_xstdmx_sp(P_IMPTASK_BM IN NUMBER) IS
 CURSOR CUR_IMPDATA IS
      SELECT
             C03     LJBH,      ---产品编号
             C04    LJMC,       ---产品名称
             C05     JHSL,      ---计划生产数量
             C06     JHRQ,      -----交货日期
             C07     CX_DQ,
             C08     BZ,
             C09     BH          ------编号
       FROM ZX_SWAPDATA_TB T
        WHERE T.IMPTASK_BM = P_IMPTASK_BM;
        V_LJ CUR_IMPDATA%ROWTYPE;
        V_CNT NUMBER;
        v_wl_cnt NUMBER;
        v_LJID NUMBER;
        V_ZFID number;
BEGIN
   SAVEPOINT V_SP_0000;
   SELECT TEMPADDITION  INTO V_ZFID FROM ZX_SWAPDATA_VW;
   OPEN CUR_IMPDATA;
   LOOP FETCH CUR_IMPDATA INTO V_LJ;
   EXIT WHEN CUR_IMPDATA%NOTFOUND;
   SELECT COUNT(1) INTO V_CNT
   FROM XSTDMX_TB WHERE TRIM(LJBH) = TRIM(V_LJ.LJBH) AND TRIM(JHRQ)=TRIM(V_LJ.JHRQ)
   and fid=V_ZFID and trim(bh)=trim(V_LJ.BH);
   select count(id) into v_wl_cnt from WLZD_TB where trim(WLBH)=trim(V_LJ.LJBH);
   if v_wl_cnt = 1 then
   select id into V_LJID from WLZD_TB where trim(WLBH)=trim(V_LJ.LJBH);
   else
   V_LJID :=-1;
   end if;
   IF V_CNT = 0 THEN
   INSERT INTO XSTDMX_TB
      (ID,FID,LJID,LJBH,LJMC,JHSL,JHRQ,CX_DQ,BZ,BH)
         SELECT SEQXSTDMX.NEXTVAL,
                V_ZFID,
                v_LJID,
                V_LJ.LJBH,
                V_LJ.LJMC,
                V_LJ.JHSL,
                V_LJ.JHRQ,
                V_LJ.CX_DQ,
                V_LJ.BZ,
                V_LJ.BH
                FROM DUAL;
   END IF;
       IF V_CNT <>0 THEN
       UPDATE XSTDMX_TB
        SET   LJID =v_LJID,
              LJBH=V_LJ.LJBH,
              LJMC=V_LJ.LJMC,
              JHSL= V_LJ.JHSL,
              JHRQ=V_LJ.JHRQ,
              CX_DQ=V_LJ.CX_DQ,
              BZ=V_LJ.BZ
              WHERE trim(LJBH) = trim(V_LJ.LJBH)
              and TRIM(JHRQ)=TRIM(V_LJ.JHRQ) and trim(BH)=trim(V_LJ.BH);
        END IF;
   END LOOP;
   CLOSE CUR_IMPDATA;
   COMMIT;
   EXCEPTION  WHEN OTHERS THEN RAISE_APPLICATION_ERROR(-20009, SQLERRM);
   ROLLBACK TO SAVEPOINT V_SP_0000;
    delete from ZX_SWAPDATA_TB T
    WHERE T.IMPTASK_BM = P_IMPTASK_BM
    and nvl(T.STATE, 0) <> 1;
   commit;
   END input_xstdmx_sp;
/

