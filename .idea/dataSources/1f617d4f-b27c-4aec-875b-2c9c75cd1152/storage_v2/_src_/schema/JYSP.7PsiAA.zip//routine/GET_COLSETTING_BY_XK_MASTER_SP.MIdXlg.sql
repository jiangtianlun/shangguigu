CREATE PROCEDURE GET_COLSETTING_BY_XK_MASTER_SP(P_USERID NUMBER) is
v_columnsetting  number;
v_str            varchar2(4000);
v_num            number;
v_str2           varchar2(1000);
v_tabexist       number;
-- 2008-09-03 zxm 解析 文档管理后台模块  的操作权限
-- 得到权限设置
cursor c_columnsetting is
   select ltrim(to_char(columnsetting),',') columnsetting
     from xk_master
    where user_id = P_USERID;
c_columnsetting_rt   c_columnsetting%rowtype;

begin
     select count(*) into v_tabexist from user_tables where table_name = 'XK_MASTER_COLUMNSETTING';
     -- 表不存在  建表
     if v_tabexist < 1 then
         v_str := 'create table xk_master_columnsetting( columnsetting  number )';
         execute immediate v_str;
         v_str := 'comment on table xk_master_columnsetting is '||chr(39)|| '文档后台权限操作'||chr(39) ;
         execute immediate v_str;
     -- 表已存在 删除数据
     else
         v_str := 'delete from xk_master_columnsetting ' ;
         execute immediate v_str;
     end if;

     open c_columnsetting ;
     fetch c_columnsetting into c_columnsetting_rt;
     v_str := c_columnsetting_rt.columnsetting ;
     while ( length(v_str)>0  )
     loop
         v_num := instr(v_str,',');
         v_columnsetting := to_number( substr(v_str , 1 , v_num-1 ));
         v_str := substr(v_str , v_num +1 , length(v_str) );
         -- insert into xk_master_columnsetting
         v_str2 := 'insert into xk_master_columnsetting values ( :v_columnsetting )';
         execute immediate v_str2 using v_columnsetting ;

     end loop;
     close c_columnsetting;
     commit;
end GET_COLSETTING_BY_XK_MASTER_SP;
/

