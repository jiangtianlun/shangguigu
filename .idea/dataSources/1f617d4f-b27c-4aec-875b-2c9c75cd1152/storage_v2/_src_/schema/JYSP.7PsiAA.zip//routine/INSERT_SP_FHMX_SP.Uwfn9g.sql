CREATE procedure insert_sp_fhmx_sp(p_num in number,p_fid in number)
as
v_num number :=p_num;--限制新增几行
--v_wlid number;
begin
--select wlid into v_wlid from sp_fhsq_tb where id = p_fid;
loop
exit when v_num<1;
insert into sp_fhmx_tb(id,fid,zdrq) values (seqsp_fhsq.nextval,p_fid,sysdate);
v_num:=v_num-1;
end loop;
end insert_sp_fhmx_sp;
/

