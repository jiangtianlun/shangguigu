CREATE VIEW WL_CARTYPE_VW AS
  select wl.wlmc ljmc,(select wlmc from wlzd_tb where id=dy.wlid) yclmc,carmc.cartypename ,dy.wlid
  ---2017-11-12徐文豪-查询出物料对应的车型
  from cartypeljdy_tb car
  left join ljwldy_tb dy on car.ljid = dy.ljid
  left join cartype_tb carmc on carmc.id=car.cartypeid
  left join wlzd_tb wl on wl.id = car.ljid
  where dy.wlid is not null
/

