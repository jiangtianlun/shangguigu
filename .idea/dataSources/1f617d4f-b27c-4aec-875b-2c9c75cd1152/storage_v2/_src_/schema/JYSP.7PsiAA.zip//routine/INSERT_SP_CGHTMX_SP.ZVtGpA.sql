CREATE procedure INSERT_SP_CGHTMX_SP(p_num in number,p_fid in number)
as
 v_num number := p_num;--限制新增几行
 v_MXNUM number := 0;--v_MXNUM 明细数量
begin
  select count(id) into v_MXNUM from SP_CGHTMX_TB where fid = p_fid;
  IF v_MXNUM+v_num>50 THEN
    v_num :=50-v_MXNUM;  --明细最多只有50行
  END IF;
loop
exit when v_num < 1;
insert into SP_CGHTMX_TB (ID,fid) values (SEQSP_CGHTMX.NEXTVAL,p_fid);
v_num := v_num -1;
end loop;
end INSERT_SP_CGHTMX_SP;
/

