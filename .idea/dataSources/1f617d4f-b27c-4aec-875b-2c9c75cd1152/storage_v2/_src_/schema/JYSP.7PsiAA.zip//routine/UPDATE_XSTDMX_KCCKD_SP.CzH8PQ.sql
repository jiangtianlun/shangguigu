CREATE PROCEDURE update_xstdmx_KCCKD_SP( p_KCCKD1ID in NUMBER)
   AS
BEGIN  
  for c_sor_1 in 
  (select CKD2.XSTDMXID TDMXID,CKD2.SFSL from KCCKD2_TB CKD2  where CKD2.fid = p_KCCKD1ID)     
    loop      
    update xstdmx_tb  set CKSL = c_sor_1.sfsl WHERE ID = c_sor_1.tdmxid;
       end loop;
      COMMIT;
END update_xstdmx_KCCKD_SP;
/

