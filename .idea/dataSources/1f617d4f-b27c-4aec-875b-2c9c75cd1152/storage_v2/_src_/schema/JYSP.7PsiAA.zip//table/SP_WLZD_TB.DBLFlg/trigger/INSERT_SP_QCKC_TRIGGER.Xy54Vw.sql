CREATE TRIGGER INSERT_SP_QCKC_TRIGGER
  AFTER INSERT
  ON SP_WLZD_TB
  FOR EACH ROW
  WHEN ((new.wlbh IS NOT NULL) AND (new.sfyx = 1))
  declare
v_ckid number;
v_wlid number;
v_djlxid number;
v_a varchar2(2);
begin
  v_a:=substr(:new.wlbh,0,1); v_wlid:=:new.id;
  case when (v_a='1') then
   v_ckid:=1; --通用
  when (v_a='2') then
    v_ckid:=5; --专用
  when (v_a='3') then
    v_ckid:=3; --成品
  when (v_a='4') then
    v_ckid:=30; --半成品
  when (v_a='5') then
    v_ckid:=21; --外购件
  end case;
  
  case when (v_a='1') then
   v_djlxid:=48; --通用
  when (v_a='2') then
    v_djlxid:=50; --专用
  when (v_a='3') then
    v_djlxid:=49; --成品
  when (v_a='4') then
    v_djlxid:=60; --半成品
  when (v_a='5') then
    v_djlxid:=51; --外购件
  end case;
  if ((:new.sfyx=1)and(v_ckid=1 or v_ckid=5 or v_ckid=3 or v_ckid=30 or v_ckid=21)) then
    insert into sp_qckc_tb(id,wlid,ckid,qckc,djzt,djlxid) values (seqsp_qckc.nextval,v_wlid,v_ckid,0,1,v_djlxid);
    --insert into sp_qckc_tb(id,wlid,ckid,zdrq,ywrq) values (seqsp_qckc.nextval,v_wlid,v_ckid,(select to_char(trunc(sysdate,'mm'),'yyyy-mm-dd') from dual),(select to_char(trunc(sysdate,'yyyy-mm-dd'),'yyyy-mm-dd') from dual));
    --commit;
  end if;

end;
/

