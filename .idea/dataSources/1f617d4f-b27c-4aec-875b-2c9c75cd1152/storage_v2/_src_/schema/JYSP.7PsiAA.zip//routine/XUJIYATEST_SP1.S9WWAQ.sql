CREATE PROCEDURE xujiyatest_sp1(P_IMPTASK_BM IN NUMBER) IS
CURSOR CUR_IMPDATA IS
      SELECT
             C03     LJBH,      --零件编号
             C04     LJMC,       ---零件名称
             C05     JHSCSL,      ---计划生产数量
             C06     BDKCSL,      -----本地库存数量
             C07     ZZKC,      ----中转库存
             C08     ZKC,      ----总库存
             C09     JYSL,       ---结余数量
             C10     SJSCSL      -----实际生产数量
       FROM ZX_SWAPDATA_TB T
        WHERE T.IMPTASK_BM = P_IMPTASK_BM;
        V_LJ CUR_IMPDATA%ROWTYPE;
        V_CNT NUMBER;
        v_LJID NUMBER;
        V_USERID NUMBER;

BEGIN
   SAVEPOINT V_SP_0000;
 SELECT TEMPADDITION  INTO V_USERID FROM ZX_SWAPDATA_VW;
   OPEN CUR_IMPDATA;
   LOOP
   FETCH CUR_IMPDATA
    INTO V_LJ;
    EXIT WHEN CUR_IMPDATA%NOTFOUND;
    SELECT COUNT(1) INTO V_CNT FROM SCYJH_TB
     WHERE trim(LJBH) = trim(V_LJ.LJBH); 
     ----and TRIM(nfyf)=trim(to_char(add_months(trunc(sysdate),1),'yyyymm'));
     select ID  into V_LJID from WLZD_TB where trim(WLBH)=trim(V_LJ.LJBH);
     IF V_CNT = 0 THEN
      INSERT INTO SCYJH_TB
      (ID,DJLX,DJZT,LJID,LJBH,LJMC,JHSL,BDKCSL,ZZKCSL,ZKC,JYSL,SJSL,ZDRID,ZDRQ,NFYF)
         SELECT SEQSCYJH.NEXTVAL,
                1,
                0,-----草稿
                v_LJID,
                V_LJ.LJBH,
                V_LJ.LJMC,
                nvl(V_LJ.JHSCSL,0),
                nvl(V_LJ.BDKCSL,0),
                nvl(V_LJ.ZZKC,0),
                nvl(V_LJ.ZKC,0),
                nvl(V_LJ.JYSL,0),
                nvl(V_LJ.SJSCSL,0),
                V_USERID,
                SYSDATE,
                to_char(add_months(trunc(sysdate),1),'yyyymm') nfyf
                FROM DUAL;
        END IF;
        IF V_CNT <>0 THEN
        UPDATE SCYJH_TB
        SET   DJLX=1,
              djzt=0,
              LJID =v_LJID,
              LJBH=V_LJ.LJBH,
              LJMC=V_LJ.LJMC,
              JHSL= V_LJ.JHSCSL,
              BDKCSL=V_LJ.BDKCSL,
              ZZKCSL=V_LJ.ZZKC,
              ZKC=V_LJ.ZKC,
              JYSL= V_LJ.JYSL,
              SJSL=V_LJ.SJSCSL,
              ZDRID=V_USERID,
              ZDRQ = SYSDATE
              WHERE trim(LJBH) = trim(V_LJ.LJBH);
              -----and NFYF=to_char(add_months(trunc(sysdate),1),'yyyymm');
        END IF;
   END LOOP;
   CLOSE CUR_IMPDATA;
   COMMIT;
   EXCEPTION  WHEN OTHERS THEN RAISE_APPLICATION_ERROR(-20009, SQLERRM);
   ROLLBACK TO SAVEPOINT V_SP_0000;
   commit;
   END xujiyatest_sp1;
/

