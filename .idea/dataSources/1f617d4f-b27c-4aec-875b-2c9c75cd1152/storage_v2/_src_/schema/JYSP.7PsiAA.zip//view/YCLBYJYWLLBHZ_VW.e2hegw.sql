CREATE VIEW YCLBYJYWLLBHZ_VW AS
  with bykcjy as (select vw.bqjc,vw.byzr,vw.byzc,vw.byjy ,wl.wllbid,vw.yf from bykcjy_vw vw
left join wlzd_tb wl on vw.wlid=wl.id)
--徐文豪20170830 原材料本月结余数量按物料类别汇总
select sum(bqjc) bqjc,sum(byzr) byzr,sum(byzc) byzc,sum(byjy) byjy ,wllb,yf from
(select bqjc,byzr,byzc,byjy,yf,'无纺布卷材' wllb from bykcjy where wllbid in (72,93,94,70,71,4,103,6,8)
union all
select bqjc,byzr,byzc,byjy,yf,'无纺布片材' wllb from bykcjy where wllbid in (95,73,77,75,74,5,7,9)
union all
select bqjc,byzr,byzc,byjy,yf,'EVA' wllb from bykcjy where wllbid in (42)
union all
select bqjc,byzr,byzc,byjy,yf,'EPDM' wllb from bykcjy where wllbid in (43)
union all
select bqjc,byzr,byzc,byjy,yf,'橡胶板' wllb from bykcjy where wllbid in (45)
union all
select bqjc,byzr,byzc,byjy,yf,'PVC' wllb from bykcjy where wllbid in (44)
union all
select bqjc,byzr,byzc,byjy,yf,'海绵' wllb from bykcjy where wllbid in (48)
union all
select bqjc,byzr,byzc,byjy,yf,'双组份' wllb from bykcjy where wllbid in (50)
union all
select bqjc,byzr,byzc,byjy,yf,'铝箔' wllb from bykcjy where wllbid in (78)
union all
select bqjc,byzr,byzc,byjy,yf,'丁基胶' wllb from bykcjy where wllbid in (46))
group by wllb,yf
/

