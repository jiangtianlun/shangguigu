CREATE TYPE "FK_STATS_ROW"                                                                                                                                                                                                                            AS object (
  child_table          varchar2(32),
  child_table_fk_col   varchar2(32),
  parent_table             varchar2(32),
  parent_table_pk_col   varchar2(32)
);


/

