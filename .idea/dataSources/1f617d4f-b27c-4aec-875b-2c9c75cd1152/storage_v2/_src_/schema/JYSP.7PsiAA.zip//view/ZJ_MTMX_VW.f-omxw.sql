CREATE VIEW ZJ_MTMX_VW AS
  select XJJL.BZID BZID,
       XJJL.LJID LJID,
       NVL(XJJL.SL, 0) SL,----------巡检单的每天明细 xjy
       NVL(XJJL.BFSL, 0) BFSL,
       TO_CHAR(SCRQ, 'YYYY-MM-DD') SCRQ,
       BHGYY,
       JYY,
       gxzdid,
       GXXH
  from zj_xjjl1_tb XJJL
  LEFT JOIN wlzd_tb wlzd on XJJL.LJID = WLZD.ID
/

