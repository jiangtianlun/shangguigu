CREATE VIEW FLOW_HISTORY_VW AS
  select   HIS_ID 历史编码,
       --create cwm 090521
       --HISID 历史编码这个字段是主键，不能修改
       --HISCODES,MODULEID这两个字段过滤的时候要用到，也不能修改
       --其他字段可根据用户需要自己确定增、删、改
       --modified by wxy 090622:审批操作显示中文
       --modified by cwm 090720:增加了审批操作Resend的中文显示
       --modified by cwm 090915:增加了委托信息
       -- 2012-03-19
       his_chkusername  审批人,
       his_reciveusername  接收人,
       decode(HIS_DELEGATIONINFO,null,'无',HIS_DELEGATIONINFO) 委托信息,
       HIS_CHKTIME 时间,
       HIS_CHKorgNAME 审批单位,
       decode(HIS_OPERATION,
              'NoDef',
              '没定义',
              'First',
              '开始审批',
              'SubmitToOther',
              '提交到当前环节其它人',
              'SubmitToNext',
              '提交到下一步',
              'SubmitToReject',
              '提交到上一驳回人',
              'RejectToInitiator',
              '驳回到编制人',
              'RejectToSender',
              '驳回到发送人',
              'Reject',
              '驳回',
              'SubmitToAddition',
              '转发线外',
              'Confirm',
              '转发线外-提交',
              'Stop',
              '终止审批',
              'Resend',
              '重新提交审批',
              'Receive','接收审批',
              'Pause','审批中止',
              HIS_OPERATION) 审批操作,
       HIS_CHKCOMMENT 审批意见,
       HIS_CODES,
       MODULE_ID,
       '附件' FJ

  from flow_history_tb a, flow_tache_tb b
 where a.tache_id = b.tache_id
 order by a.his_codes ,HIS_CHKTIME
/

