CREATE VIEW VW_ENTITYMAP AS
  select field.pu_bm,
       field.FLD_BM,
       field.FLD_KEY,
       uiefld.uientity_id,
       uiefld.uientityfield_key,
       uiefld.uientityfield_entity,
       uiefld.uientityfield_entitykey
  from suf_field_tb field, suf_uientityfield_tb uiefld
 where field.UIENTITYFIELD_ID = uiefld.uientityfield_id(+)
 order by 1,2
/

