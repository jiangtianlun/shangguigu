CREATE function GET_PROPDATA_VA_FC(P_OBJ_ID   NUMBER,
                                              P_OBJSX_BM NUMBER)
-- 2007-06-21 create by yangxinzhong
 return varchar2 is
  Result VARCHAR2(200);
begin
  SELECT PROPDATA_VA
    INTO Result
    FROM OBJ_PROPDATA_TB
   WHERE OBJ_ID = P_OBJ_ID
     AND OBJSX_BM = P_OBJSX_BM;
  return(Result);
EXCEPTION
  WHEN OTHERS THEN
    return NULL;
end GET_PROPDATA_VA_FC;
/

