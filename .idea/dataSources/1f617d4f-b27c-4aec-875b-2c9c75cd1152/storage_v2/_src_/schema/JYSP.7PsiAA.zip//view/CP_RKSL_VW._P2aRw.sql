CREATE VIEW CP_RKSL_VW AS
  SELECT WLID,
       sum(KCYE) KCYE
  from (select WLID, SSSL KCYE
          from KCRKD2_TB RKD2
          left join KCRKD1_TB RKD1 on RKD2.FID = RKD1.ID
         where TO_CHAR(RKD1.YWRQ,'YYYYMM') = TO_char(sysdate,'YYYYMM')
           and RKD1.DJZT = 1
        )t
 inner join (select id, wlbh, wlmc, ggxh, jldwid
               from WLZD_TB
              where ckid IN(1273)) WL on T.wlid = wl.id
 group by WLID
/

