CREATE VIEW CGJFDMX_VW AS
  SELECT CGDD2ID,WLID,(select dwmc from jldw_tb where id =(select jldwid from wlzd_tb where wlzd_tb.id=wlid)) DWMC,
(select dhrq from cgdd1_tb where id in (select fid from cgdd2_tb where id=cgdd2id)) dhrq,
(select ksjhrq from cgdd2_tb where cgdd2_tb.id=cgdd2id) ksrq,
(select jzjhrq from cgdd2_tb where cgdd2_tb.id=cgdd2id) jzrq,
(select bz from cgdd2_tb where cgdd2_tb.id=cgdd2id) bz,
SUM(SL) SL,GYSID FROM
(SELECT CG2.ID CGDD2ID,CG2.WLID,CG2.SL,CG1.GYSID FROM CGDD2_TB CG2 INNER JOIN CGDD1_TB CG1 ON CG2.FID=CG1.ID AND CG1.DJZT=1
UNION ALL
SELECT JFD2.CGDD2ID,JFD2.WLID,(JFD2.SSSL)*-1 SL,JFD1.GYSID FROM CGJFD2_TB JFD2 INNER JOIN CGJFD1_TB JFD1 ON JFD2.FID=JFD1.ID AND JFD1.DJZT=1
) where wlid is not null
GROUP BY CGDD2ID,WLID,GYSID HAVING SUM(SL)>0 ORDER BY GYSID,CGDD2ID
/

