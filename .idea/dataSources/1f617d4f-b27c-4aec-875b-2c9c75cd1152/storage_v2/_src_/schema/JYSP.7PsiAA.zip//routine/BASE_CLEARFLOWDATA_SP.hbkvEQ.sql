CREATE procedure BASE_CLEARFLOWDATA_SP(P_MID in number) is
---按照审批模块ID 清理审批数据
begin

  delete from flow_instancetache_tb t
   where exists (select 1
            from flow_instance_tb i
           where i.instance_id = t.instance_id
             and i.module_id = P_MID);

  delete from flow_instance_tb i where i.module_id = P_MID;

   delete from flow_history_tb t
   where exists (select 1
            from flow_instance_tb i
           where i.instance_id = t.instance_id
             and i.module_id = P_MID);

  commit;
end BASE_CLEARFLOWDATA_SP;
/

