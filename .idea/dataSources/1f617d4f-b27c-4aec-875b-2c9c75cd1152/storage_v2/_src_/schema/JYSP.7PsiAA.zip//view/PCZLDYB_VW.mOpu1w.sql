CREATE VIEW PCZLDYB_VW AS
  select BZID,sum(sl) PCZS from (select id,BZID,LJID,SL,TO_CHAR(SCRQ, 'YYYYMM'),ZDRID,BZ from PC_SCZLD_TB )
 group by grouping sets(BZID,null)
/

