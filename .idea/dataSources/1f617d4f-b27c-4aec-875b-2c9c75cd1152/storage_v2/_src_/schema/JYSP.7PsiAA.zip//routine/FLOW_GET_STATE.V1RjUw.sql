CREATE function flow_GET_state(
p_moduleid   varchar2,
p_pk         varchar2,
p_userid     varchar2,
p_isFirst    varchar2
)
 return number is
 
-- 2012-08-16  得到审批状态
v_result         number;

-- 得到环节
cursor c_tacheno is
   select t3.*
  from flow_instancetache_tb tt, flow_instance_tb t,flow_tache_tb t3
 where tt.instance_id = t.instance_id
   and t.module_id = p_moduleid
   and t.instance_object = p_pk
   and tt.isttch_tachestate=1
   and instr(',' || tt.isttch_alluncheck || ',', ','||p_userid||',') > 0
   and tt.tache_id = t3.tache_id
 order by  t3.tache_id ;
c_tacheno_rt   c_tacheno%rowtype;
--编制环节
cursor c_bzno is
select tache_no
  from flow_tache_tb 
 where module_id = p_moduleid
   and tache_type = 1;
c_bzno_rt  c_bzno%rowtype;

begin

     for c_tacheno_rt in c_tacheno
     loop
         v_result := c_tacheno_rt.tache_no ;
         exit;
     end loop;
     
     if(p_isFirst =1) then
          for c_bzno_rt in c_bzno
          loop
            v_result := c_bzno_rt.tache_no ;
            exit;
         end loop;
     end if;

     
    return(v_result);
end flow_GET_state;
/

