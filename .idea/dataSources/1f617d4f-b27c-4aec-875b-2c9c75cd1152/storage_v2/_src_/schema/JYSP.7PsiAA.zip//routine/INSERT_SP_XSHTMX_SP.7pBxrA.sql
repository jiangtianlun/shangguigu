CREATE procedure INSERT_SP_XSHTMX_SP(p_num in number,p_fid in number)
as
 v_num number := p_num;--限制新增几行
 v_MXNUM number := 0;--v_MXNUM 明细数量
 v_SHL number;
begin
  select count(id) into v_MXNUM from SP_XSHTMX_TB where fid = p_fid;
  select shl into v_SHL from SP_XSHT_TB where id = p_fid;
  IF v_MXNUM+v_num>10 THEN
    v_num :=10-v_MXNUM;  --明细最多只有10行
  END IF;
loop
exit when v_num < 1;
insert into SP_XSHTMX_TB (ID,fid,shl) values (SEQSP_XSHTMX.NEXTVAL,p_fid,v_SHL);
v_num := v_num -1;
end loop;
end INSERT_SP_XSHTMX_SP;
/

