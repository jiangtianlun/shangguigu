CREATE package body DotNet is
--------------------------------------------------------------------------------------------------------
--****分页实现***********************************************************************************
--------------------------------------------------------------------------------------------------------
PROCEDURE DotNetPagination(
Pindex in number,
Psql in long,
Psize in number,
Pcount out number,
v_cur out T_CURSOR,
Prcount out number
)
AS

v_sql long;
v_count number;
v_Plow number;
v_Phei number;
Begin
------------------------------------------------------------取分页总数
v_sql := 'select count(1) from (' || Psql || ')';
execute immediate v_sql into v_count;
Pcount := ceil(v_count/Psize);
Prcount:=v_count;
------------------------------------------------------------显示任意页内容
v_Phei := (Pindex-1) * Psize + Psize;
v_Plow := v_Phei - Psize + 1;


v_sql:= 'select * from (select rownum rnm, a.* from ('||Psql ||') a where rownum <='|| v_Phei||' ) where rnm >='|| v_Plow ;

open v_cur for v_sql;

End DotNetPagination;
end DotNet;


/

