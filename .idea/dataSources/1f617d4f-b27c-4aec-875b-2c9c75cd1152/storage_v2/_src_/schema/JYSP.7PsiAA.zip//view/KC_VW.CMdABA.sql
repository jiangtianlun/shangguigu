CREATE VIEW KC_VW AS
  select wlid,djlxid,kcyw.fid kcywlbid,ywrq,sfsl sl,ck1.zdrid from kcckd1_tb ck1 left join kcckd2_tb ck2 on ck1.id =ck2.fid
left join kcywlb_tb kcyw on ck1.djlxid =kcyw.id
where ck1.djzt=1
union all
select wlid,djlxid,kcyw.fid kcywlbid,ywrq,sssl sl,rk1.zdrid from kcrkd1_tb rk1
left join kcrkd2_tb rk2 on rk1.id =rk2.fid left join kcywlb_tb kcyw on rk1.djlxid =kcyw.id
where rk1.djzt=1
/

