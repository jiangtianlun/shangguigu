CREATE PROCEDURE tk_clgz_sp(p_rq in varchar2) is
  cursor cur_impdata is
    select LJBH, LJID, LJMC, JYSL, SJSL, NFYF AS RQ
                 from scyjh_tb
                where NFYF = p_rq
                  AND DJZT = 1 ;
  COMM cur_impdata%rowtype;
  V_CNT number;
  begin
    open cur_impdata;
    loop
      fetch cur_impdata
        into COMM;
      exit when cur_impdata%notfound;
      SELECT COUNT(*)
        INTO V_CNT
        FROM PC_YJH_TB
       WHERE LJBH = COMM.LJBH
         and TRIM(NFYF) = p_rq;
      if V_CNT = 0 then
         INSERT INTO PC_YJH_TB
            (ID, DJZT, LJID, LJBH, LJMC, JYSL, SJSL, NFYF)
            SELECT SEQPC_YJH.NEXTVAL,
                   0, -----草稿
                   COMM.LJID,
                   COMM.LJBH,
                   COMM.LJMC,
                   nvl(COMM.JYSL, 0),
                   nvl(COMM.SJSL, 0),
                   COMM.RQ
              FROM DUAL;
      end if;
    end loop;
    close cur_impdata;
    commit;
  end tk_clgz_sp;
/

