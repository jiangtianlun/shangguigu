CREATE VIEW SP_ZLTJB1_VW AS
  select rqq,lb,jsyqid,sum(yssl)yssl,sum(s1)s1,sum(s2)s2,sum(s3)s3 from (
select rqq,lb,jsyqid,yssl,case jl when 0 then cs else null end as s1,case jl when 1 then cs else null end as s2,case jl when 2 then cs else null end as s3
from (select rqq,lb,jsyqid,jl,sum(yssl)cs,sum(yssl)yssl
from
(select a.lb,b.jsyqid,nvl(b.jyjl,-1)jl,to_char(a.rq,'yyyy-mm')rqq,a.yssl from sp_cpysd2_tb b left join sp_cpysd1_tb a on b.fid=a.id)
group by rqq,lb,jsyqid,jl)) group by rqq,lb,jsyqid order by rqq,lb,jsyqid
/

