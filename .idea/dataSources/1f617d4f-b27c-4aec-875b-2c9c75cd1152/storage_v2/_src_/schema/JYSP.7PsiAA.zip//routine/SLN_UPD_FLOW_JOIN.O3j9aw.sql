CREATE procedure SLN_UPD_FLOW_JOIN(  P_JOIN_ID       in NUMBER,
                                                P_GROUP_ID      in NUMBER,
                                                P_UNIT_ID_S     in NUMBER,
                                                P_UNIT_ID_D     in NUMBER,
                                                P_U_NAME        in VARCHAR2,
                                                P_U_MEMO        in VARCHAR2,
                                                P_U_DESCRIPTION in VARCHAR2,
                                                P_U_VALIDATE    in VARCHAR2,
                                                P_U_STATE       in NUMBER,
                                                P_FLAG in varchar2
                                              ) as
begin
  if(P_FLAG=0) then
    insert into FLOW_JOIN_TB(
       JOIN_ID,
       GROUP_ID,
       UNIT_ID_S,
       UNIT_ID_D,
       U_NAME,
       U_MEMO,
       U_DESCRIPTION,
       U_VALIDATE,
       U_STATE) values(
       P_JOIN_ID,
       P_GROUP_ID,
       P_UNIT_ID_S,
       P_UNIT_ID_D,
       P_U_NAME,
       P_U_MEMO,
       P_U_DESCRIPTION,
       P_U_VALIDATE,
       P_U_STATE);

else
    update Flow_JOIN_Tb set
       GROUP_ID=P_GROUP_ID,
       UNIT_ID_S=P_UNIT_ID_S,
       UNIT_ID_D=P_UNIT_ID_D,
       U_NAME=P_U_NAME,
       U_MEMO=P_U_MEMO,
       U_DESCRIPTION=P_U_DESCRIPTION,
       U_VALIDATE=P_U_VALIDATE,
       U_STATE=P_U_STATE
       where JOIN_ID=P_JOIN_ID;
end if;
commit;
end SLN_UPD_FLOW_JOIN;
/

