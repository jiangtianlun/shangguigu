CREATE function Flow_is_reject(
p_moduleid   varchar2,
p_pk         varchar2
)
 return number is

-- 2012-08-16  判断审批是否是驳回的
v_result         number:=0;

-- 得到审批历史
cursor c_his is
   select * from flow_history_tb t order by t.his_id desc;
c_his_rt   c_his%rowtype;

begin

     for c_his_rt in c_his
     loop
         if c_his_rt.his_operation ='Receive' then
            v_result :=-1; 
         elsif c_his_rt.his_operation like 'Reject%' then
           v_result :=1; 
           exit;
         else
           v_result :=0;
           exit;
         end if;
         
     end loop;


    return(v_result);
end Flow_is_reject;
/

