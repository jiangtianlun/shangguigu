CREATE function dmlstatement_fc(tbname in varchar2,
                                           flag   integer) return varchar2 is
-- 2007-06-11 CREATE BY YANGXINZHOANG
-- 根据表名，flag生成 insert，update，delete 语句。
  Result varchar2(4000);

  cursor c1(c1_tabname varchar2) is
    select conl.column_name
      from user_constraints con, user_cons_columns conl
     where con.table_name = upper(c1_tabname)
       and con.constraint_type = 'P'
       and con.constraint_name = conl.constraint_name;

  cursor c2(c2_tabname varchar2) is
    select column_name
      from user_tab_columns
     where table_name = upper(c2_tabname);

  v_pkcolname user_cons_columns.column_name%type;
  v_rec1      c2%rowtype;
  v_sqlstr    varchar2(4000) := 'INSERT INTO ' || tbname || '(';
  v_sqlstr2   varchar2(4000);
  v_update    varchar2(4000) := 'UPDATE ' || tbname || ' SET ';
  v_delete    varchar2(60);
begin
  IF flag IS NULL THEN
    RETURN NULL;
  END IF;
  open c1(tbname);
  fetch c1
    into v_pkcolname;
  close c1;
  -- INSERT
  if flag = 1 then
    open c2(tbname);
    loop
      fetch c2
        into v_rec1;
      exit when c2%notfound;
      v_sqlstr := v_sqlstr || v_rec1.column_name || ',';
      IF v_rec1.column_name = v_pkcolname THEN
        v_sqlstr2 := ' VALUES (SEQ' || RTRIM(tbname, '_TAB') || '.NEXTVAL' || ',';
      ELSE
        v_sqlstr2 := v_sqlstr2 || '@' || v_rec1.column_name || ',';
      END IF;
    end loop;
    v_sqlstr  := rtrim(v_sqlstr, ',') || ')';
    v_sqlstr2 := rtrim(v_sqlstr2, ',') || ')';
    Result    := v_sqlstr || v_sqlstr2;
    return(Result);
  end if;

  -- UPDATE
  if flag = 2 then
    open c2(tbname);
    loop
      fetch c2
        into v_rec1;
      exit when c2%notfound;
      v_update := v_update || v_rec1.column_name || ' =' || '@' ||
                  v_rec1.column_name || ',';
    end loop;
    v_update := rtrim(v_update, ',') || ')';
    Result   := v_update;
    return(Result);
  end if;

  --DELETE
  if flag = 3 then
    v_delete := 'DELETE FROM ' || tbname || ' WHERE ' || v_pkcolname || ' =' || '@' ||
                v_pkcolname;
    Result   := v_delete;
    return(Result);
  end if;
end dmlstatement_fc;
/

