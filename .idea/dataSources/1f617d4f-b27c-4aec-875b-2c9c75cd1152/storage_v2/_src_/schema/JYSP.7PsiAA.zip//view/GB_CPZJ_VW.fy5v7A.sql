CREATE VIEW GB_CPZJ_VW AS
  select cpid,ny,jl,count(*) as cs from (select cpid,to_char(rq,'yyyy-mm') as ny,jl from gb_cpzj_tb where to_char(rq,'yyyy-mm')>='2019-01' and nvl(zt,0)=2) group by cpid,ny,jl
/

