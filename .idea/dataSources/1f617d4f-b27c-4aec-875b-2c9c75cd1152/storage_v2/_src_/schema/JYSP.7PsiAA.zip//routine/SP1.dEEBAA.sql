CREATE procedure sp1 is

v_ljl varchar2(1000):='[8]*0.17+[13]*0.1+[19]*9.2';
v1 number:= 111;
v_qzf   number;
v_hzf   number;
v_zb_id varchar2(100);
begin
    while (instr(v_ljl, '[') > 0) 
    LOOP
          v_qzf   := instr(v_ljl, '[');
          v_hzf   := instr(v_ljl, ']');
          v_zb_id := substr(v_ljl, v_qzf, v_hzf-v_qzf+1);
          
          v_ljl := replace(v_ljl, v_zb_id, v1);
    END LOOP;  



end sp1;
/

