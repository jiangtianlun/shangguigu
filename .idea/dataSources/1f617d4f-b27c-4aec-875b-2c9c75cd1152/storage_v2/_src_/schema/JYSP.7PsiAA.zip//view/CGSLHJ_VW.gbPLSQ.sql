CREATE VIEW CGSLHJ_VW AS
  select gysid, cgwlid, sum(cgsl) CGsl, min(id) as idd from (
 SELECT a.ID,a.GYSID, case nvl(b.cgwlid,-1) when -1 then a.wlid else b.cgwlid end as cgwlid,a.WLID as scwlid,a.CGSL FROM CGQGWLHJ_TB a left join WLZHDY_TB b on a.wlid = b.scwlid WHERE A.ID IN (110,112)
 ) group by gysid, cgwlid order by gysid, cgwlid
/

