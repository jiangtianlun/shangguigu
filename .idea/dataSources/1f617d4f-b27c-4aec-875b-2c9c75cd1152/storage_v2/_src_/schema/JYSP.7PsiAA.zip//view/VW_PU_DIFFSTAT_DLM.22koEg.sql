CREATE VIEW VW_PU_DIFFSTAT_DLM AS
  select '菜单' as DXM,
       '<a href=CommPage.aspx?PU=-102&PTYPE=1&PSTA=' ||
       to_char(pkg_session.get_val_date('P_STA'), 'yyyy-mm-dd') || '&PEND=' ||
       to_char(pkg_session.get_val_date('P_END'), 'yyyy-mm-dd') ||
       '&MENUID=' || pkg_session.get_val('P_MENU') || ' target=_blank>' ||
       count(menu_id) || '</a>' as DNEW,
       '<a href=CommPage.aspx?PU=-102&PTYPE=2&PSTA=' ||
       to_char(pkg_session.get_val_date('P_STA'), 'yyyy-mm-dd') || '&PEND=' ||
       to_char(pkg_session.get_val_date('P_END'), 'yyyy-mm-dd') || '&MENUID=' ||
       pkg_session.get_val('P_MENU') || ' target=_blank>' ||
       nvl(sum(FC_PU_MENUCHANGE(menu_id,
                            pkg_session.get_val_date('P_STA'),
                            pkg_session.get_val_date('P_END'))),0) || '</a>' as DCHANGE,
       NULL as DALL
  from vw_menu_pu
 where MENU_DATE > pkg_session.get_val_date('P_STA')
   and MENU_DATE <= pkg_session.get_val_date('P_END')
   and FC_PU_MENUCHECK(menu_id, pkg_session.get_val('P_MENU')) = 1
union all
select 'PU' as DXM,
       to_char(nvl(sum(DSTATYPE), 0)) as DNEW,
       to_char(nvl(sum(decode(DSTATYPE, 1, 0, 1)), 0)) as DCHANGE,
       count(DSTATYPE) as DALL
  from vw_pu_diffstatistical
 where DTYPE = 4
   and DDATE > pkg_session.get_val_date('P_STA')
   and DDATE <= pkg_session.get_val_date('P_END')
union all
select '网格控件' as DXM,
       to_char(nvl(sum(DSTATYPE), 0)) as DNEW,
       to_char(nvl(sum(decode(DSTATYPE, 1, 0, 1)), 0)) as DCHANGE,
       count(DSTATYPE) as DALL
  from vw_pu_diffstatistical
 where DTYPE = 0
   and DDATE > pkg_session.get_val_date('P_STA')
   and DDATE <= pkg_session.get_val_date('P_END')
union all
select '卡片控件' as DXM,
       to_char(nvl(sum(DSTATYPE), 0)) as DNEW,
       to_char(nvl(sum(decode(DSTATYPE, 1, 0, 1)), 0)) as DCHANGE,
       count(DSTATYPE) as DALL
  from vw_pu_diffstatistical
 where DTYPE = 1
   and DDATE > pkg_session.get_val_date('P_STA')
   and DDATE <= pkg_session.get_val_date('P_END')
union all
select '网格数据域' as DXM,
       to_char(nvl(sum(DSTATYPE), 0)) as DNEW,
       to_char(nvl(sum(decode(DSTATYPE, 1, 0, 1)), 0)) as DCHANGE,
       count(DSTATYPE) as DALL
  from vw_pu_diffstatistical
 where DTYPE = 2
   and DDATE > pkg_session.get_val_date('P_STA')
   and DDATE <= pkg_session.get_val_date('P_END')
union all
select '卡片数据域' as DXM,
       to_char(nvl(sum(DSTATYPE), 0)) as DNEW,
       to_char(nvl(sum(decode(DSTATYPE, 1, 0, 1)), 0)) as DCHANGE,
       count(DSTATYPE) as DALL
  from vw_pu_diffstatistical
 where DTYPE = 3
   and DDATE > pkg_session.get_val_date('P_STA')
   and DDATE <= pkg_session.get_val_date('P_END')
/

