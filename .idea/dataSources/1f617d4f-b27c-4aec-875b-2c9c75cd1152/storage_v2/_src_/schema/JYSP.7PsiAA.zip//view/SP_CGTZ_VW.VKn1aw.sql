CREATE VIEW SP_CGTZ_VW AS
  select gysid, dhrq, wlid, sl, dj, jhjq, mx.bz,mx.id cgddmxid,MX.HWJDZT
  from sp_cgddmx_tb mx
  left join sp_cgdd_tb dd on mx.fid = dd.id
 where dd.djzt = 1 or (mx.dj is not null and mx.gysid is not null and mx.dhrq is not null)
/

