CREATE procedure INSERT_DJBH_SP_KCRKD1_SP(p_tb   in varchar2,-----表名
                                                     p_lm   in varchar2,-----列名
                                                     p_djlxid in number,------单据类型ID
                                                     p_userid in number,------制单人ID
                                                     p_ckid in number,  ------仓库ID
                                                     p_num in number,   ------新增行的数量
                                                     p_rq   in number := 0,------日期
                                                     p_hzcd in number := 3)
--by  CC 19.04 出库主表新增按钮(仓库）
as
  v_num     number := p_num;--限制你新增几行
  v_sql     VARCHAR2(4000);----sql语句
  v_djbh    varchar2(100);------单据编号
  v_number  number;--------------编号
  v_rq      varchar2(30);-------日期
  v_qzcd    number;-------取自的长度
  v_lbbh    varchar2(100);--------类别的编号
 --v_MXNUM number := 0;--v_MXNUM 明细数量
begin
  if p_rq = 0 then
    select to_char(sysdate, 'yyyymmdd') into v_rq from dual;
  else
    select to_char(sysdate, 'yymmdd') into v_rq from dual;
  end if;
  select lbbh into v_lbbh from sp_kcywlb_tb where id=p_djlxid;
  select length(v_lbbh) into v_qzcd from dual;-----取的长度
  v_sql := 'select nvl(max(substr(' || p_lm || ',' || -p_hzcd || ',' ||
           p_hzcd || ')),0)+1 from ' || p_tb ||
           ' where to_char(zdrq,''yyyymmdd'')=to_char(sysdate,''yyyymmdd'')
           and instr(' || p_lm || ',''' || v_lbbh  || ''')>0';
  EXECUTE IMMEDIATE v_sql
    INTO v_number;
    v_djbh:=v_lbbh||v_rq||'-'||lpad(v_number, p_hzcd, '0');
loop
exit when v_num < 1;
insert into sp_KCRKD1_TB (ID,DJBH,DJZT,DJLXID,CKID,ZDRID,ZDRQ,YWRQ) SELECT SEQsp_KCRKD1.NEXTVAL,v_djbh,0,p_djlxid,p_ckid,p_userid,sysdate,sysdate FROM DUAL;
v_num := v_num -1;
end loop;
EXCEPTION
  WHEN OTHERS THEN
    v_djbh:='生成单号出错';
loop
exit when v_num < 1;
insert into sp_KCRKD1_TB (ID,DJBH,DJZT,DJLXID,CKID,ZDRID,ZDRQ,YWRQ) SELECT SEQsp_KCRKD1.NEXTVAL,v_djbh,0,p_djlxid,p_ckid,p_userid,sysdate,sysdate FROM DUAL;
v_num := v_num -1;
end loop;
end INSERT_DJBH_SP_KCRKD1_SP;
/

