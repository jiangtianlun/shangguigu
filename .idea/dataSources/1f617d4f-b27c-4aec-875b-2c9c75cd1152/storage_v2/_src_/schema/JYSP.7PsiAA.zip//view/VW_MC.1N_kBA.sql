CREATE VIEW VW_MC AS
  select 1 id,'名称A' txt from dual
union
select 2 id,'名称B' txt from dual
/

