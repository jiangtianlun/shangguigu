CREATE function BASE_GETMAXLEVELDEP_FC(P_USER_ID NUMBER)
  return number is
  Result   number;
  v_org_id number;
  v_dep_id auth_organization_tb.deplevel_id%type := -1;
  type orgid_table_type is table of auth_organization_tb.org_id%type index by binary_integer;
  orgid_table orgid_table_type;
  cursor depCur is
    select nvl(DEPLEVEL_ID, -1)
      from auth_organization_tb
     where ORG_ID = v_org_id;
begin
  select org_id into v_org_id from auth_user_tb where user_id = P_USER_ID;
  open depCur;
  fetch depCur
    into v_dep_id;
  close depCur;
  --if v_dep_id is null then
   -- v_dep_id := -1;
  --end if;

select org_id bulk collect into orgid_table
            from auth_organization_tb
           where deplevel_id = v_dep_id
           start with org_id = v_org_id
          connect by prior org_id_superior = org_id;

        Result:=orgid_table(orgid_table.last);
        /*select org_id
   into Result
   from (select org_id
           from auth_organization_tb
          where deplevel_id = base_getdeplevel_fc(v_org_id)
          start with org_id = v_org_id
         connect by prior org_id_superior = org_id
          order by level desc)
  where rownum = 1;*/
  return(Result);
end BASE_GETMAXLEVELDEP_FC;
/

