CREATE VIEW YF_MLSSKC_VW AS
  SELECT A.ID,A.MLID,E.MLBH,E.MLMC,E.MLGG,A.NF,A.QCKC,B.RKSL,C.CKSL,D.KCSL AS QMSL FROM YF_MLKCYE_TB A LEFT JOIN
(select mlid,rkrq,sum(sl)RKSL from (select mlid,gysid,sl,to_char(rkrq,'yyyy-MM') rkrq from yf_mlck_tb where rkrq is not null) group by mlid,rkrq) B
ON A.MLID=B.MLID AND A.NF=B.RKRQ LEFT JOIN
(select mlid,ckrq,sum(sl)CKSL from (select mlid,sl,to_char(ckrq,'yyyy-MM') ckrq from yf_mlck_tb where rkrq is not null and ckrq is not null) group by mlid,ckrq) C
ON A.MLID=C.MLID AND A.NF=C.CKRQ
LEFT JOIN
(select mlid,sum(sl)KCSL from (select mlid,sl from yf_mlck_tb where rkrq is not null and ckrq is null) group by mlid) D
ON A.MLID=D.MLID
LEFT JOIN YF_MLZD_TB E ON A.MLID=E.ID
ORDER BY A.NF,A.MLID
/

