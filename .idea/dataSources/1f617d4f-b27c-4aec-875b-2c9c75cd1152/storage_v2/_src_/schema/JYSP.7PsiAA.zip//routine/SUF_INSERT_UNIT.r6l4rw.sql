CREATE PROCEDURE SUF_INSERT_UNIT(P_PU_BM       IN NUMBER, ---单元编码
                                            P_TABLENAME   IN VARCHAR2, ---单元表名称（大写）
                                            P_UNITNAME    IN VARCHAR2, ---单元名称
                                            P_UNITCOMMENT IN VARCHAR2, ---单元说明
                                            P_UNITTYPE    IN NUMBER, ---单元类型
                                            /*P_SEQNAME     IN VARCHAR2, ---序列名称*/
                                            P_MODULEID       IN NUMBER,
                                            P_PU_SQL_FROM    VARCHAR2,
                                            P_PU_SQL_WHERE   VARCHAR2,
                                            P_PU_SQL_ORDERBY VARCHAR2,
                                            P_PU_SQL_INSERT  VARCHAR2,
                                            P_PU_SQL_UPDATE  VARCHAR2,
                                            P_PU_SQL_DELETE  VARCHAR2,
                                            P_PU_CALCULATE   VARCHAR2,
                                            P_PU_FORMPATH    VARCHAR2,
                                            P_PU_CLASS       NUMBER,
                                            P_TEMPLET_BM     NUMBER) AS
  ---审批编码

  V_ERRNO  NUMBER; --错误号
  V_ERRMSG VARCHAR2(80); --错误信息
  V_ID     NUMBER;

BEGIN
  SAVEPOINT V_SP_0000;
  V_ERRNO := -20000;

  IF P_UNITTYPE = 1 THEN
    V_ID := -1;
  ELSE
    V_ID := 3;
  END IF;

  --插入 程序单元
  INSERT INTO SUF_PROGRAMUNIT_TB
    (PU_BM,
     MODULEID,
     PU_NAME,
     PU_TYPE,
     PU_COMMENT,
     PU_SQL_FROM,
     PU_SQL_WHERE,
     PU_SQL_ORDERBY,
     PU_SQL_INSERT,
     PU_SQL_UPDATE,
     PU_SQL_DELETE,
     PU_CALCULATE,
     PU_FORMPATH,
     PU_CLASS,
     TEMPLET_BM)
  VALUES
    (P_PU_BM,
     P_MODULEID,
     P_UNITNAME,
     P_UNITTYPE,
     P_UNITCOMMENT,
     P_PU_SQL_FROM,
     P_PU_SQL_WHERE,
     P_PU_SQL_ORDERBY,
     P_PU_SQL_INSERT,
     P_PU_SQL_UPDATE,
     P_PU_SQL_DELETE,
     P_PU_CALCULATE,
     P_PU_FORMPATH,
     P_PU_CLASS,
     P_TEMPLET_BM);

  IF P_UNITTYPE = 0 THEN
    INSERT INTO SUF_FIELD_TB
      (FLD_BM,
       PU_BM,
       FLD_INDEX,
       FLD_CODE,
       FLD_KEY,
       FLD_DISPTEXT,
       FLD_WIDTH,
       FLD_VISIBLE,
       FLD_VISIBLE2)
    VALUES
      (SEQSUF_FIELD.NEXTVAL, P_PU_BM, 0, 'NULL', 'mc', '选择', 40, 0, 0);
    INSERT INTO SUF_FIELD_TB
      (FLD_BM,
       PU_BM,
       FLD_INDEX,
       FLD_CODE,
       FLD_KEY,
       FLD_DISPTEXT,
       FLD_WIDTH,
       FLD_VISIBLE,
       FLD_VISIBLE2)
    VALUES
      (SEQSUF_FIELD.NEXTVAL, P_PU_BM, 2, 'NULL', 'del', '删除', 40, 1, 0);
    INSERT INTO SUF_FIELD_TB
      (FLD_BM,
       PU_BM,
       FLD_INDEX,
       FLD_CODE,
       FLD_KEY,
       FLD_DISPTEXT,
       FLD_WIDTH,
       FLD_VISIBLE,
       FLD_VISIBLE2)
    VALUES
      (SEQSUF_FIELD.NEXTVAL, P_PU_BM, 3, 'NULL', 'xh', '序号', 40, 1, 0);
  END IF;

  IF P_UNITTYPE = 2 or p_unittype = 6 THEN
    INSERT INTO SUF_FIELD_TB
      (FLD_BM,
       PU_BM,
       FLD_INDEX,
       FLD_CODE,
       FLD_KEY,
       FLD_DISPTEXT,
       FLD_WIDTH,
       FLD_VISIBLE,
       FLD_VISIBLE2)
    VALUES
      (SEQSUF_FIELD.NEXTVAL, P_PU_BM, 0, 'NULL', 'mc', '选择', 40, 0, 0);
    INSERT INTO SUF_FIELD_TB
      (FLD_BM,
       PU_BM,
       FLD_INDEX,
       FLD_CODE,
       FLD_KEY,
       FLD_DISPTEXT,
       FLD_WIDTH,
       FLD_VISIBLE,
       FLD_VISIBLE2)
    VALUES
      (SEQSUF_FIELD.NEXTVAL, P_PU_BM, 2, 'NULL', 'del', '删除', 40, 0, 0);
    INSERT INTO SUF_FIELD_TB
      (FLD_BM,
       PU_BM,
       FLD_INDEX,
       FLD_CODE,
       FLD_KEY,
       FLD_DISPTEXT,
       FLD_WIDTH,
       FLD_VISIBLE,
       FLD_VISIBLE2)
    VALUES
      (SEQSUF_FIELD.NEXTVAL, P_PU_BM, 3, 'NULL', 'xh', '序号', 40, 1, 0);
  END IF;

  IF P_UNITTYPE = 4 THEN
    INSERT INTO SUF_FIELD_TB
      (FLD_BM,
       PU_BM,
       FLD_INDEX,
       FLD_CODE,
       FLD_KEY,
       FLD_DISPTEXT,
       FLD_WIDTH,
       FLD_VISIBLE,
       FLD_VISIBLE2)
    VALUES
      (SEQSUF_FIELD.NEXTVAL, P_PU_BM, 0, 'NULL', 'mc', '选择', 40, 1, 0);
    INSERT INTO SUF_FIELD_TB
      (FLD_BM,
       PU_BM,
       FLD_INDEX,
       FLD_CODE,
       FLD_KEY,
       FLD_DISPTEXT,
       FLD_WIDTH,
       FLD_VISIBLE,
       FLD_VISIBLE2)
    VALUES
      (SEQSUF_FIELD.NEXTVAL, P_PU_BM, 2, 'NULL', 'del', '删除', 40, 0, 0);
    INSERT INTO SUF_FIELD_TB
      (FLD_BM,
       PU_BM,
       FLD_INDEX,
       FLD_CODE,
       FLD_KEY,
       FLD_DISPTEXT,
       FLD_WIDTH,
       FLD_VISIBLE,
       FLD_VISIBLE2)
    VALUES
      (SEQSUF_FIELD.NEXTVAL, P_PU_BM, 3, 'NULL', 'xh', '序号', 40, 1, 0);
  END IF;

  IF P_UNITTYPE = 5 THEN
    INSERT INTO SUF_FIELD_TB
      (FLD_BM,
       PU_BM,
       FLD_INDEX,
       FLD_CODE,
       FLD_KEY,
       FLD_DISPTEXT,
       FLD_WIDTH,
       FLD_VISIBLE,
       FLD_VISIBLE2)
    VALUES
      (SEQSUF_FIELD.NEXTVAL, P_PU_BM, 0, 'NULL', 'mc', '选择', 40, 0, 0);
    INSERT INTO SUF_FIELD_TB
      (FLD_BM,
       PU_BM,
       FLD_INDEX,
       FLD_CODE,
       FLD_KEY,
       FLD_DISPTEXT,
       FLD_WIDTH,
       FLD_VISIBLE,
       FLD_VISIBLE2)
    VALUES
      (SEQSUF_FIELD.NEXTVAL, P_PU_BM, 2, 'NULL', 'del', '删除', 40, 0, 0);
    INSERT INTO SUF_FIELD_TB
      (FLD_BM,
       PU_BM,
       FLD_INDEX,
       FLD_CODE,
       FLD_KEY,
       FLD_DISPTEXT,
       FLD_WIDTH,
       FLD_VISIBLE,
       FLD_VISIBLE2)
    VALUES
      (SEQSUF_FIELD.NEXTVAL, P_PU_BM, 3, 'NULL', 'xh', '序号', 40, 1, 0);
  END IF;

  --插入 域列表
  INSERT INTO SUF_FIELD_TB
    (FLD_BM,
     FLD_INDEX,
     PU_BM,
     FLD_CODE,
     FLD_KEY,
     FLD_DISPTEXT,
     FLD_DATATYPE,
     FLD_CTROLTYPE,
     FLD_DICTSTRING,
     FLD_TABLENAME,
     FLD_WIDTH,
     FLD_DEFAULTVALUE2,
     FLD_DEFAULTVALUE,
     FLD_ISPRIMKEY,
     FLD_ISQUERY,
     FLD_QUERYTYPE,
     FLD_QLWIDTH,
     FLD_QCWIDTH,
     FLD_ISSUM,
     FLD_ISSAVED,
     FLD_VISIBLE,
     FLD_VISIBLE2,
     FLD_ENABLED,
     FLD_FORMATSTRING,
     FLD_ALIGN,
     FLD_PROPERTY)
    SELECT SEQSUF_FIELD.NEXTVAL AS FLD_BM, ROWNUM + V_ID AS FLD_INDEX, A.*
      FROM (SELECT P_PU_BM AS PU_BM,
                   TAB.COLUMN_NAME AS CODE,
                   TAB.COLUMN_NAME AS IKEY,
                   (SELECT COMMENTS
                      FROM USER_COL_COMMENTS COMM
                     WHERE COMM.TABLE_NAME = TAB.TABLE_NAME
                       AND COMM.COLUMN_NAME = TAB.COLUMN_NAME) AS TEXT,
                   DECODE(TAB.DATA_TYPE,
                          'NUMBER',
                          5,
                          'DATE',
                          7,
                          'VARCHAR',
                          8,
                          'VARCHAR2',
                          8,
                          'CLOB',
                          12,
                          'BLOB',
                          13) AS DATATYPE,
                   DECODE(TAB.DATA_TYPE, 'DATE', 3, 0) AS CONTROLTYPE,
                   NULL AS DICTSTRING,
                   P_TABLENAME AS TBNAME,
                   100 AS WIDTH,
                   NULL AS FLD_DVTYPE,
                   NULL AS FLD_DEFAULTVALUE,
                   DECODE(TAB.COLUMN_ID, 1, 1, 0) AS FLD_ISPRIMKEY,
                   NULL AS FLD_ISQUERY,
                   NULL AS FLD_QUERYTYPE,
                   NULL AS FLD_QLWIDTH,
                   NULL AS FLD_QCWIDTH,
                   NULL AS FLD_ISSUM,
                   1 AS FLD_ISSAVED,
                   1 AS FLD_VISIBLE,
                   1 AS FLD_VISIBLE2,
                   DECODE(TAB.COLUMN_ID, 1, 0, 1) AS FLD_ENABLED,
                   NULL AS FLD_FORMATSTRING,
                   NULL AS FLD_ALIGN,
                   NULL FLD_PROPERTY
              FROM USER_TAB_COLUMNS TAB
             WHERE TAB.TABLE_NAME = P_TABLENAME  
             ORDER BY TAB.COLUMN_ID) A;
  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK TO SAVEPOINT V_SP_0000;
    V_ERRMSG := 'STS_ERROR: SUF_INSERT_UNIT error hapened';
    RAISE_APPLICATION_ERROR(V_ERRNO, V_ERRMSG);
END;
/

