CREATE function getClassRoot(CID_IN in number) return varchar2 is
  Result varchar2(50);
  cld   ko_class_tb.class_id%type;
begin

  select class_id
    into cld
    from ko_class_tb t
   where class_superior_id is null    
   start with class_id = CID_IN
  connect by class_id = prior class_superior_id;



  if cld <> 1 then
    Result:= 'O';
  else
    Result:= 'G';
  end if;

  return(Result);
end getClassRoot;
/

