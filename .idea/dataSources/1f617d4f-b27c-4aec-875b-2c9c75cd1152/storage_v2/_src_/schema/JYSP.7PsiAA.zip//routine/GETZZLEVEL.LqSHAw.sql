CREATE function GETZZLevel(P_BM number) return varchar2 is
  Result varchar2(80);
  v_bm   number;
  cursor v_cs_0(p_0_bm number) is
    select org_id_superior  from auth_organization_tb where org_id  = p_0_bm;

begin
  open v_cs_0(P_BM);
  fetch v_cs_0
    into v_bm;
  close v_cs_0;
  if v_bm is null then
    Result := '';
  else
    Result := rpad('|_', to_number(GETZZLevelsub(v_bm, 1)) * 4, '_');
  end if;
  return(Result);
end GETZZLevel;
/

