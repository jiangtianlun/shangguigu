CREATE function get_right_value_dic(left_value  in varchar2,
                                               right_value in varchar2,
                                               p_expressidOrRoletacheid in number,
                                               p_isroletache in number)
  return varchar2 is
  -- 090407 CREATE BY cwm
  Result varchar2(1000) := null;
  v_sql1 varchar2(500) := null;
  v_sql2 varchar2(500) := null;
  v_txt  varchar2(200);
  v_id   number;
begin
  if left_value = 0 then
    select u_name
      into Result
      from auth_organization_tb
     where org_id = right_value;
  else
  if p_isroletache=0 then
  select FLD_DICTSTRING
      into v_sql1
      from suf_field_tb
     where pu_bm =
           (select MODULE_PU_BM
              from oa_module_tb module
             where module.moduleid =
                   (select tache.moduleid
                      from oa_tache_tb tache
                     where tache.tacheid =
                           (select tr.tacheid
                              from oa_tacherouter_tb tr
                             where tr.expressid = p_expressidOrRoletacheid)))
       and FLD_BM = left_value;
  else
  select FLD_DICTSTRING
      into v_sql1
      from suf_field_tb
     where pu_bm =
           (select MODULE_PU_BM
              from oa_module_tb module
             where module.moduleid =
                   (select tache.moduleid
                      from oa_tache_tb tache
                     where tache.tacheid =
                           (select tr.tacheid
                              from oa_roletache_tb tr
                             where tr.roletacheid = p_expressidOrRoletacheid)))
       and FLD_BM = left_value;
  end if;
    
  
    /*v_sql2 := v_sql1 || ' where id=' || right_value;
    execute immediate v_sql2
      into v_txt, v_id;*/
    v_txt := GET_SQL_VALUE_FC(right_value, v_sql1);
    if v_txt = '-1' then
      Result := '';
    else
      Result := v_txt;
    end if;
  end if;

  return Result;
end get_right_value_dic;
/

