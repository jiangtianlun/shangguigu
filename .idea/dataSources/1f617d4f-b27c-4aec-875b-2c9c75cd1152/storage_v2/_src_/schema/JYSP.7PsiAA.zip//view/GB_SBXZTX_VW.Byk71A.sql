CREATE VIEW GB_SBXZTX_VW AS
  select a."ID",a."SBID",a."XZRQ",a."XZXM",a."XZR",a."XZJL",a."XZDW",a."BZ",a."XCXZRQ",a."XCXZ",b.sbbh,b.sbmc,b.sblx,case when XCXZRQ is null then null else Round(xcxzrq-sysdate,3) end as r0,
case when XCXZRQ is not null and (xcxzrq-sysdate<5 and xcxzrq-sysdate>-5 and nvl(XCXZ,0)<>1) then 1 else 0 end as r1
 from (select * from GB_SBXZJL_TB where xcxzrq is not null) a left join XC_SBTZ_TB b on a.sbid=b.id
/

