CREATE procedure insert_sp_kcckd1_sp(p_InsNum in number, p_djlxid in number, p_UserId in number ,p_ckid in number) as
  v_InsNum number := p_InsNum;
  v_djlxid number :=p_djlxid;
  v_UserId number :=p_UserId;
  v_ckid number :=p_ckid;
  --v_CurNum number := 0;
begin


  /*限制新增后最大数量*/
  /*select count(id) into v_CurNum from rd_kcckd1_tb;
  if v_CurNum + v_InsNum > 100 then
     v_InsNum := 0;
  end if;*/

  loop
  exit when v_InsNum < 1;
  insert into sp_kcckd1_tb(id,djzt,djlxid,zdrq,zdrid,ywrq,ckid,shrq,shrid) select seqsp_kcckd1.nextval,0,v_djlxid,sysdate,v_UserId,sysdate,v_ckid,sysdate,v_UserId from dual;
  v_InsNum := v_InsNum -1;
  end loop;

end insert_sp_kcckd1_sp;
/

