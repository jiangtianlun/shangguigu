CREATE VIEW SCYJH_VW AS
  select ID,
       LJID,
       LJBH,
       LJMC,
       JHSL,
       SJSL,
       BDKCSL,
       ZZKCSL,
       NFYF,
       ZDRQ,
       DJLX,
       ZKC,
       JYSL,
       DJZT
  from scyjh_tb
/

