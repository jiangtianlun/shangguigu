CREATE VIEW SP_JXC2_VW AS
  SELECT CKID,
               WLID,
               SUM(QCKC) QCKC,--期初库存
               SUM(QCKCJE) QCKCJE,

               SUM(CGRK) CGRK,--采购入库单总
               SUM(CGRKJE) CGRKJE,
               SUM(SCRK) SCRK,--生产入库单总
               SUM(SCRKJE) SCRKJE,
               SUM(QTRK) QTRK,--其他入库单总
               SUM(QTRKJE) QTRKJE,
               SUM(CGRK) +SUM(SCRK)+ SUM(QTRK) BQRK, --本期入库总
               SUM(CGRKJE) +SUM(SCRKJE)+ SUM(QTRKJE) BQRKJE,

               SUM(XSCK) XSCK,--销售出库单总
               SUM(XSCKJE) XSCKJE,
               SUM(LLCK) LLCK,--领料出库单总
               SUM(LLCKJE) LLCKJE,
               SUM(QTCK) QTCK,--其他出库单总
               SUM(QTCKJE) QTCKJE,
               SUM(XSCK) + SUM(LLCK)+SUM(QTCK) BQCK, --本期出库总
               SUM(XSCKJE) + SUM(LLCKJE)+SUM(QTCKJE) BQCKJE,
               SUM(QCKC) + SUM(CGRK) +SUM(SCRK)+ SUM(QTRK) - SUM(XSCK)-SUM(LLCK) - SUM(QTCK) BQJY, --本期结余
               SUM(QCKCJE) + SUM(CGRKJE) +SUM(SCRKJE)+ SUM(QTRKJE) - SUM(XSCKJE)-SUM(LLCKJE) - SUM(QTCKJE) BQJYJE,
               ph
          FROM ( --期初库存
                SELECT CKID,
                        WLID,
                        NVL(PDSL, 0) QCKC,  --期初盘点库存
                        NVL(PDJE, 0) QCKCJE,--期初盘点金额
                        0 CGRK,   --采购入库
                        0 CGRKJE, --采购入库金额
                        0 SCRK,
                        0 SCRKJE,
                        0 QTRK,   --其他入库
                        0 QTRKJE, --其他入库金额
                        0 XSCK,   --销售出库
                        0 XSCKJE, --销售出库金额
                        0 LLCK,   --领料出库
                        0 LLCKJE, --领料出库金额
                        0 QTCK,   --其他出库
                        0 QTCKJE, --其他出库金额
                        ph        --批号
                  FROM SP_QCKC_TB QC, SP_SJCS_TB SJ
                 WHERE QC.DJZT = 1
                   --AND QC.CKID = 5
                   AND QC.DJLXID in (select id from SP_kcywlb_tb where fid = 47)
                   AND TO_CHAR(QC.YWRQ, 'YYYY-MM') =
                       TO_CHAR(SJ.KSRQ, 'YYYY-MM')
                   AND PDSL != 0  --盘点数量为0不计入下月进销存报表
                UNION ALL
                --采购入库
                 SELECT rkd1.CKID,
                       WLID,
                       0 QCKC,
                       0 QCKCJE,
                       NVL(SSSL, 0) CGRK,
                       NVL(JE, 0) CGRKJE,
                       0 SCRK,
                       0 SCRKJE,
                       0 QTRK,
                       0 QTRKJE,--其他入库金额
                       0 XSCK,   --销售出库
                       0 XSCKJE, --销售出库金额
                       0 LLCK,   --领料出库
                       0 LLCKJE, --领料出库金额
                       0 QTCK,   --其他出库
                       0 QTCKJE, --其他出库金额
                        ph        --批号
                  FROM SP_KCRKD1_TB RKD1, SP_KCRKD2_TB RKD2, SP_SJCS_TB SJ
                 WHERE RKD1.ID = RKD2.FID
                   AND RKD1.DJZT = 1
                   --AND RKD1.CKID = 5
                   AND RKD1.DJLXID in (select id from sp_kcywlb_tb where fid = 79)
                   AND TO_CHAR(RKD1.YWRQ, 'YYYY-MM-DD') BETWEEN
                       TO_CHAR(SJ.KSRQ, 'YYYY-MM-DD') AND
                       TO_CHAR(SJ.JSRQ, 'YYYY-MM-DD')
                UNION ALL
                --生产入库
                SELECT rkd1.CKID,
                       WLID,
                       0 QCKC,
                       0 QCKCJE,
                       0 CGRK,
                       0 CGRKJE,
                       NVL(SSSL, 0) SCRK,
                       NVL(JE, 0) SCRKJE,
                       0 QTRK,
                       0 QTRKJE,--其他入库金额
                       0 XSCK,   --销售出库
                       0 XSCKJE, --销售出库金额
                       0 LLCK,   --领料出库
                       0 LLCKJE, --领料出库金额
                       0 QTCK,   --其他出库
                       0 QTCKJE, --其他出库金额
                        ph        --批号
                  FROM SP_KCRKD1_TB RKD1, SP_KCRKD2_TB RKD2, SP_SJCS_TB SJ
                 WHERE RKD1.ID = RKD2.FID
                   AND RKD1.DJZT = 1
                   --AND RKD1.CKID = 5
                   AND RKD1.DJLXID in (select id from sp_kcywlb_tb where fid = 80) --成品、半成品的生产入库
                   AND TO_CHAR(RKD1.YWRQ, 'YYYY-MM-DD') BETWEEN
                       TO_CHAR(SJ.KSRQ, 'YYYY-MM-DD') AND
                       TO_CHAR(SJ.JSRQ, 'YYYY-MM-DD')
                UNION ALL
                --其他入库
                SELECT rkd1.CKID,
                       WLID,
                       0 QCKC,
                       0 QCKCJE,
                       0 CGRK,
                       0 CGRKJE,
                       0 SCRK,
                       0 SCRKJE,
                       NVL(SSSL, 0) QTRK,
                       NVL(JE, 0) QTRKJE,--其他入库金额
                       0 XSCK,   --销售出库
                       0 XSCKJE, --销售出库金额
                       0 LLCK,   --领料出库
                       0 LLCKJE, --领料出库金额
                       0 QTCK,   --其他出库
                       0 QTCKJE, --其他出库金额
                        ph        --批号
                  FROM SP_KCRKD1_TB RKD1, SP_KCRKD2_TB RKD2, SP_SJCS_TB SJ
                 WHERE RKD1.ID = RKD2.FID
                   AND RKD1.DJZT = 1
                   --AND RKD1.CKID = 5
                   AND RKD1.DJLXID in (select id from sp_kcywlb_tb where fid =37)  --其他入库
                   AND TO_CHAR(RKD1.YWRQ, 'YYYY-MM-DD') BETWEEN
                       TO_CHAR(SJ.KSRQ, 'YYYY-MM-DD') AND
                       TO_CHAR(SJ.JSRQ, 'YYYY-MM-DD')
                UNION ALL
                --销售出库
                SELECT CKID,
                       WLID,
                       0 QCKC,
                       0 QCKCJE,
                       0 CGRK,
                       0 CGRKJE,
                       0 SCRK,
                       0 SCRKJE,
                       0 QTRK,
                       0 QTRKJE,
                       NVL(SFSL, 0) XSCK,
                       NVL(JE, 0) XSCKJE,
                       0 LLCK,
                       0 LLCKJE,
                       0 QTCK,
                       0 QTCKJE,
                       ph
                  FROM SP_KCCKD1_TB CKD1, SP_KCCKD2_TB CKD2, SP_SJCS_TB SJ
                 WHERE CKD1.ID = CKD2.FID
                   AND CKD1.DJZT = 1
                   --AND CKD1.CKID = 5
                   AND CKD1.DJLXID in (select id from sp_kcywlb_tb where fid = 78)--成品、半成品销售出库
                   AND TO_CHAR(CKD1.YWRQ, 'YYYY-MM-DD') BETWEEN
                       TO_CHAR(SJ.KSRQ, 'YYYY-MM-DD') AND
                       TO_CHAR(SJ.JSRQ, 'YYYY-MM-DD')
                UNION ALL
                --领料出库
                SELECT CKID,
                       WLID,
                       0 QCKC,
                       0 QCKCJE,
                       0 CGRK,
                       0 CGRKJE,
                       0 SCRK,
                       0 SCRKJE,
                       0 QTRK,
                       0 QTRKJE,
                       0 XSCK,
                       0 XSCKJE,
                       NVL(SFSL, 0) LLCK,
                       NVL(JE, 0) LLCKJE,
                       0 QTCK,
                       0 QTCKJE,
                       ph
                  FROM SP_KCCKD1_TB CKD1, SP_KCCKD2_TB CKD2, SP_SJCS_TB SJ
                 WHERE CKD1.ID = CKD2.FID
                   AND CKD1.DJZT = 1
                   --AND CKD1.CKID = 5
                   AND CKD1.DJLXID in (select id from sp_kcywlb_tb where fid = 77)
                   AND TO_CHAR(CKD1.YWRQ, 'YYYY-MM-DD') BETWEEN
                       TO_CHAR(SJ.KSRQ, 'YYYY-MM-DD') AND
                       TO_CHAR(SJ.JSRQ, 'YYYY-MM-DD')

                UNION ALL

                --其他出库
                SELECT CKID,
                       WLID,
                       0 QCKC,
                       0 QCKCJE,
                       0 CGRK,
                       0 CGRKJE,
                       0 SCRK,
                       0 SCRKJE,
                       0 QTRK,
                       0 QTRKJE,
                       0 XSCK,
                       0 XSCKJE,
                       0 LLCK,
                       0 LLCKJE,
                       NVL(SFSL, 0) QTCK,
                       NVL(JE,0) QTCKJE,
                       ph
                  FROM SP_KCCKD1_TB CKD1, SP_KCCKD2_TB CKD2, SP_SJCS_TB SJ
                 WHERE CKD1.ID = CKD2.FID
                   AND CKD1.DJZT = 1
                   --AND CKD1.CKID = 5
                   AND CKD1.DJLXID in (select id from sp_kcywlb_tb where fid =42) --其他出库
                   AND TO_CHAR(CKD1.YWRQ, 'YYYY-MM-DD') BETWEEN
                       TO_CHAR(SJ.KSRQ, 'YYYY-MM-DD') AND
                       TO_CHAR(SJ.JSRQ, 'YYYY-MM-DD'))
         GROUP BY CKID, WLID, ph ORDER BY WLID,PH
/

