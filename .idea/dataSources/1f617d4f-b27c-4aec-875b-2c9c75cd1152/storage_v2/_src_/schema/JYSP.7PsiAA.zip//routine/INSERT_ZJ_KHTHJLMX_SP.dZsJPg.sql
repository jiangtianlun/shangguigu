CREATE procedure INSERT_ZJ_KHTHJLMX_SP(p_fid in number,p_num in number)
as
----62901客户退货记录明细新增1行按钮存储过程
 v_num number:= p_num;
begin
loop
exit when v_num < 1;
insert into ZJ_KHTHJLMX_TB(ID,FID) SELECT SEQZJ_KHTHJLMX.NEXTVAL,p_fid FROM DUAL;
v_num := v_num -1;
end loop;
end INSERT_ZJ_KHTHJLMX_SP;
/

